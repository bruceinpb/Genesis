/**
 * Genesis 2 — Main Application Controller
 * Orchestrates all modules and manages the UI.
 *
 * Uses Firestore for cloud storage (projects, chapters) and
 * IndexedDB for local-only features (characters, notes, settings).
 */

import { Storage, STORE_NAMES } from './storage.js';
import { FirestoreStorage } from './firestore-storage.js';
import { ManuscriptManager } from './manuscript.js';
import { ProseAnalyzer } from './prose.js';
import { StructureManager } from './structure.js';
import { ExportManager } from './export.js';
import { Editor } from './editor.js';
import { ProseGenerator } from './generate.js';
import { ErrorDatabase } from './error-database.js';

class App {
  constructor() {
    this.localStorage = new Storage();   // IndexedDB for local features
    this.fs = new FirestoreStorage();     // Firestore for cloud features
    this.manuscript = null;               // For characters/notes (IndexedDB)
    this.analyzer = new ProseAnalyzer();
    this.structure = new StructureManager();
    this.exporter = null;
    this.editor = null;
    this.generator = null;
    this.errorDb = null;

    this.state = {
      currentUser: null,
      currentProjectId: null,
      currentChapterId: null,
      sidebarTab: 'chapters',
      focusMode: false,
      sidebarOpen: true,
      theme: 'dark',
      dailyGoal: 1000,
      wordsToday: 0,
      sessionStart: Date.now()
    };

    // Cached project data to avoid extra Firestore reads
    this._currentProject = null;
    this._chapterWordCounts = {};
    this._autoSaveInterval = null;
    this._currentChapterOutline = '';
    this._lastProseReview = null;
    this._lastGeneratedText = '';
    this._cachedErrorPatternsPrompt = '';
  }

  async init() {
    // Initialize local storage (for settings, characters, notes)
    await this.localStorage.init();
    this.manuscript = new ManuscriptManager(this.localStorage);

    // Initialize modules
    this.exporter = new ExportManager(this.fs);
    this.generator = new ProseGenerator(this.localStorage);
    await this.generator.init();
    this.errorDb = new ErrorDatabase(this.localStorage, this.fs);

    // Pre-load error patterns prompt for immediate availability
    this.errorDb.buildNegativePrompt({ maxPatterns: 20, minFrequency: 2 })
      .then(prompt => { this._cachedErrorPatternsPrompt = prompt; })
      .catch(() => {});

    // Load settings
    this.state.theme = await this.localStorage.getSetting('theme', 'dark');
    this.state.dailyGoal = await this.localStorage.getSetting('dailyGoal', 1000);
    this._hfToken = await this.localStorage.getSetting('hfToken', '');

    // Apply theme
    this._applyTheme(this.state.theme);

    // Initialize editor
    const editorEl = document.getElementById('editor');
    this.editor = new Editor(editorEl, {
      onChange: (content) => this._onEditorChange(content),
      onWordCount: (count) => this._onWordCountUpdate(count)
    });

    // Bind UI events
    this._bindEvents();

    // Check for saved user
    this.state.currentUser = window.localStorage.getItem('genesis2_userName') || null;

    // Show landing page
    await this._showLanding();

    // Track daily words
    await this._loadDailyProgress();

    // Register service worker
    this._registerServiceWorker();
  }

  // ========================================
  //  Landing Page
  // ========================================

  async _showLanding() {
    // Stop auto-save
    if (this._autoSaveInterval) {
      clearInterval(this._autoSaveInterval);
      this._autoSaveInterval = null;
    }

    // Save current chapter before leaving
    await this._saveCurrentChapter();

    // Show landing, hide app
    document.getElementById('landing-page').style.display = '';
    document.getElementById('app').style.display = 'none';

    // Reset state
    this.state.currentProjectId = null;
    this.state.currentChapterId = null;
    this._currentProject = null;
    this._chapterWordCounts = {};

    if (this.state.currentUser) {
      await this._showProjectSelection();
    } else {
      this._showUserSelection();
    }
  }

  async _switchUser() {
    await this._saveCurrentChapter();
    this.state.currentUser = null;
    localStorage.removeItem('genesis-user');
    await this._showLanding();
  }

  _showUserSelection() {
    document.getElementById('landing-user-select').style.display = '';
    document.getElementById('landing-projects').style.display = 'none';
    this._loadExistingUsers();
    // Focus the name input
    setTimeout(() => document.getElementById('new-user-name')?.focus(), 300);
  }

  async _showProjectSelection() {
    document.getElementById('landing-user-select').style.display = 'none';
    document.getElementById('landing-projects').style.display = '';
    document.getElementById('landing-user-name').textContent = this.state.currentUser;
    await this._loadProjects();
  }

  async _loadExistingUsers() {
    const list = document.getElementById('user-list');
    try {
      const users = await this.fs.getAllUsers();
      if (users.length === 0) {
        list.innerHTML = '';
      } else {
        list.innerHTML = users.map(u =>
          `<button class="user-btn" data-name="${this._esc(u.displayName)}">${this._esc(u.displayName)}</button>`
        ).join('');
      }
    } catch (err) {
      console.error('Failed to load users:', err);
      list.innerHTML = `<p class="landing-error">Could not connect to database. Check Firebase configuration in js/firebase-config.js.</p>`;
    }
  }

  async _selectUser(name) {
    this.state.currentUser = name;
    window.localStorage.setItem('genesis2_userName', name);
    try {
      await this.fs.getOrCreateUser(name);
    } catch (err) {
      console.error('Failed to create user:', err);
    }
    await this._showProjectSelection();
  }

  async _loadProjects() {
    const myList = document.getElementById('my-projects-list');
    const othersList = document.getElementById('others-projects-list');
    const othersSection = document.getElementById('others-projects-section');

    myList.innerHTML = '<div class="landing-loading"><div class="generate-spinner"></div> Loading projects...</div>';

    try {
      const allProjects = await this.fs.getAllProjects();
      const myProjects = allProjects.filter(p => p.owner === this.state.currentUser);
      const otherProjects = allProjects.filter(p => p.owner !== this.state.currentUser);

      myList.innerHTML = myProjects.length > 0
        ? myProjects.map(p => this._renderProjectCard(p)).join('')
        : '<p class="projects-empty">No projects yet. Create your first one!</p>';

      if (otherProjects.length > 0) {
        othersSection.style.display = '';
        const grouped = {};
        for (const p of otherProjects) {
          if (!grouped[p.owner]) grouped[p.owner] = [];
          grouped[p.owner].push(p);
        }
        let html = '';
        for (const [owner, projects] of Object.entries(grouped)) {
          html += `<div class="owner-group"><h4>${this._esc(owner)}'s Projects</h4>`;
          html += `<div class="project-grid">`;
          html += projects.map(p => this._renderProjectCard(p)).join('');
          html += `</div></div>`;
        }
        othersList.innerHTML = html;
      } else {
        othersSection.style.display = 'none';
      }
    } catch (err) {
      console.error('Failed to load projects:', err);
      myList.innerHTML = `<p class="landing-error">Failed to load projects. Check your internet connection and Firebase configuration.</p>`;
    }
  }

  _renderProjectCard(project) {
    const updated = project.updatedAt?.toDate
      ? project.updatedAt.toDate()
      : new Date(project.updatedAt);
    const dateStr = updated.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    return `
      <div class="project-card" data-id="${project.id}">
        <div class="project-card-inner">
          ${project.coverImage ? `<img class="project-card-cover" src="${project.coverImage}" alt="Cover" loading="lazy">` : '<div class="project-card-cover-empty"></div>'}
          <div class="project-card-info">
            <div class="project-card-title">${this._esc(project.title)}</div>
            <div class="project-card-meta">
              ${project.genre ? `<span class="project-genre">${this._esc(project.genre)}</span>` : ''}
              <span class="project-date">Updated ${dateStr}</span>
            </div>
            <div class="project-card-goal">${(project.wordCountGoal || 0).toLocaleString()} word goal</div>
          </div>
        </div>
      </div>`;
  }

  async _createNewProject() {
    this._showNewProjectHelp();
  }

  _showNewProjectHelp() {
    const overlay = document.getElementById('new-project-help-overlay');
    if (overlay) overlay.classList.add('visible');
  }

  _showNewProjectModal() {
    const overlay = document.getElementById('new-project-overlay');
    if (!overlay) return;

    // Reset form fields
    const titleEl = document.getElementById('new-project-title');
    const genreEl = document.getElementById('new-project-genre');
    const subgenreGroupEl = document.getElementById('new-project-subgenre-group');
    const subgenreEl = document.getElementById('new-project-subgenre');
    const goalEl = document.getElementById('new-project-word-goal');
    const structureEl = document.getElementById('new-project-structure');

    if (titleEl) titleEl.value = '';
    if (goalEl) goalEl.value = '80000';
    if (subgenreGroupEl) subgenreGroupEl.style.display = 'none';
    if (subgenreEl) subgenreEl.innerHTML = '<option value="">— None —</option>';

    // Populate genre options
    if (genreEl) {
      genreEl.innerHTML = '<option value="">— Select Genre (optional) —</option>' +
        (window.GENRE_DATA || []).map(g => `<option value="${g.id}">${g.label}</option>`).join('');
    }

    // Populate structure template options
    if (structureEl) {
      const templates = this.structure.getTemplates();
      structureEl.innerHTML = templates.map(t =>
        `<option value="${t.id}" ${t.id === 'userOutline' ? '' : (t.id === 'threeAct' ? 'selected' : '')}>${t.name}</option>`
      ).join('');
    }

    overlay.classList.add('visible');
    setTimeout(() => titleEl?.focus(), 300);
  }

  async _submitNewProject() {
    const title = document.getElementById('new-project-title')?.value?.trim();
    if (!title) {
      alert('Please enter a project title.');
      return;
    }

    const genre = document.getElementById('new-project-genre')?.value || '';
    const subgenre = document.getElementById('new-project-subgenre')?.value || '';
    const wordCountGoal = parseInt(document.getElementById('new-project-word-goal')?.value) || 80000;
    const structureTemplate = document.getElementById('new-project-structure')?.value || 'threeAct';

    // Close the modal
    document.getElementById('new-project-overlay')?.classList.remove('visible');

    try {
      const project = await this.fs.createProject({
        owner: this.state.currentUser,
        title,
        genre,
        subgenre,
        wordCountGoal
      });

      // Save the structure template choice for this project
      await this.localStorage.setSetting('structureTemplate_' + project.id, structureTemplate);

      await this.fs.createChapter({
        projectId: project.id,
        chapterNumber: 1,
        title: 'Chapter One'
      });

      await this._openProject(project.id);
    } catch (err) {
      console.error('Failed to create project:', err);
      alert('Failed to create project. Check your internet connection.');
    }
  }

  async _openProject(projectId) {
    // Hide landing, show app
    document.getElementById('landing-page').style.display = 'none';
    document.getElementById('app').style.display = '';

    await this._loadProject(projectId);
  }

  // ========================================
  //  Project & Chapter Management
  // ========================================

  async _loadProject(projectId) {
    try {
      const project = await this.fs.getProject(projectId);
      if (!project) {
        await this._showLanding();
        return;
      }

      this.state.currentProjectId = projectId;
      this._currentProject = project;

      // Update toolbar title
      document.getElementById('project-title').textContent = project.title;

      // Render chapter list
      await this._renderChapterList();

      // Load first chapter
      const chapters = await this.fs.getProjectChapters(projectId);

      // Cache word counts
      this._chapterWordCounts = {};
      for (const ch of chapters) {
        this._chapterWordCounts[ch.id] = ch.wordCount || 0;
      }

      if (chapters.length > 0) {
        await this._loadChapter(chapters[0].id);
      } else {
        this.editor.clear();
        this.state.currentChapterId = null;
        this._showWelcome();
      }

      // Update cover display
      this._updateCoverDisplay();

      // Update status bar
      this._updateStatusBarLocal();

      // Start auto-save interval (30 seconds)
      if (this._autoSaveInterval) clearInterval(this._autoSaveInterval);
      this._autoSaveInterval = setInterval(() => {
        this._saveCurrentChapter();
      }, 30000);
    } catch (err) {
      console.error('Failed to load project:', err);
      alert('Failed to load project. Check your internet connection.');
      await this._showLanding();
    }
  }

  async _loadChapter(chapterId) {
    try {
      const chapter = await this.fs.getChapter(chapterId);
      if (!chapter) return;

      // Save current chapter first
      await this._saveCurrentChapter();

      // Show editor, hide welcome
      this._hideWelcome();

      this.state.currentChapterId = chapterId;
      this._currentChapterOutline = chapter.outline || '';
      this.editor.setContent(chapter.content || '');

      // Display chapter outline if available
      const outlineDisplay = document.getElementById('chapter-outline-display');
      const outlineText = document.getElementById('chapter-outline-text');
      if (outlineDisplay && outlineText) {
        if (this._currentChapterOutline) {
          outlineText.textContent = this._currentChapterOutline;
          outlineDisplay.style.display = '';
        } else {
          outlineDisplay.style.display = 'none';
        }
      }

      // Update active state in tree
      document.querySelectorAll('.tree-item').forEach(el => {
        el.classList.toggle('active', el.dataset.id === chapterId);
      });

      // Update toolbar chapter title
      const titleEl = document.getElementById('scene-title');
      if (titleEl) titleEl.textContent = chapter.title;
    } catch (err) {
      console.error('Failed to load chapter:', err);
    }
  }

  async _saveCurrentChapter() {
    if (!this.state.currentChapterId) return;
    const content = this.editor.getContent();
    try {
      await this.fs.updateChapter(this.state.currentChapterId, { content });
    } catch (err) {
      console.error('Auto-save failed:', err);
    }
  }

  // ========================================
  //  Editor Events
  // ========================================

  async _onEditorChange(content) {
    if (!this.state.currentChapterId) return;

    // Save to Firestore
    try {
      await this.fs.updateChapter(this.state.currentChapterId, { content });
    } catch (err) {
      console.error('Save failed:', err);
    }

    // Update local word count displays
    this._updateLocalWordCounts(content);
  }

  _onWordCountUpdate(count) {
    const wcEl = document.getElementById('status-words');
    if (wcEl) wcEl.textContent = count.toLocaleString();

    const fwcWords = document.getElementById('fwc-words');
    if (fwcWords) fwcWords.textContent = count.toLocaleString();

    this._trackDailyWords(count);
  }

  _updateLocalWordCounts(content) {
    const text = content.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ');
    const words = text.match(/[a-zA-Z'''\u2019-]+/g) || [];
    const chapterWords = words.length;

    // Update tree item
    const chEl = document.querySelector(`.tree-item[data-id="${this.state.currentChapterId}"] .word-count`);
    if (chEl) chEl.textContent = chapterWords.toLocaleString();

    // Update cached word count
    this._chapterWordCounts[this.state.currentChapterId] = chapterWords;

    // Recalculate total
    const total = Object.values(this._chapterWordCounts).reduce((sum, wc) => sum + wc, 0);

    const totalEl = document.getElementById('status-total');
    if (totalEl) totalEl.textContent = total.toLocaleString();
    const fwcTotal = document.getElementById('fwc-total');
    if (fwcTotal) fwcTotal.textContent = total.toLocaleString();

    // Update progress
    const project = this._currentProject;
    if (project) {
      const goal = project.wordCountGoal || 80000;
      const progress = Math.round((total / goal) * 100);
      const progressEl = document.getElementById('status-progress');
      if (progressEl) progressEl.textContent = progress + '%';
      const fwcProgress = document.getElementById('fwc-progress');
      if (fwcProgress) fwcProgress.textContent = progress + '%';
    }
  }

  // ========================================
  //  Sidebar Rendering
  // ========================================

  async _renderChapterList() {
    const container = document.getElementById('sidebar-chapters');
    if (!container || !this.state.currentProjectId) return;

    try {
      const chapters = await this.fs.getProjectChapters(this.state.currentProjectId);

      let html = '';

      // Chapter toolbar with Select All, Delete Selected, Accept Outline
      if (chapters.length > 0) {
        html += `
        <div class="chapter-toolbar">
          <label class="chapter-select-all-label">
            <input type="checkbox" id="chapter-select-all" title="Select All">
            <span>Select All</span>
          </label>
          <button class="btn btn-sm chapter-toolbar-btn chapter-delete-selected-btn" id="btn-delete-selected-chapters" disabled title="Delete selected chapters">Delete Selected</button>
          <button class="btn btn-sm chapter-toolbar-btn chapter-accept-outline-btn" id="btn-accept-chapter-outline" title="Accept outline and begin prose generation">Accept Outline</button>
        </div>`;
      }

      for (const chapter of chapters) {
        const statusLabel = chapter.status === 'complete' ? 'done' : chapter.status === 'revision' ? 'rev' : '';
        const hasOutline = chapter.outline ? ' title="Has outline"' : '';
        const outlineIcon = chapter.outline ? '<span style="color:var(--accent-primary);font-size:0.7rem;margin-right:2px;">&#9998;</span>' : '';
        html += `
        <div class="tree-item chapter ${chapter.id === this.state.currentChapterId ? 'active' : ''}"
             data-id="${chapter.id}" data-type="chapter"${hasOutline}>
          <input type="checkbox" class="chapter-checkbox" data-chapter-id="${chapter.id}" title="Select chapter">
          <span class="icon">&#9656;</span>
          <span class="name">${outlineIcon}${this._esc(chapter.title)}</span>
          <span class="word-count">${(chapter.wordCount || 0).toLocaleString()}${statusLabel ? ' (' + statusLabel + ')' : ''}</span>
          <button class="chapter-delete-btn" data-delete-chapter="${chapter.id}" title="Delete chapter">&times;</button>
        </div>`;
      }

      html += `
        <button class="tree-add" data-action="add-chapter">
          + Chapter
        </button>`;

      container.innerHTML = html;
    } catch (err) {
      console.error('Failed to render chapter list:', err);
    }
  }

  async _renderCharactersList() {
    const container = document.getElementById('sidebar-characters');
    if (!container || !this.state.currentProjectId) return;

    // Characters stored locally in IndexedDB
    const characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId);

    let html = '';
    for (const char of characters) {
      html += `
        <div class="character-card" data-id="${char.id}">
          <div class="name">${this._esc(char.name)}</div>
          <div class="role">${char.role}</div>
          ${char.description ? `<div class="desc">${this._esc(char.description.substring(0, 100))}</div>` : ''}
        </div>`;
    }

    html += `
      <button class="tree-add" data-action="add-character">
        + Character
      </button>`;

    container.innerHTML = html;
  }

  async _renderNotesList() {
    const container = document.getElementById('sidebar-notes');
    if (!container || !this.state.currentProjectId) return;

    // Notes stored locally in IndexedDB
    const notes = await this.localStorage.getProjectNotes(this.state.currentProjectId);

    let html = '';
    for (const note of notes) {
      html += `
        <div class="tree-item" data-id="${note.id}" data-type="note">
          <span class="icon">&#9998;</span>
          <span class="name">${this._esc(note.title)}</span>
          <span class="word-count">${note.type}</span>
        </div>`;
    }

    html += `
      <button class="tree-add" data-action="add-note">
        + Note
      </button>`;

    container.innerHTML = html;
  }

  // ========================================
  //  Panels
  // ========================================

  async openAnalysisPanel() {
    const content = this.editor.getContent();
    const analysis = this.analyzer.analyze(content);
    const score = this.analyzer.calculateScore(analysis);

    const body = document.getElementById('panel-analysis-body');
    if (!body) return;

    body.innerHTML = this._renderAnalysis(analysis, score);
    this._showPanel('analysis');
  }

  async openStructurePanel() {
    if (!this.state.currentProjectId || !this._currentProject) return;

    const project = this._currentProject;
    const totalWords = Object.values(this._chapterWordCounts).reduce((sum, wc) => sum + wc, 0);
    const templateId = await this.localStorage.getSetting('structureTemplate_' + this.state.currentProjectId, 'threeAct');
    const targetWords = project.wordCountGoal || 80000;

    const guidance = this.structure.getPacingGuidance(templateId, targetWords, totalWords);
    const beats = this.structure.mapBeatsToManuscript(templateId, targetWords, totalWords);

    const body = document.getElementById('panel-structure-body');
    if (!body) return;

    body.innerHTML = this._renderStructure(guidance, beats, project, templateId);
    this._showPanel('structure');
  }

  async openExportPanel() {
    // Show/hide cover download section
    const coverSection = document.getElementById('export-cover-section');
    const coverPreview = document.getElementById('export-cover-preview');
    if (coverSection && coverPreview) {
      if (this._currentProject?.coverImage) {
        coverSection.style.display = '';
        coverPreview.style.display = '';
        coverPreview.src = this._currentProject.coverImage;
      } else {
        coverSection.style.display = 'none';
      }
    }
    this._showPanel('export');
  }

  async openGeneratePanel() {
    const noKeyEl = document.getElementById('generate-no-key');
    const generateBtn = document.getElementById('btn-generate-prose');
    const plotEl = document.getElementById('generate-plot');

    if (noKeyEl && generateBtn) {
      if (!this.generator.hasApiKey()) {
        noKeyEl.style.display = 'block';
        generateBtn.style.display = 'none';
      } else {
        noKeyEl.style.display = 'none';
        generateBtn.style.display = '';
      }
    }

    const errEl = document.getElementById('generate-error');
    if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }

    this._setGenerateStatus(false);

    // Populate AI instructions from project
    const aiInstructionsEl = document.getElementById('generate-ai-instructions');
    if (aiInstructionsEl) {
      aiInstructionsEl.value = this._currentProject?.aiInstructions || '';
    }

    // Show chapter outline if available
    if (this._currentChapterOutline && plotEl) {
      // Pre-fill the plot field with the outline if the plot field is empty
      if (!plotEl.value?.trim()) {
        plotEl.value = this._currentChapterOutline;
      }
    }

    this._showPanel('generate');

    setTimeout(() => plotEl?.focus(), 300);
  }

  async _runGeneration(options = {}) {
    let plot, wordTarget, tone, style, useCharacters;
    if (options.isContinuation && this._lastGenSettings) {
      plot = this._lastGenSettings.plot;
      wordTarget = options.wordTarget || this._lastGenSettings.wordTarget;
      tone = this._lastGenSettings.tone;
      style = this._lastGenSettings.style;
      useCharacters = this._lastGenSettings.useCharacters;
    } else {
      plot = document.getElementById('generate-plot')?.value?.trim();
      if (!plot) {
        alert('Please enter a story plot or description.');
        return;
      }
      wordTarget = parseInt(document.getElementById('generate-word-target')?.value) || 1000;
      tone = document.getElementById('generate-tone')?.value?.trim() || '';
      style = document.getElementById('generate-style')?.value?.trim() || '';
      useCharacters = document.getElementById('generate-use-characters')?.checked;
    }

    const existingContent = this.editor.getContent();
    // Store pre-generation content so rewrite can roll back to it
    this._preGenerationContent = existingContent;
    let characters = [];
    if (useCharacters && this.state.currentProjectId) {
      characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId);
    }

    // Load project notes if checkbox is checked
    let useNotes;
    if (options.isContinuation && this._lastGenSettings) {
      useNotes = this._lastGenSettings.useNotes;
    } else {
      useNotes = document.getElementById('generate-use-notes')?.checked;
    }
    let notes = '';
    if (useNotes && this.state.currentProjectId) {
      const projectNotes = await this.localStorage.getProjectNotes(this.state.currentProjectId);
      if (projectNotes.length > 0) {
        notes = projectNotes.map(n => {
          let entry = n.title;
          if (n.type && n.type !== 'general') entry = `[${n.type}] ${entry}`;
          if (n.content) entry += '\n' + n.content;
          return entry;
        }).join('\n\n');
      }
    }

    // Append project knowledge base as reference materials
    const knowledgePromptMain = await this._getProjectKnowledge();
    if (knowledgePromptMain) {
      notes = notes ? notes + '\n\n' + knowledgePromptMain : knowledgePromptMain;
    }

    // Load AI instructions from project
    const aiInstructions = this._currentProject?.aiInstructions || '';

    this._lastGenSettings = { plot, wordTarget, tone, style, useCharacters, useNotes, chapterOutline: this._currentChapterOutline || '' };

    // Get chapter title
    let chapterTitle = '';
    if (this.state.currentChapterId) {
      try {
        const chapter = await this.fs.getChapter(this.state.currentChapterId);
        if (chapter) chapterTitle = chapter.title;
      } catch (_) {}
    }

    // Build conclusion instructions if needed
    let concludeStory = options.concludeStory || false;
    const project = this._currentProject;
    const projectGoal = project ? (project.wordCountGoal || 0) : 0;
    const genreId = project ? (project.genre || '') : '';
    const subgenreId = project ? (project.subgenre || '') : '';
    const genreInfo = this._getGenreRules(genreId, subgenreId);
    const genre = genreInfo ? genreInfo.label : '';
    const genreRules = genreInfo ? genreInfo.rules : '';

    this._showContinueBar(false);
    this._setGenerateStatus(true);
    this._generateCancelled = false;
    const errEl = document.getElementById('generate-error');
    if (errEl) { errEl.style.display = 'none'; }

    this._closeAllPanels();
    this._hideWelcome();

    const editorEl = this.editor.element;

    // Load chapter outline if available
    const chapterOutline = this._currentChapterOutline || '';

    // Load error patterns from the cross-project database as negative prompts
    let errorPatternsPrompt = '';
    if (this.errorDb) {
      try {
        errorPatternsPrompt = await this.errorDb.buildNegativePrompt({ maxPatterns: 20, minFrequency: 2 });
        this._cachedErrorPatternsPrompt = errorPatternsPrompt;
      } catch (_) {}
    }

    // --- Chunked generation with scoring between chunks ---
    // Break the total word target into scored chunks.
    // After each chunk, halt and score the prose, then continue.
    const CHUNK_SIZE = 1000;
    const maxTokensPerChunk = 4096; // ~1000 words
    let wordsGenerated = 0;
    let chunkNum = 0;
    let allStreamedText = '';
    let chunkScores = []; // Track per-chunk best scores for weighted average
    const generationSessionKey = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    // Show iterative overlay for the scoring phases
    const qualityThresholdDisplay = this._currentProject?.qualityThreshold || 90;
    this._showIterativeOverlay(true);
    this._showIterativeScoringNotice(false);
    this._updateIterativeScore(null);
    this._updateIterativeIteration(0, 0);
    // Update threshold display
    const thresholdLabelEl = document.getElementById('iterative-threshold-label');
    if (thresholdLabelEl) thresholdLabelEl.textContent = `Target: ${qualityThresholdDisplay}%`;
    const thresholdMarkerEl = document.getElementById('iterative-progress-threshold');
    if (thresholdMarkerEl) thresholdMarkerEl.style.left = qualityThresholdDisplay + '%';
    const logEl = document.getElementById('iterative-status-log');
    if (logEl) logEl.textContent = `Generating ~${wordTarget} words in scored chunks (threshold: ${qualityThresholdDisplay}%)\u2026`;

    while (wordsGenerated < wordTarget && !this._generateCancelled) {
      chunkNum++;
      const remaining = wordTarget - wordsGenerated;
      const thisChunkTarget = Math.min(CHUNK_SIZE, remaining);
      const isLastChunk = remaining <= CHUNK_SIZE;

      this._updateIterativeChunk(chunkNum);
      this._updateIterativePhase('Generating\u2026');
      this._updateIterativeLog(`Chunk ${chunkNum}: Generating ~${thisChunkTarget} words\u2026`);

      let streamedText = '';
      const currentExisting = this.editor.getContent();

      try {
        await new Promise((resolve, reject) => {
          if (this._generateCancelled) { resolve(); return; }

          this.generator.generate(
            {
              plot,
              existingContent: currentExisting,
              chapterTitle,
              characters,
              notes,
              chapterOutline,
              aiInstructions,
              tone,
              style,
              wordTarget: thisChunkTarget,
              maxTokens: maxTokensPerChunk,
              concludeStory: isLastChunk && concludeStory,
              genre,
              genreRules,
              projectGoal,
              voice: project?.voice || '',
              errorPatternsPrompt
            },
            {
              onChunk: (text) => {
                streamedText += text;
                streamedText = this._stripEmDashes(streamedText);
                const startingContent = currentExisting.trim() ? currentExisting : '';
                const paragraphs = streamedText.split('\n\n');
                const newHtml = paragraphs
                  .map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`)
                  .join('');
                editorEl.innerHTML = startingContent + newHtml;
                const container = editorEl.closest('.editor-area');
                if (container) container.scrollTop = container.scrollHeight;
                const wc = editorEl.textContent.match(/[a-zA-Z'''\u2019-]+/g) || [];
                const chapterWords = wc.length;
                const wordsEl = document.getElementById('status-words');
                if (wordsEl) wordsEl.textContent = chapterWords.toLocaleString();
                const fwcWords = document.getElementById('fwc-words');
                if (fwcWords) fwcWords.textContent = chapterWords.toLocaleString();
                this._updateLocalWordCounts(editorEl.innerHTML);
                this._trackDailyWords(chapterWords);
              },
              onDone: () => {
                // Format headings and scene breaks
                editorEl.innerHTML = this._formatGeneratedHtml(editorEl.innerHTML, chapterTitle);
                const content = this.editor.getContent();
                if (this.state.currentChapterId) {
                  this.fs.updateChapter(this.state.currentChapterId, { content }).catch(() => {});
                  this._updateLocalWordCounts(content);
                }
                resolve();
              },
              onError: (err) => reject(err)
            }
          );
        });
      } catch (err) {
        this._setGenerateStatus(false);
        this._showIterativeOverlay(false);
        this._autoWriteToGoal = false;
        this._writeToGoalTarget = 0;
        this._showPanel('generate');
        if (errEl) {
          errEl.style.display = 'block';
          errEl.textContent = err.message;
        }
        return;
      }

      if (this._generateCancelled) break;

      // Count words in this chunk
      const chunkWords = (streamedText.match(/[a-zA-Z'''\u2019-]+/g) || []).length;
      wordsGenerated += chunkWords;
      allStreamedText += streamedText;

      this._updateIterativeLog(`Chunk ${chunkNum}: Generated ${chunkWords} words (${wordsGenerated}/${wordTarget} total)`);

      // If chunk was too small or empty, stop to avoid infinite loop
      if (chunkWords < 10) break;

      // --- Prose CI/CD: Score, lint, patch with anti-regression ---
      if (streamedText.length > 50) {
        const qualityThreshold = this._currentProject?.qualityThreshold || 90;
        const MAX_CICD_ITERATIONS = 6;
        const MAX_SCORE_RETRIES = 2;
        let currentChunkText = streamedText;
        let chunkBestScore = 0;
        let chunkBestText = streamedText;
        let chunkIteration = 0;
        let chunkBestReview = null;
        let consecutiveNoImprovement = 0;

        // Reset iteration display for this chunk
        this._updateIterativeScore(null);
        this._updateIterativeIteration(0, 0);
        this._resetScoreHistory();
        this._chunkFixLists = [];

        // === PROSE CI/CD STEP 0: Calculate baseline voice fingerprint ===
        const baselineFingerprint = this.analyzer.calculateVoiceFingerprint(currentChunkText);
        this._updateIterativeLog(`Chunk ${chunkNum}: Voice fingerprint locked (mean: ${baselineFingerprint.sentenceLengthMean}, stddev: ${baselineFingerprint.sentenceLengthStdDev})`);

        // === PROSE CI/CD STEP 1: Generate Intent Ledger (locked for this chunk) ===
        let intentLedger = null;
        try {
          this._updateIterativePhase('Locking intent\u2026');
          this._updateIterativeLog(`Chunk ${chunkNum}: Generating intent ledger\u2026`);
          intentLedger = await this.generator.generateIntentLedger({
            plot, chapterOutline, characters, existingProse: currentChunkText, chapterTitle
          });
          this._updateIterativeLog(`Chunk ${chunkNum}: Intent locked (POV: ${intentLedger.povType}, tense: ${intentLedger.tense})`);
        } catch (err) {
          this._updateIterativeLog(`Chunk ${chunkNum}: Intent ledger generation failed: ${err.message}. Continuing without.`);
        }

        // === PROSE CI/CD STEP 2: Deterministic lint pass (no API call) ===
        let lintResult = this.analyzer.lintProse(currentChunkText);
        if (lintResult.defects.length > 0) {
          this._updateIterativeLog(`Chunk ${chunkNum}: Lint found ${lintResult.stats.hardDefects} hard + ${lintResult.stats.mediumDefects} medium defects`);
        }

        // === PROSE CI/CD ITERATION LOOP ===
        while (chunkIteration < MAX_CICD_ITERATIONS && !this._generateCancelled) {
          chunkIteration++;

          // --- Lane 1: Check hard lint defects first (deterministic, free) ---
          lintResult = this.analyzer.lintProse(currentChunkText);
          const hardDefects = lintResult.defects.filter(d => d.severity === 'hard');

          // --- Lane 2 + 3: Score via API ---
          this._updateIterativePhase('Scoring\u2026');
          this._showIterativeScoringNotice(true);
          this._updateIterativeLog(`Chunk ${chunkNum}: Scoring (iteration ${chunkIteration})\u2026`);

          let review = null;
          let scoreRetries = 0;
          while (scoreRetries <= MAX_SCORE_RETRIES) {
            try {
              review = await this.generator.scoreProse(currentChunkText, chunkIteration > 1 ? {
                isRewrite: true,
                previousIssueCount: (chunkBestReview?.issues?.length || 0) + (chunkBestReview?.aiPatterns?.length || 0)
              } : undefined);
            } catch (err) {
              this._updateIterativeLog(`Chunk ${chunkNum}: Scoring error: ${err.message}`);
              review = null;
            }
            if (review && review.score > 0) break;
            scoreRetries++;
            if (scoreRetries <= MAX_SCORE_RETRIES) {
              this._updateIterativeLog(`Chunk ${chunkNum}: Scoring returned 0, retrying (${scoreRetries}/${MAX_SCORE_RETRIES})\u2026`);
              await new Promise(r => setTimeout(r, 1500));
            }
          }
          this._showIterativeScoringNotice(false);
          if (this._generateCancelled) break;

          if (!review || review.score === 0) {
            this._updateIterativeLog(`Chunk ${chunkNum}: Scoring failed. Using current text.`);
            break;
          }

          const score = review.score;

          // Record errors to cross-project database (non-blocking)
          const issueCount = (review.issues?.length || 0) + (review.aiPatterns?.length || 0);
          if (this.errorDb && issueCount > 0) {
            this.errorDb.recordFromReview(review, {
              projectId: this.state.currentProjectId,
              chapterId: this.state.currentChapterId,
              chapterTitle, genre, sessionKey: generationSessionKey
            }).catch(() => {});
            try {
              errorPatternsPrompt = await this.errorDb.buildNegativePrompt({ maxPatterns: 20, minFrequency: 1 });
              this._cachedErrorPatternsPrompt = errorPatternsPrompt;
            } catch (_) {}
          }

          // Track best version
          if (score > chunkBestScore) {
            chunkBestScore = score;
            chunkBestText = currentChunkText;
            chunkBestReview = review;
            consecutiveNoImprovement = 0;
            this._chunkDegradationAnalysis = null;
          } else {
            consecutiveNoImprovement++;
            if (score < chunkBestScore && chunkIteration > 1) {
              // Deep analysis of why score dropped
              this._updateIterativeLog(`Chunk ${chunkNum}: Score dropped (${score} < best ${chunkBestScore}). Analyzing decline\u2026`);
              try {
                this._chunkDegradationAnalysis = await this.generator.compareProseVersions({
                  bestProse: chunkBestText,
                  bestScore: chunkBestScore,
                  bestSubscores: chunkBestReview?.subscores || {},
                  rewrittenProse: currentChunkText,
                  rewrittenScore: score,
                  rewrittenSubscores: review.subscores || {},
                  appliedFixes: this._chunkFixLists?.length > 0 ? this._chunkFixLists[this._chunkFixLists.length - 1] : null
                });
                this._updateIterativeLog(`Chunk ${chunkNum}: Decline root cause: ${this._chunkDegradationAnalysis.rootCause || 'unknown'}`);
              } catch (err) {
                this._updateIterativeLog(`Chunk ${chunkNum}: Decline analysis failed: ${err.message}`);
                this._chunkDegradationAnalysis = null;
              }
              currentChunkText = chunkBestText;
              if (chunkBestReview) review = chunkBestReview;
            }
          }

          // After revert, review.score reflects the best version's score
          const displayScore = review.score;
          this._updateIterativeScore(displayScore, true);
          this._recordIterationScore(chunkIteration, displayScore);
          this._updateIterativeIteration(chunkIteration, chunkBestScore);
          this._updateIterativeLog(`Chunk ${chunkNum}: Score = ${displayScore}/100 (${review.label || ''}) [threshold: ${qualityThreshold}] | Lint: ${hardDefects.length} hard defects`);

          // Check pass condition
          if (chunkBestScore >= qualityThreshold && hardDefects.length === 0) {
            this._updateIterativeLog(`Chunk ${chunkNum}: PASSED threshold (${qualityThreshold}%) with zero hard defects.`);
            await new Promise(r => setTimeout(r, 1000));
            break;
          }

          if (chunkIteration >= MAX_CICD_ITERATIONS) {
            this._updateIterativeLog(`Chunk ${chunkNum}: Max iterations (${MAX_CICD_ITERATIONS}) reached. Best: ${chunkBestScore}/100`);
            break;
          }

          // === PROSE CI/CD STEP 3: AI Self-Reflection ===
          this._updateIterativePhase('Reflecting on improvements\u2026');
          this._updateIterativeLog(`Chunk ${chunkNum}: AI reflecting — "How can I improve this prose to reach ${qualityThreshold}?"\u2026`);

          let fixList = null;
          try {
            fixList = await this.generator.reflectOnProse({
              prose: currentChunkText,
              score: chunkBestScore || score,
              subscores: review.subscores,
              threshold: qualityThreshold,
              issues: review.issues,
              aiPatterns: review.aiPatterns,
              iterationNum: chunkIteration,
              previousFixLists: this._chunkFixLists && this._chunkFixLists.length > 0 ? this._chunkFixLists : undefined,
              degradationAnalysis: this._chunkDegradationAnalysis || undefined
            });
          } catch (err) {
            this._updateIterativeLog(`Chunk ${chunkNum}: Reflection failed: ${err.message}`);
            break;
          }

          if (this._generateCancelled) break;

          if (!fixList || !fixList.fixes || fixList.fixes.length === 0) {
            this._updateIterativeLog(`Chunk ${chunkNum}: No fixes identified. Best: ${chunkBestScore}/100`);
            break;
          }

          this._updateIterativeLog(`Chunk ${chunkNum}: Reflection — ${fixList.reflection || 'Analysis complete'}`);
          this._updateIterativeLog(`Chunk ${chunkNum}: Fix list (${fixList.fixes.length} fixes): ${fixList.fixes.map(f => f.description.slice(0, 50)).join('; ')}`);

          // === PROSE CI/CD STEP 3.5: Pre-validate fixes before applying ===
          this._updateIterativePhase('Pre-validating fixes\u2026');
          this._updateIterativeLog(`Chunk ${chunkNum}: Pre-validating ${fixList.fixes.length} fixes\u2026`);

          let skipFixes = false;
          try {
            const cicdValidation = await this.generator.preValidateFixes({
              prose: currentChunkText,
              fixList,
              currentScore: chunkBestScore || score,
              subscores: review.subscores,
              threshold: qualityThreshold
            });
            this._updateIterativeLog(`Chunk ${chunkNum}: Pre-validation predicts ${cicdValidation.predictedScore} (${cicdValidation.confidence})`);

            if (cicdValidation.predictedScore <= (chunkBestScore || score)) {
              this._updateIterativeLog(`Chunk ${chunkNum}: Fixes predicted to not improve score. Skipping this iteration.`);
              skipFixes = true;
            }
          } catch (err) {
            this._updateIterativeLog(`Chunk ${chunkNum}: Pre-validation failed: ${err.message}. Proceeding.`);
          }

          if (this._generateCancelled) break;

          if (!this._chunkFixLists) this._chunkFixLists = [];
          this._chunkFixLists.push(fixList);

          if (skipFixes) continue;

          // === PROSE CI/CD STEP 4: Apply fix list ===
          this._updateIterativePhase(`Applying ${fixList.fixes.length} fixes\u2026`);

          const preChunkContent = currentExisting;
          let patchedText = '';
          try {
            await new Promise((resolve, reject) => {
              if (this._generateCancelled) { resolve(); return; }
              this.generator.applyFixList(
                {
                  originalProse: currentChunkText,
                  fixList,
                  chapterTitle, characters, notes, chapterOutline, aiInstructions,
                  tone, style,
                  wordTarget: thisChunkTarget,
                  maxTokens: maxTokensPerChunk,
                  genre, genreRules,
                  voice: project?.voice || '',
                  errorPatternsPrompt,
                  iterationNum: chunkIteration,
                  threshold: qualityThreshold
                },
                {
                  onChunk: (text) => {
                    patchedText += text;
                    patchedText = this._stripEmDashes(patchedText);
                    const startingContent = preChunkContent.trim() ? preChunkContent : '';
                    const paragraphs = patchedText.split('\n\n');
                    const newHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
                    editorEl.innerHTML = startingContent + newHtml;
                    const container = editorEl.closest('.editor-area');
                    if (container) container.scrollTop = container.scrollHeight;
                  },
                  onDone: () => {
                    const content = this.editor.getContent();
                    if (this.state.currentChapterId) {
                      this.fs.updateChapter(this.state.currentChapterId, { content }).catch(() => {});
                      this._updateLocalWordCounts(content);
                    }
                    resolve();
                  },
                  onError: (err) => reject(err)
                }
              );
            });
          } catch (err) {
            this._updateIterativeLog(`Chunk ${chunkNum}: Fix application failed: ${err.message}`);
            break;
          }

          if (this._generateCancelled) break;

          // === PROSE CI/CD STEP 5: Anti-regression check ===
          if (patchedText && patchedText.length > 20) {
            const preWords = (currentChunkText.match(/[a-zA-Z'''\u2019-]+/g) || []).length;
            const postWords = (patchedText.match(/[a-zA-Z'''\u2019-]+/g) || []).length;
            const wordCountDrift = Math.abs(postWords - preWords) / Math.max(preWords, 1);

            if (wordCountDrift > 0.25) {
              this._updateIterativeLog(`Chunk ${chunkNum}: Word count changed by ${Math.round(wordCountDrift * 100)}% (${preWords} \u2192 ${postWords}). Reverting.`);
              const startingContent = preChunkContent.trim() ? preChunkContent : '';
              const paragraphs = currentChunkText.split('\n\n');
              const revertHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
              editorEl.innerHTML = startingContent + revertHtml;
              if (this.state.currentChapterId) {
                this.fs.updateChapter(this.state.currentChapterId, { content: this.editor.getContent() }).catch(() => {});
              }
              consecutiveNoImprovement++;
            } else {
              currentChunkText = patchedText;
              this._updateIterativeLog(`Chunk ${chunkNum}: Fixes applied (words: ${postWords})`);
            }
          }
        }

        // Restore best version if different from current
        if (chunkBestText !== currentChunkText && chunkBestScore > 0) {
          this._updateIterativeLog(`Chunk ${chunkNum}: Restoring best version (score ${chunkBestScore}).`);
          const startingContent = currentExisting.trim() ? currentExisting : '';
          const paragraphs = chunkBestText.split('\n\n');
          const restoredHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
          editorEl.innerHTML = startingContent + restoredHtml;
          if (this.state.currentChapterId) {
            this.fs.updateChapter(this.state.currentChapterId, { content: this.editor.getContent() }).catch(() => {});
          }
        }

        this._updateIterativeLog(`Chunk ${chunkNum}: Complete. Best score: ${chunkBestScore}/100 (threshold: ${qualityThreshold})`);
        chunkScores.push({ score: chunkBestScore, words: chunkWords });
      }

      // Check if we should stop (close to target or generation cancelled)
      if (wordsGenerated >= wordTarget * 0.9) break;
    }

    // All chunks done
    this._setGenerateStatus(false);

    // Save final content
    const finalContent = this.editor.getContent();
    if (this.state.currentChapterId) {
      try {
        await this.fs.updateChapter(this.state.currentChapterId, { content: finalContent });
      } catch (_) {}
      this._updateLocalWordCounts(finalContent);
    }

    // Write to Goal: check if we need another chunk
    if (this._autoWriteToGoal && this._writeToGoalTarget > 0) {
      const currentTotal = this._getTotalWordCount();
      const goal = this._writeToGoalTarget;
      const maxOverage = this._writeToGoalMaxOverage || Math.round(goal * 0.03);
      const remaining = goal - currentTotal;

      if (remaining > maxOverage * -1 && remaining > 50) {
        this._showIterativeOverlay(false);
        const nextChunk = Math.min(remaining, 2000);
        const isLastChunkForGoal = remaining <= 2000;
        setTimeout(() => this._runGeneration({
          isContinuation: true,
          wordTarget: nextChunk,
          concludeStory: isLastChunkForGoal,
          writeToGoal: true
        }), 1500);
        return;
      } else {
        this._autoWriteToGoal = false;
        this._writeToGoalTarget = 0;
      }
    }

    // Final scoring of all generated prose against the threshold
    if (allStreamedText && allStreamedText.length > 100) {
      const finalThreshold = this._currentProject?.qualityThreshold || 90;

      // Calculate weighted average of chunk scores for consistency check
      let weightedAvg = 0;
      if (chunkScores.length > 0) {
        const totalChunkWords = chunkScores.reduce((s, c) => s + c.words, 0);
        weightedAvg = totalChunkWords > 0
          ? Math.round(chunkScores.reduce((s, c) => s + c.score * c.words, 0) / totalChunkWords)
          : Math.round(chunkScores.reduce((s, c) => s + c.score, 0) / chunkScores.length);
      }

      this._updateIterativePhase('Scoring complete work\u2026');
      this._updateIterativeLog(`All ${chunkNum} chunks complete (avg: ${weightedAvg}). Scoring full text against threshold (${finalThreshold}%)\u2026`);
      this._showIterativeScoringNotice(true);

      try {
        const finalReview = await this.generator.scoreProse(allStreamedText);
        this._showIterativeScoringNotice(false);

        if (finalReview && finalReview.score > 0) {
          let finalScore = finalReview.score;

          // If full-text score is significantly lower than the weighted chunk average,
          // use the chunk average as a floor (within 5 points) to prevent scoring inconsistency
          if (weightedAvg > 0 && finalScore < weightedAvg - 5) {
            const adjustedScore = weightedAvg - 3;
            this._updateIterativeLog(`Full-text score (${finalScore}) was inconsistent with chunk average (${weightedAvg}). Adjusted to ${adjustedScore}.`);
            finalScore = adjustedScore;
            finalReview.score = adjustedScore;
          }

          this._updateIterativeScore(finalScore);
          this._updateIterativeLog(`Final score: ${finalScore}/100 (threshold: ${finalThreshold})`);

          if (finalScore >= finalThreshold) {
            this._updateIterativeLog(`Full text passed threshold! Score: ${finalScore}/${finalThreshold}`);
          } else {
            this._updateIterativeLog(`Full text below threshold: ${finalScore}/${finalThreshold}. Review and fix options will be shown.`);
          }

          // Brief pause for user to see the final score
          await new Promise(r => setTimeout(r, 1500));
          this._showIterativeOverlay(false);

          // Record final review errors into the cross-project error database (session-aware)
          if (this.errorDb && ((finalReview.issues?.length || 0) + (finalReview.aiPatterns?.length || 0)) > 0) {
            this.errorDb.recordFromReview(finalReview, {
              projectId: this.state.currentProjectId,
              chapterId: this.state.currentChapterId,
              chapterTitle,
              genre,
              sessionKey: generationSessionKey
            }).catch(() => {});
          }

          // Show the full prose review with threshold context
          finalReview._qualityThreshold = finalThreshold;
          this._showProseReview(finalReview, allStreamedText);
        } else {
          this._showIterativeOverlay(false);
          this._scoreProse(allStreamedText);
        }
      } catch (err) {
        this._showIterativeScoringNotice(false);
        this._showIterativeOverlay(false);
        console.error('Final scoring failed:', err);
        this._scoreProse(allStreamedText);
      }
    } else {
      this._showIterativeOverlay(false);
    }

    this._showContinueBar(true);
  }

  _showContinueBar(show) {
    const bar = document.getElementById('continue-bar');
    if (bar) bar.style.display = show ? 'flex' : 'none';
  }

  _getTotalWordCount() {
    return Object.values(this._chapterWordCounts).reduce((sum, wc) => sum + wc, 0);
  }

  async _handleContinueWriting(wordTarget) {
    const project = this._currentProject;
    const totalWords = this._getTotalWordCount();
    const goal = project ? (project.wordCountGoal || 0) : 0;

    // Check if this generation would exceed the project word count goal
    if (goal > 0 && totalWords + wordTarget > goal) {
      const remaining = Math.max(0, goal - totalWords);
      const willExceed = remaining < wordTarget;

      if (willExceed && remaining > 0) {
        const proceed = confirm(
          `Your story has ${totalWords.toLocaleString()} words with a goal of ${goal.toLocaleString()}. ` +
          `Adding ~${wordTarget.toLocaleString()} words will exceed the goal.\n\n` +
          `Would you like the AI to write a conclusion to wrap up the story instead?`
        );
        if (proceed) {
          // User wants to wrap up — generate remaining words with conclusion instructions
          this._showContinueBar(false);
          this._lastGenSettings.wordTarget = wordTarget;
          await this._runGeneration({ isContinuation: true, concludeStory: true, wordTarget });
          return;
        }
        // User said no — generate normally without conclusion
      } else if (remaining <= 0) {
        const proceed = confirm(
          `Your story has already reached ${totalWords.toLocaleString()} words (goal: ${goal.toLocaleString()}). ` +
          `Continue writing anyway?`
        );
        if (!proceed) return;
      }
    }

    this._showContinueBar(false);
    if (this._lastGenSettings) this._lastGenSettings.wordTarget = wordTarget;
    await this._runGeneration({ isContinuation: true, wordTarget });
  }

  async _handleWriteToGoal() {
    const project = this._currentProject;
    if (!project) return;

    const totalWords = this._getTotalWordCount();
    const goal = project.wordCountGoal || 0;

    if (goal <= 0) {
      alert('No word count goal set for this project. Set one in Settings → Project Settings.');
      return;
    }

    const remaining = goal - totalWords;
    const maxOverage = Math.round(goal * 0.03); // 3% overage allowed

    if (remaining <= 0) {
      alert(`Your story has already reached ${totalWords.toLocaleString()} words (goal: ${goal.toLocaleString()}).`);
      return;
    }

    this._showContinueBar(false);

    // Generate in chunks, targeting the remaining word count
    // Each chunk targets min(remaining, 2000) words
    // The final chunk includes story conclusion instructions
    this._autoWriteToGoal = true;
    this._writeToGoalTarget = goal;
    this._writeToGoalMaxOverage = maxOverage;

    // Set the word target for this chunk
    const chunkSize = Math.min(remaining, 2000);
    if (this._lastGenSettings) this._lastGenSettings.wordTarget = chunkSize;

    // If remaining words fit in one chunk, include conclusion instructions
    const concludeStory = remaining <= 2000;
    await this._runGeneration({ isContinuation: true, wordTarget: chunkSize, concludeStory, writeToGoal: true });
  }

  _setGenerateStatus(active) {
    const statusEl = document.getElementById('generate-status');
    const cancelBtn = document.getElementById('btn-generate-cancel');
    const generateBtn = document.getElementById('btn-generate-prose');

    if (statusEl) statusEl.style.display = active ? 'block' : 'none';
    if (cancelBtn) cancelBtn.style.display = active ? '' : 'none';
    if (generateBtn) generateBtn.disabled = active;
  }

  _showScoringProgress(show) {
    const overlay = document.getElementById('scoring-progress-overlay');
    if (overlay) {
      if (show) {
        overlay.classList.add('visible');
      } else {
        overlay.classList.remove('visible');
      }
    }
  }

  async openSettingsPanel() {
    const body = document.getElementById('panel-settings-body');
    if (!body) return;

    body.innerHTML = this._renderSettings(this._currentProject);
    this._initApiKeyPinLock();

    // Render story structure into settings if project is open
    if (this._currentProject && this.state.currentProjectId) {
      const container = document.getElementById('settings-structure-container');
      if (container) {
        const totalWords = Object.values(this._chapterWordCounts).reduce((sum, wc) => sum + wc, 0);
        const templateId = await this.localStorage.getSetting('structureTemplate_' + this.state.currentProjectId, 'threeAct');
        const targetWords = this._currentProject.wordCountGoal || 80000;
        const guidance = this.structure.getPacingGuidance(templateId, targetWords, totalWords);
        const beats = this.structure.mapBeatsToManuscript(templateId, targetWords, totalWords);
        container.innerHTML = this._renderStructureInSettings(guidance, beats, this._currentProject, templateId);
      }
    }

    this._showPanel('settings');
  }

  async openErrorDatabasePanel() {
    const body = document.getElementById('panel-error-database-body');
    if (!body) return;

    body.innerHTML = '<div class="analysis-section"><p>Loading error patterns...</p></div>';
    this._showPanel('error-database');

    await this._renderErrorDatabasePanel();
  }

  async _renderErrorDatabasePanel() {
    const body = document.getElementById('panel-error-database-body');
    if (!body || !this.errorDb) return;

    const stats = await this.errorDb.getStats();
    const allPatterns = await this.errorDb.getPatterns({ minFrequency: 1, limit: 200 });

    const categoryLabels = {
      'pet-phrase': 'PET Phrases',
      'telling': 'Telling vs Showing',
      'cliche': 'Cliches',
      'weak-words': 'Weak/Filler Words',
      'passive': 'Passive Voice',
      'structure': 'Structural Issues',
      'pacing': 'Pacing Problems',
      'ai-pattern': 'AI Writing Patterns',
      'other': 'Other Issues'
    };

    const severityColors = {
      'high': 'var(--danger, #e94560)',
      'medium': 'var(--warning, #f0a500)',
      'low': 'var(--text-secondary, #999)'
    };

    let html = '';

    // Stats summary
    html += `<div class="analysis-section">`;
    html += `<h3>Database Overview</h3>`;
    html += `<p>The error pattern database tracks common prose problems found during AI scoring. These patterns are automatically used as "negative prompts" during prose generation to prevent repeating the same mistakes.</p>`;
    html += `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px;margin:12px 0;">`;
    html += `<div style="text-align:center;padding:12px;background:var(--bg-secondary,#1a1a2e);border-radius:8px;"><div style="font-size:24px;font-weight:700;color:var(--accent-primary,#4fc3f7);">${stats.totalPatterns}</div><div style="font-size:11px;color:var(--text-secondary,#999);">Unique Patterns</div></div>`;
    html += `<div style="text-align:center;padding:12px;background:var(--bg-secondary,#1a1a2e);border-radius:8px;"><div style="font-size:24px;font-weight:700;color:var(--accent-primary,#4fc3f7);">${stats.totalOccurrences}</div><div style="font-size:11px;color:var(--text-secondary,#999);">Total Occurrences</div></div>`;
    html += `<div style="text-align:center;padding:12px;background:var(--bg-secondary,#1a1a2e);border-radius:8px;"><div style="font-size:24px;font-weight:700;color:var(--accent-primary,#4fc3f7);">${stats.projectCount}</div><div style="font-size:11px;color:var(--text-secondary,#999);">Projects</div></div>`;
    html += `<div style="text-align:center;padding:12px;background:var(--bg-secondary,#1a1a2e);border-radius:8px;"><div style="font-size:24px;font-weight:700;color:var(--accent-primary,#4fc3f7);">${Object.keys(stats.categories).length}</div><div style="font-size:11px;color:var(--text-secondary,#999);">Categories</div></div>`;
    html += `</div>`;

    if (stats.totalPatterns === 0) {
      html += `<p style="color:var(--text-secondary,#999);margin-top:12px;">No error patterns recorded yet. Patterns are automatically captured during prose scoring. Generate and score some prose to start building your error database.</p>`;
    }
    html += `</div>`;

    // Category breakdown
    if (stats.totalPatterns > 0 && Object.keys(stats.categories).length > 0) {
      html += `<div class="analysis-section">`;
      html += `<h3>Categories</h3>`;
      for (const [cat, count] of Object.entries(stats.categories).sort((a, b) => b[1] - a[1])) {
        const label = categoryLabels[cat] || cat;
        const pct = Math.round((count / stats.totalPatterns) * 100);
        html += `<div style="display:flex;align-items:center;gap:8px;margin:6px 0;">`;
        html += `<span style="flex:1;font-size:13px;">${label}</span>`;
        html += `<span style="font-size:12px;color:var(--text-secondary,#999);">${count} patterns (${pct}%)</span>`;
        html += `<div style="width:100px;height:6px;background:var(--bg-secondary,#1a1a2e);border-radius:3px;overflow:hidden;"><div style="width:${pct}%;height:100%;background:var(--accent-primary,#4fc3f7);border-radius:3px;"></div></div>`;
        html += `</div>`;
      }
      html += `</div>`;
    }

    // Pattern list grouped by category
    if (allPatterns.length > 0) {
      const grouped = {};
      for (const p of allPatterns) {
        const cat = p.category || 'other';
        if (!grouped[cat]) grouped[cat] = [];
        grouped[cat].push(p);
      }

      html += `<div class="analysis-section">`;
      html += `<h3>All Patterns</h3>`;
      html += `<p style="font-size:12px;color:var(--text-secondary,#999);margin-bottom:8px;">Patterns seen 2+ times are included in negative prompts during generation. Click the dismiss button to exclude a pattern.</p>`;

      for (const [cat, items] of Object.entries(grouped).sort((a, b) => b[1].length - a[1].length)) {
        const label = categoryLabels[cat] || cat;
        html += `<div style="margin:16px 0 8px 0;font-weight:600;font-size:14px;color:var(--text-primary,#eee);">${label} (${items.length})</div>`;

        for (const item of items) {
          const sevColor = severityColors[item.severity] || severityColors.low;
          const freqBadge = item.frequency >= 2
            ? `<span style="background:var(--accent-primary,#4fc3f7);color:#000;padding:1px 6px;border-radius:8px;font-size:10px;font-weight:700;">${item.frequency}x</span>`
            : `<span style="color:var(--text-secondary,#999);font-size:10px;">${item.frequency}x</span>`;
          const activeLabel = item.frequency >= 2
            ? `<span style="color:var(--accent-primary,#4fc3f7);font-size:10px;margin-left:4px;">ACTIVE</span>`
            : '';

          html += `<div style="display:flex;align-items:flex-start;gap:8px;padding:8px;margin:4px 0;background:var(--bg-secondary,#1a1a2e);border-radius:6px;border-left:3px solid ${sevColor};" data-pattern-id="${item.id}">`;
          html += `<div style="flex:1;min-width:0;">`;
          if (item.text) {
            html += `<div style="font-size:12px;color:var(--text-secondary,#999);font-style:italic;margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">"${item.text}"</div>`;
          }
          html += `<div style="font-size:13px;color:var(--text-primary,#eee);">${item.problem}</div>`;
          html += `<div style="font-size:11px;color:var(--text-secondary,#999);margin-top:2px;">${freqBadge}${activeLabel} &middot; Impact: ~${item.estimatedImpact} pts &middot; ${item.severity}</div>`;
          html += `</div>`;
          html += `<button class="btn btn-sm error-db-dismiss-btn" data-pattern-id="${item.id}" style="flex-shrink:0;font-size:11px;padding:4px 8px;" title="Dismiss this pattern">&times;</button>`;
          html += `</div>`;
        }
      }
      html += `</div>`;
    }

    // Actions
    html += `<div class="analysis-section" style="display:flex;gap:8px;flex-wrap:wrap;">`;
    if (stats.totalPatterns > 0) {
      html += `<button class="btn btn-sm" id="btn-clear-error-db" style="border-color:var(--danger,#e94560);color:var(--danger,#e94560);">Clear All Patterns</button>`;
    }
    if (stats.dismissedPatterns > 0) {
      html += `<button class="btn btn-sm" id="btn-restore-dismissed">Restore ${stats.dismissedPatterns} Dismissed</button>`;
    }
    html += `</div>`;

    body.innerHTML = html;

    // Bind dismiss buttons
    body.querySelectorAll('.error-db-dismiss-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.dataset.patternId;
        if (id && this.errorDb) {
          await this.errorDb.dismissPattern(id);
          await this._renderErrorDatabasePanel();
        }
      });
    });

    // Bind clear all button
    document.getElementById('btn-clear-error-db')?.addEventListener('click', async () => {
      if (confirm('Clear all error patterns? This cannot be undone.')) {
        await this.errorDb.clearAll();
        await this._renderErrorDatabasePanel();
      }
    });

    // Bind restore dismissed button
    document.getElementById('btn-restore-dismissed')?.addEventListener('click', async () => {
      const allWithDismissed = await this.errorDb.storage.getAll('errorPatterns');
      for (const p of allWithDismissed) {
        if (p.dismissed) {
          await this.errorDb.restorePattern(p.id);
        }
      }
      await this._renderErrorDatabasePanel();
    });
  }

  _initApiKeyPinLock() {
    const hasPin = !!localStorage.getItem('genesis-api-pin');
    const lockedDiv = document.getElementById('api-key-locked');
    const unlockedDiv = document.getElementById('api-key-unlocked');
    if (!lockedDiv || !unlockedDiv) return;

    if (hasPin) {
      lockedDiv.style.display = 'block';
      unlockedDiv.style.display = 'none';
    } else {
      lockedDiv.style.display = 'none';
      unlockedDiv.style.display = 'block';
    }
  }

  _showPanel(panelId) {
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('visible'));
    document.getElementById('panel-overlay').classList.remove('visible');

    const panel = document.getElementById('panel-' + panelId);
    if (panel) {
      panel.classList.add('visible');
      document.getElementById('panel-overlay').classList.add('visible');
    }
  }

  _closeAllPanels() {
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('visible'));
    document.getElementById('panel-overlay').classList.remove('visible');
  }

  // ========================================
  //  Analysis Rendering
  // ========================================

  _renderAnalysis(analysis, score) {
    const sv = analysis.sentenceVariety;
    const bars = sv.lengths.slice(0, 80).map(len => {
      const height = Math.min(100, (len / 40) * 100);
      let cls = 'medium';
      if (len <= 8) cls = 'short';
      else if (len <= 18) cls = 'medium';
      else if (len <= 30) cls = 'long';
      else cls = 'very-long';
      return `<div class="sentence-bar ${cls}" style="height:${height}%" title="${len} words"></div>`;
    }).join('');

    return `
      <div class="analysis-section">
        <h3>Prose Score</h3>
        <div class="stat-card" style="text-align:center;padding:20px;">
          <div class="stat-value" style="font-size:2.5rem;">${score}</div>
          <div class="stat-label">${score >= 80 ? 'Excellent' : score >= 65 ? 'Good' : score >= 50 ? 'Needs Work' : 'Rough Draft'}</div>
          <div class="meter" style="margin-top:12px;">
            <div class="meter-fill ${score >= 70 ? 'good' : score >= 50 ? 'warning' : 'danger'}" style="width:${score}%"></div>
          </div>
        </div>
      </div>

      <div class="analysis-section">
        <h3>Counts</h3>
        <div class="stat-grid">
          <div class="stat-card">
            <div class="stat-value">${analysis.counts.words.toLocaleString()}</div>
            <div class="stat-label">Words</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${analysis.counts.sentences.toLocaleString()}</div>
            <div class="stat-label">Sentences</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${analysis.counts.paragraphs}</div>
            <div class="stat-label">Paragraphs</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${analysis.counts.pages}</div>
            <div class="stat-label">Pages</div>
          </div>
        </div>
      </div>

      <div class="analysis-section">
        <h3>Readability</h3>
        <div class="stat-grid">
          <div class="stat-card">
            <div class="stat-value">${analysis.readability.fleschKincaid}</div>
            <div class="stat-label">Flesch Score</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${analysis.readability.gradeLevel}</div>
            <div class="stat-label">Grade Level</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${analysis.readability.avgWordsPerSentence}</div>
            <div class="stat-label">Avg Words/Sent</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${analysis.readability.avgSyllablesPerWord}</div>
            <div class="stat-label">Avg Syllables</div>
          </div>
        </div>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-top:8px;">
          Best sellers typically score 60-80 on Flesch (grade 5-9). Your prose reads at grade ${analysis.readability.gradeLevel}.
        </p>
      </div>

      <div class="analysis-section">
        <h3>Sentence Variety</h3>
        <div class="sentence-bars">${bars}</div>
        <div class="stat-grid" style="margin-top:8px;">
          <div class="stat-card">
            <div class="stat-value">${sv.categories.short}</div>
            <div class="stat-label">Short (&le;8)</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${sv.categories.medium}</div>
            <div class="stat-label">Medium (9-18)</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${sv.categories.long}</div>
            <div class="stat-label">Long (19-30)</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${sv.categories.veryLong}</div>
            <div class="stat-label">Very Long (30+)</div>
          </div>
        </div>
        <div class="meter" style="margin-top:8px;">
          <div class="meter-fill ${sv.varietyScore >= 60 ? 'good' : sv.varietyScore >= 35 ? 'warning' : 'danger'}" style="width:${sv.varietyScore}%"></div>
        </div>
        <p style="font-size:0.8rem;color:var(--text-muted);">Variety score: ${sv.varietyScore}/100. Mix short punchy sentences with longer flowing ones.</p>
      </div>

      <div class="analysis-section">
        <h3>Passive Voice (${analysis.passiveVoice.percentage}%)</h3>
        <div class="meter">
          <div class="meter-fill ${analysis.passiveVoice.percentage <= 15 ? 'good' : analysis.passiveVoice.percentage <= 25 ? 'warning' : 'danger'}" style="width:${Math.min(100, analysis.passiveVoice.percentage * 2)}%"></div>
        </div>
        ${analysis.passiveVoice.instances.length > 0 ? `
          <div style="margin-top:8px;">
            ${analysis.passiveVoice.instances.slice(0, 5).map(p =>
              `<div class="word-tag" style="display:block;margin:4px 0;border-radius:var(--radius-sm);">
                <strong>${this._esc(p.phrase)}</strong> &mdash; <span style="color:var(--text-muted)">${this._esc(p.sentence)}...</span>
              </div>`
            ).join('')}
          </div>` : '<p style="font-size:0.8rem;color:var(--success);">No passive voice detected.</p>'}
      </div>

      ${analysis.wordChoice.weakWords.length > 0 ? `
      <div class="analysis-section">
        <h3>Weak / Filler Words</h3>
        <div class="word-list">
          ${analysis.wordChoice.weakWords.map(w =>
            `<span class="word-tag">${w.word} <span class="count">${w.count}</span></span>`
          ).join('')}
        </div>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-top:8px;">Consider replacing with stronger, more specific words.</p>
      </div>` : ''}

      ${analysis.wordChoice.filterWords.length > 0 ? `
      <div class="analysis-section">
        <h3>Filter Words (Show Don't Tell)</h3>
        <div class="word-list">
          ${analysis.wordChoice.filterWords.map(w =>
            `<span class="word-tag">${w.word} <span class="count">${w.count}</span></span>`
          ).join('')}
        </div>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-top:8px;">
          Filter words like "felt," "saw," and "noticed" create distance. Show the experience directly.
        </p>
      </div>` : ''}

      ${analysis.adverbs.list.length > 0 ? `
      <div class="analysis-section">
        <h3>Adverbs (${analysis.adverbs.percentage}%)</h3>
        <div class="word-list">
          ${analysis.adverbs.list.slice(0, 10).map(a =>
            `<span class="word-tag">${a.word} <span class="count">${a.count}</span></span>`
          ).join('')}
        </div>
      </div>` : ''}

      ${analysis.cliches.length > 0 ? `
      <div class="analysis-section">
        <h3>Cliches Found</h3>
        <div style="margin-top:4px;">
          ${analysis.cliches.map(c =>
            `<div class="word-tag" style="display:block;margin:4px 0;border-radius:var(--radius-sm);color:var(--danger);">
              "${c.phrase}" <span class="count">&times;${c.count}</span>
            </div>`
          ).join('')}
        </div>
      </div>` : ''}

      ${analysis.repetition.length > 0 ? `
      <div class="analysis-section">
        <h3>Overused Words</h3>
        <div class="word-list">
          ${analysis.repetition.slice(0, 10).map(r =>
            `<span class="word-tag">${r.word} <span class="count">${r.count} (${r.frequency}%)</span></span>`
          ).join('')}
        </div>
      </div>` : ''}

      <div class="analysis-section">
        <h3>Dialogue Ratio</h3>
        <div class="stat-grid">
          <div class="stat-card">
            <div class="stat-value">${Math.round(analysis.dialogue.ratio * 100)}%</div>
            <div class="stat-label">Dialogue</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${Math.round((1 - analysis.dialogue.ratio) * 100)}%</div>
            <div class="stat-label">Narrative</div>
          </div>
        </div>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-top:8px;">
          Best-selling fiction typically balances 20-50% dialogue with narrative.
        </p>
      </div>

      <div class="analysis-section">
        <h3>Lexical Diversity</h3>
        <div class="meter">
          <div class="meter-fill ${analysis.wordChoice.uniqueWordRatio >= 0.5 ? 'good' : 'warning'}" style="width:${analysis.wordChoice.uniqueWordRatio * 100}%"></div>
        </div>
        <p style="font-size:0.8rem;color:var(--text-muted);">
          ${Math.round(analysis.wordChoice.uniqueWordRatio * 100)}% unique words. Higher diversity suggests richer vocabulary.
        </p>
      </div>
    `;
  }

  // ========================================
  //  Structure Rendering
  // ========================================

  _renderStructure(guidance, beats, project, templateId) {
    const templates = this.structure.getTemplates();

    return `
      <div class="analysis-section">
        <h3>Structure Template</h3>
        <select class="form-input" id="structure-template-select" style="margin-bottom:12px;">
          ${templates.map(t =>
            `<option value="${t.id}" ${t.id === templateId ? 'selected' : ''}>${t.name} (${t.beatCount} beats)</option>`
          ).join('')}
        </select>
      </div>

      <div class="analysis-section">
        <h3>Progress</h3>
        <div class="stat-grid">
          <div class="stat-card">
            <div class="stat-value">${guidance.progress}%</div>
            <div class="stat-label">Complete</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${guidance.wordsRemaining.toLocaleString()}</div>
            <div class="stat-label">Words Remaining</div>
          </div>
        </div>
        <div class="meter" style="margin-top:12px;">
          <div class="meter-fill info" style="width:${guidance.progress}%"></div>
        </div>
      </div>

      <div class="analysis-section">
        <h3>Current Beat</h3>
        <div class="stat-card" style="text-align:left;">
          <div style="font-weight:600;color:var(--accent-primary);">${guidance.currentBeat.name}</div>
          <div style="font-size:0.85rem;color:var(--text-secondary);margin-top:4px;">${guidance.currentBeat.description}</div>
        </div>
        ${guidance.nextBeat ? `
        <div style="margin-top:12px;font-size:0.85rem;color:var(--text-muted);">
          Next: <strong>${guidance.nextBeat.name}</strong> in ~${guidance.wordsToNextBeat.toLocaleString()} words
        </div>` : ''}
      </div>

      <div class="analysis-section">
        <h3>Beat Sheet</h3>
        <div class="beat-sheet">
          ${beats.map(beat => `
            <div class="beat-item ${beat.isReached ? 'completed' : ''}">
              <div class="beat-title">${beat.name}</div>
              <div class="beat-desc">${beat.description}</div>
              <div class="beat-percent">${beat.percent}% &bull; ~${beat.targetWordPosition.toLocaleString()} words &bull; p.${beat.approximatePage}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  _renderStructureInSettings(guidance, beats, project, templateId) {
    const templates = this.structure.getTemplates();

    return `
      <select class="form-input" id="structure-template-select" style="margin-bottom:12px;">
        ${templates.map(t =>
          `<option value="${t.id}" ${t.id === templateId ? 'selected' : ''}>${t.name} (${t.beatCount} beats)</option>`
        ).join('')}
      </select>

      <div class="stat-grid" style="margin-bottom:12px;">
        <div class="stat-card">
          <div class="stat-value">${guidance.progress}%</div>
          <div class="stat-label">Complete</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${guidance.wordsRemaining.toLocaleString()}</div>
          <div class="stat-label">Words Remaining</div>
        </div>
      </div>
      <div class="meter" style="margin-bottom:12px;">
        <div class="meter-fill info" style="width:${guidance.progress}%"></div>
      </div>

      <div class="stat-card" style="text-align:left;margin-bottom:12px;">
        <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">Current Beat</div>
        <div style="font-weight:600;color:var(--accent-primary);">${guidance.currentBeat.name}</div>
        <div style="font-size:0.85rem;color:var(--text-secondary);margin-top:4px;">${guidance.currentBeat.description}</div>
        ${guidance.nextBeat ? `
        <div style="margin-top:8px;font-size:0.85rem;color:var(--text-muted);">
          Next: <strong>${guidance.nextBeat.name}</strong> in ~${guidance.wordsToNextBeat.toLocaleString()} words
        </div>` : ''}
      </div>

      <details style="margin-top:8px;">
        <summary style="cursor:pointer;font-size:0.85rem;color:var(--accent-primary);font-weight:600;">View Full Beat Sheet</summary>
        <div class="beat-sheet" style="margin-top:8px;">
          ${beats.map(beat => `
            <div class="beat-item ${beat.isReached ? 'completed' : ''}">
              <div class="beat-title">${beat.name}</div>
              <div class="beat-desc">${beat.description}</div>
              <div class="beat-percent">${beat.percent}% &bull; ~${beat.targetWordPosition.toLocaleString()} words &bull; p.${beat.approximatePage}</div>
            </div>
          `).join('')}
        </div>
      </details>
    `;
  }

  // ========================================
  //  Cover Image
  // ========================================

  _updateCoverDisplay() {
    const project = this._currentProject;
    const placeholder = document.getElementById('cover-placeholder');
    const img = document.getElementById('cover-image');
    const regenBtn = document.getElementById('btn-regenerate-cover');
    const editBtn = document.getElementById('btn-edit-cover');
    if (!placeholder || !img || !regenBtn) return;

    if (project?.coverImage) {
      placeholder.style.display = 'none';
      img.style.display = 'block';
      img.src = project.coverImage;
      regenBtn.style.cssText = 'display:block; width:100%; margin-top:6px;';
      if (editBtn) editBtn.style.cssText = 'display:block; width:100%; margin-top:6px;';
    } else {
      placeholder.style.display = '';
      img.style.display = 'none';
      img.src = '';
      regenBtn.style.cssText = 'display:none; width:100%; margin-top:6px;';
      if (editBtn) editBtn.style.cssText = 'display:none; width:100%; margin-top:6px;';
    }
  }

  async _generateCover(regenerate = false) {
    const project = this._currentProject;
    if (!project) return;

    if (!this.generator.hasApiKey()) {
      alert('Set your Anthropic API key in Settings first.');
      return;
    }

    // Show loading state
    const loading = document.getElementById('cover-loading');
    const placeholder = document.getElementById('cover-placeholder');
    if (loading) loading.style.display = '';
    if (placeholder) placeholder.style.display = 'none';

    try {
      // Gather prose excerpt from chapters
      const chapters = await this.fs.getProjectChapters(project.id);
      let proseExcerpt = '';
      for (const ch of chapters) {
        if (ch.content) {
          const text = ch.content.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
          proseExcerpt += text + ' ';
          if (proseExcerpt.length > 3000) break;
        }
      }

      // Gather characters
      const characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId) || [];

      // Step 1: Claude generates the image prompt
      const coverPrompt = await this.generator.generateCoverPrompt({
        title: project.title,
        genre: project.genre || '',
        proseExcerpt: proseExcerpt.trim(),
        characters
      });

      if (!coverPrompt) throw new Error('Failed to generate cover prompt.');

      let coverImage = null;

      // Step 2a: Try HuggingFace via Puter.js CORS-free fetch (best approach)
      if (!coverImage && this._hfToken) {
        try {
          if (loading) loading.textContent = 'Generating AI cover...';
          coverImage = await this.generator.generateCoverViaHF(coverPrompt, this._hfToken);
        } catch (err) {
          console.warn('HF via puter.net.fetch failed:', err.message);
        }
      }

      // Step 2b: Try Puter.js built-in image generation
      if (!coverImage) {
        try {
          if (loading) loading.textContent = 'Generating cover image...';
          coverImage = await this.generator.generateCoverWithPuter(coverPrompt);
        } catch (err) {
          console.warn('Puter cover generation failed:', err.message);
        }
      }

      // Step 2c: Try Hugging Face via CORS proxy (corsproxy.io)
      if (!coverImage && this._hfToken) {
        try {
          if (loading) loading.textContent = 'Generating cover image...';
          coverImage = await this.generator.generateCoverImage(coverPrompt, this._hfToken);
        } catch (err) {
          console.warn('HF via CORS proxy failed:', err.message);
        }
      }

      // Save base image (without text) for the cover editor
      let coverImageBase = coverImage || null;

      // Overlay title (and subtitle if set) on AI-generated cover
      if (coverImage) {
        coverImage = await this.generator.overlayTitle(coverImage, project.title, project.subtitle || '');
      }

      // Step 2d: Canvas fallback (always works, has its own title rendering)
      if (!coverImage) {
        console.warn('AI image sources failed, using canvas fallback');
        const design = this.generator.getDefaultCoverDesign(project.genre);
        // Render fallback without text for base image
        coverImageBase = this.generator.renderCover(design, '', '');
        coverImage = this.generator.renderCover(design, project.title, project.owner);
      }

      // Save to Firestore (include base image for cover editor)
      await this.fs.updateProject(project.id, { coverImage, coverImageBase, coverPrompt });
      this._currentProject.coverImage = coverImage;
      this._currentProject.coverImageBase = coverImageBase;
      this._currentProject.coverPrompt = coverPrompt;

      // Update display
      this._updateCoverDisplay();
    } catch (err) {
      console.error('Cover generation failed:', err);
      alert('Cover generation failed: ' + err.message);
      if (placeholder) placeholder.style.display = '';
    } finally {
      if (loading) {
        loading.style.display = 'none';
        loading.textContent = 'Generating...';
      }
    }
  }

  _downloadCover() {
    const project = this._currentProject;
    if (!project?.coverImage) return;

    if (project.coverImage.startsWith('data:')) {
      // Base64 data URL — direct download
      const a = document.createElement('a');
      a.href = project.coverImage;
      a.download = `${project.title || 'cover'} - cover.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      // External URL — open in new tab
      window.open(project.coverImage, '_blank');
    }
  }

  // ========================================
  //  Settings Rendering
  // ========================================

  _renderSettings(project) {
    return `
      <div class="analysis-section">
        <h3>Appearance</h3>
        <div class="form-group">
          <label data-tooltip="Choose your editor color scheme. Dark reduces eye strain for nighttime writing. Light provides a clean daytime look. Sepia gives a warm, paper-like feel that's easy on the eyes.">Theme</label>
          <select class="form-input" id="setting-theme">
            <option value="dark" ${this.state.theme === 'dark' ? 'selected' : ''}>Dark</option>
            <option value="light" ${this.state.theme === 'light' ? 'selected' : ''}>Light</option>
            <option value="sepia" ${this.state.theme === 'sepia' ? 'selected' : ''}>Sepia</option>
          </select>
        </div>
      </div>

      <div class="analysis-section">
        <h3>AI Prose Generation</h3>
        <div class="form-group">
          <label data-tooltip="Your Anthropic API key enables AI prose generation, story analysis, and structure analysis. The key is stored only on this device and is sent directly to Anthropic's API — never to any other server. You can protect it with a PIN below.">Anthropic API Key</label>
          <div id="api-key-locked" style="display:none;">
            <div style="display:flex;gap:8px;align-items:center;">
              <input type="password" class="form-input" id="api-key-pin-input" data-tooltip="Enter the PIN you set to unlock and view or change your API key." placeholder="Enter PIN to unlock" style="flex:1;">
              <button class="btn btn-sm" id="api-key-unlock-btn" data-tooltip="Unlock — Verify your PIN to access the API key field.">Unlock</button>
            </div>
            <p style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">API key is PIN-protected.</p>
          </div>
          <div id="api-key-unlocked">
            <input type="password" class="form-input" id="setting-api-key" data-tooltip="Paste your Anthropic API key here. It starts with 'sk-ant-'. Get one free at console.anthropic.com. Usage is billed directly to your Anthropic account." value="${this._esc(this.generator?.apiKey || '')}" placeholder="sk-ant-...">
            <p style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">
              Get your key at <a href="https://console.anthropic.com/settings/keys" target="_blank" style="color:var(--accent-primary);">console.anthropic.com</a>. Stored locally on this device only.
            </p>
            <div style="margin-top:8px;display:flex;gap:8px;align-items:center;">
              <input type="password" class="form-input" id="api-key-set-pin" data-tooltip="Set a PIN code (at least 4 characters) to protect your API key. When locked, the key cannot be viewed or changed without entering the correct PIN. Useful on shared devices." placeholder="${localStorage.getItem('genesis-api-pin') ? 'New PIN (leave blank to keep)' : 'Set a PIN to lock (optional)'}" style="flex:1;">
              <button class="btn btn-sm" id="api-key-lock-btn" data-tooltip="${localStorage.getItem('genesis-api-pin') ? 'Update PIN — Change your existing PIN to a new one.' : 'Set PIN — Protect your API key with a PIN code so others cannot view or change it.'}">${localStorage.getItem('genesis-api-pin') ? 'Update PIN' : 'Set PIN'}</button>
              ${localStorage.getItem('genesis-api-pin') ? '<button class="btn btn-sm" id="api-key-remove-pin" data-tooltip="Remove PIN — Remove PIN protection from your API key. Anyone with access to this device will be able to view and change the key.">Remove PIN</button>' : ''}
            </div>
          </div>
        </div>
        <div class="form-group">
          <label data-tooltip="Choose which Claude AI model powers prose generation and analysis. Sonnet 4.5 is the best balance of quality, speed, and cost — recommended for most writers. Haiku 4.5 is faster and cheaper but produces slightly less polished prose. Opus 4.6 produces the highest quality literary prose but is slower and costs more per generation.">AI Model</label>
          <select class="form-input" id="setting-ai-model">
            <option value="claude-sonnet-4-5-20250929" ${this.generator?.model === 'claude-sonnet-4-5-20250929' ? 'selected' : ''}>Claude Sonnet 4.5 (recommended)</option>
            <option value="claude-haiku-4-5-20251001" ${this.generator?.model === 'claude-haiku-4-5-20251001' ? 'selected' : ''}>Claude Haiku 4.5 (faster, cheaper)</option>
            <option value="claude-opus-4-6" ${this.generator?.model === 'claude-opus-4-6' ? 'selected' : ''}>Claude Opus 4.6 (highest quality)</option>
          </select>
        </div>
        <button class="btn btn-sm" id="save-api-settings" data-tooltip="Save your API key and AI model selection. These settings apply to all projects." style="width:100%;">Save AI Settings</button>
      </div>

      <div class="analysis-section">
        <h3>Cover Image Generation</h3>
        <div class="form-group">
          <label data-tooltip="Your Hugging Face API token enables AI-generated book cover images using Stable Diffusion XL and FLUX models. Free tokens are available at huggingface.co/settings/tokens. The cover generator analyzes your story's content and genre to create a unique cover image.">Hugging Face API Token</label>
          <input type="password" class="form-input" id="setting-hf-token" data-tooltip="Paste your Hugging Face API token here. It starts with 'hf_'. Free tokens have generous rate limits for image generation." value="${this._esc(this._hfToken || '')}" placeholder="hf_...">
          <p style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">
            Free token from <a href="https://huggingface.co/settings/tokens" target="_blank" style="color:var(--accent-primary);">huggingface.co</a>. Used for AI cover art (FLUX / Stable Diffusion).
          </p>
        </div>
        <button class="btn btn-sm" id="save-hf-settings" data-tooltip="Save your Hugging Face token. Once saved, use 'Create Cover' or 'Regenerate Cover' in the sidebar to generate AI cover art." style="width:100%;">Save Cover Settings</button>
      </div>

      <div class="analysis-section">
        <h3>Writing Goals</h3>
        <div class="form-group">
          <label data-tooltip="Set your daily writing target in words. Your progress toward this goal is tracked in the status bar at the bottom of the screen and resets each day at midnight. A consistent daily goal helps build a productive writing habit.">Daily Word Goal</label>
          <input type="number" class="form-input" id="setting-daily-goal" data-tooltip="Enter your daily word count target. Common goals: 500 (casual), 1000 (steady), 2000 (ambitious), 5000+ (NaNoWriMo pace)." value="${this.state.dailyGoal}" min="100" step="100">
        </div>
      </div>

      ${project ? `
      <div class="analysis-section">
        <h3>Project Settings</h3>
        <div class="form-group">
          <label data-tooltip="The title of your book or manuscript. This appears in the project list, on the AI-generated cover image, and in exported manuscripts.">Project Title</label>
          <input type="text" class="form-input" id="setting-project-name" value="${this._esc(project.title)}">
        </div>
        <div class="form-group">
          <label data-tooltip="Select your project's literary genre. The AI uses genre-specific prose style rules to maintain consistent tone, pacing, and conventions throughout your manuscript. This prevents style drift during long writing sessions.">Genre</label>
          <select class="form-input" id="setting-project-genre">
            <option value="">— Select Genre —</option>
            ${(window.GENRE_DATA || []).map(g => `<option value="${g.id}" ${(project.genre === g.id) ? 'selected' : ''}>${g.label}</option>`).join('')}
          </select>
        </div>
        <div class="form-group" id="subgenre-group" style="${project.subgenre ? '' : 'display:none;'}">
          <label data-tooltip="Refine your genre selection with a subgenre. Subgenres provide more specific prose style rules — for example, 'Cozy Mystery' vs 'Noir' produce very different writing styles. The AI will follow these specialized rules.">Subgenre</label>
          <select class="form-input" id="setting-project-subgenre">
            <option value="">— None (use main genre rules) —</option>
            ${this._getSubgenreOptions(project.genre, project.subgenre)}
          </select>
        </div>
        <div class="form-group">
          <label data-tooltip="Select the narrative voice and point of view for AI-generated prose. This controls whether the AI writes in first person, third person limited, omniscient, deep POV, and other narrative perspectives. 'Auto' lets the AI choose based on context.">Narrative Voice / POV</label>
          <select class="form-input" id="setting-project-voice">
            <option value="auto" ${(!project.voice || project.voice === 'auto') ? 'selected' : ''}>Auto (AI chooses based on context)</option>
            <option value="first-person" ${project.voice === 'first-person' ? 'selected' : ''}>First Person (I/me/my)</option>
            <option value="third-limited" ${project.voice === 'third-limited' ? 'selected' : ''}>Third-Person Limited</option>
            <option value="third-omniscient" ${project.voice === 'third-omniscient' ? 'selected' : ''}>Third-Person Omniscient</option>
            <option value="third-objective" ${project.voice === 'third-objective' ? 'selected' : ''}>Third-Person Objective (camera eye)</option>
            <option value="deep-pov" ${project.voice === 'deep-pov' ? 'selected' : ''}>Deep POV (close third-person)</option>
            <option value="second-person" ${project.voice === 'second-person' ? 'selected' : ''}>Second Person (you/your)</option>
            <option value="unreliable" ${project.voice === 'unreliable' ? 'selected' : ''}>Unreliable Narrator</option>
            <option value="multiple-pov" ${project.voice === 'multiple-pov' ? 'selected' : ''}>Multiple POV (rotating perspectives)</option>
            <option value="stream-of-consciousness" ${project.voice === 'stream-of-consciousness' ? 'selected' : ''}>Stream of Consciousness</option>
            <option value="epistolary" ${project.voice === 'epistolary' ? 'selected' : ''}>Epistolary (letters/documents/diary)</option>
          </select>
          <p style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">Controls the narrative perspective for all AI-generated prose in this project.</p>
        </div>
        <button class="btn btn-primary" id="save-project-settings" data-tooltip="Save changes to the project title, genre, and voice settings." style="width:100%;margin-top:8px;">Save Project Settings</button>
        <p style="font-size:0.75rem;color:var(--text-muted);margin-top:6px;">Word count goal and chapter structure are configured in the Book Structure panel (sidebar).</p>
      </div>

      <div class="analysis-section">
        <h3>Story Structure</h3>
        <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:10px;">
          Select a narrative structure template to guide your story's pacing and beat progression. Choose "User / AI Created Outline" if your story doesn't follow a traditional structure (e.g., biographies, non-fiction, or custom outlines).
        </p>
        <div id="settings-structure-container"></div>
      </div>

      <div class="analysis-section">
        <h3>Data</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button class="btn btn-sm" id="btn-export-json" data-tooltip="Export a complete JSON backup of this project including all chapters, characters, notes, cover image, and settings. Use for backups or transferring your project to another device.">Backup (JSON)</button>
        </div>
      </div>

      <div class="analysis-section">
        <h3>Danger Zone</h3>
        <button class="btn btn-sm" id="btn-delete-project" data-tooltip="Permanently delete this entire project and all its contents: chapters, characters, notes, and cover image. This action cannot be undone. You will be asked to confirm before deletion." style="border-color:var(--danger);color:var(--danger);">Delete Project</button>
      </div>
      ` : ''}
    `;
  }

  // ========================================
  //  Book Structure Panel
  // ========================================

  async openBookStructurePanel() {
    const project = this._currentProject;
    if (!project) return;

    const titleEl = document.getElementById('bs-title');
    const subtitleEl = document.getElementById('bs-subtitle');
    const totalWordsEl = document.getElementById('bs-total-words');
    const numChaptersEl = document.getElementById('bs-num-chapters');

    if (titleEl) titleEl.value = project.title || '';
    if (subtitleEl) subtitleEl.value = project.subtitle || '';
    if (totalWordsEl) totalWordsEl.value = project.wordCountGoal || 80000;

    const thresholdEl = document.getElementById('bs-quality-threshold');
    if (thresholdEl) thresholdEl.value = project.qualityThreshold || 90;

    // Calculate num chapters from existing or default
    const chapters = await this.fs.getProjectChapters(this.state.currentProjectId);
    const numCh = project.numChapters || chapters.length || 20;
    if (numChaptersEl) numChaptersEl.value = numCh;

    this._updateWordsPerChapter();
    this._showPanel('book-structure');
  }

  _updateWordsPerChapter() {
    const totalWords = parseInt(document.getElementById('bs-total-words')?.value) || 80000;
    const numChapters = parseInt(document.getElementById('bs-num-chapters')?.value) || 20;
    const wpc = Math.round(totalWords / numChapters);
    const el = document.getElementById('bs-words-per-chapter');
    if (el) el.textContent = wpc.toLocaleString();
  }

  async _saveBookStructure() {
    if (!this.state.currentProjectId) return;

    const title = document.getElementById('bs-title')?.value?.trim();
    const subtitle = document.getElementById('bs-subtitle')?.value?.trim() || '';
    const wordCountGoal = parseInt(document.getElementById('bs-total-words')?.value) || 80000;
    const numChapters = parseInt(document.getElementById('bs-num-chapters')?.value) || 20;
    const qualityThreshold = Math.max(50, Math.min(100, parseInt(document.getElementById('bs-quality-threshold')?.value) || 90));

    try {
      await this.fs.updateProject(this.state.currentProjectId, {
        title, subtitle, wordCountGoal, numChapters, qualityThreshold
      });

      this._currentProject = { ...this._currentProject, title, subtitle, wordCountGoal, numChapters, qualityThreshold };
      document.getElementById('project-title').textContent = title;
      this._updateStatusBarLocal();
      alert('Book structure saved.');
    } catch (err) {
      console.error('Failed to save book structure:', err);
      alert('Failed to save book structure.');
    }
  }

  async _generateOutlines() {
    if (!this.state.currentProjectId || !this._currentProject) return;

    const project = this._currentProject;
    if (!this.generator.hasApiKey()) {
      alert('Set your Anthropic API key in Settings first.');
      return;
    }

    const numChapters = parseInt(document.getElementById('bs-num-chapters')?.value) || project.numChapters || 20;
    const totalWords = parseInt(document.getElementById('bs-total-words')?.value) || project.wordCountGoal || 80000;
    const title = document.getElementById('bs-title')?.value?.trim() || project.title;
    const subtitle = document.getElementById('bs-subtitle')?.value?.trim() || project.subtitle || '';

    // Gather characters
    const characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId) || [];

    // Gather notes
    const projectNotes = await this.localStorage.getProjectNotes(this.state.currentProjectId) || [];
    let notes = '';
    if (projectNotes.length > 0) {
      notes = projectNotes.map(n => {
        let entry = n.title;
        if (n.type && n.type !== 'general') entry = `[${n.type}] ${entry}`;
        if (n.content) entry += '\n' + n.content;
        return entry;
      }).join('\n\n');
    }

    // Append project knowledge base as reference materials
    const knowledgePromptOutline = await this._getProjectKnowledge();
    if (knowledgePromptOutline) {
      notes = notes ? notes + '\n\n' + knowledgePromptOutline : knowledgePromptOutline;
    }

    const aiInstructions = project.aiInstructions || '';
    const genreInfo = this._getGenreRules(project.genre, project.subgenre);
    const genre = genreInfo ? genreInfo.label : (project.genre || '');

    // Show loading state
    const statusEl = document.getElementById('bs-outline-status');
    const errorEl = document.getElementById('bs-outline-error');
    const genBtn = document.getElementById('btn-generate-outlines');
    if (statusEl) statusEl.style.display = '';
    if (errorEl) { errorEl.style.display = 'none'; errorEl.textContent = ''; }
    if (genBtn) genBtn.disabled = true;

    try {
      const outlines = await this.generator.generateOutlines({
        title, subtitle, genre, totalWords, numChapters, characters, notes, aiInstructions
      });

      if (!outlines || !Array.isArray(outlines) || outlines.length === 0) {
        throw new Error('No outlines were generated.');
      }

      // Save book structure first
      await this.fs.updateProject(this.state.currentProjectId, {
        title, subtitle, wordCountGoal: totalWords, numChapters
      });
      this._currentProject = { ...this._currentProject, title, subtitle, wordCountGoal: totalWords, numChapters };

      // Create chapters from outlines
      for (let i = 0; i < outlines.length; i++) {
        const outline = outlines[i];
        const ch = await this.fs.createChapter({
          projectId: this.state.currentProjectId,
          chapterNumber: i + 1,
          title: outline.title || `Chapter ${i + 1}`,
          content: '',
          outline: outline.outline || ''
        });
        this._chapterWordCounts[ch.id] = 0;
      }

      // Refresh chapter list and load first chapter
      await this._renderChapterList();
      const chapters = await this.fs.getProjectChapters(this.state.currentProjectId);
      if (chapters.length > 0) {
        await this._loadChapter(chapters[0].id);
      }

      document.getElementById('project-title').textContent = title;
      this._updateStatusBarLocal();
      this._closeAllPanels();
      alert(`Generated ${outlines.length} chapter outlines. Review each chapter's outline in the editor.`);
    } catch (err) {
      console.error('Outline generation failed:', err);
      if (errorEl) {
        errorEl.style.display = '';
        errorEl.textContent = err.message;
      }
    } finally {
      if (statusEl) statusEl.style.display = 'none';
      if (genBtn) genBtn.disabled = false;
    }
  }

  // ========================================
  //  Rethink Chapter Outline
  // ========================================

  async _openRethinkModal() {
    if (!this.state.currentChapterId) {
      alert('No chapter selected.');
      return;
    }

    const chapter = await this.fs.getChapter(this.state.currentChapterId);
    if (!chapter?.outline) {
      alert('This chapter has no outline to rethink. Generate outlines first from the Book Structure panel.');
      return;
    }

    document.getElementById('rethink-prompt').value = '';
    document.getElementById('rethink-status').style.display = 'none';
    const overlay = document.getElementById('rethink-overlay');
    if (overlay) overlay.classList.add('visible');
  }

  async _submitRethink() {
    const userInstructions = document.getElementById('rethink-prompt')?.value?.trim();
    if (!userInstructions) {
      alert('Please enter instructions for how to revise the outline.');
      return;
    }

    const chapter = await this.fs.getChapter(this.state.currentChapterId);
    if (!chapter?.outline) return;

    const project = this._currentProject;
    const characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId) || [];
    const projectNotes = await this.localStorage.getProjectNotes(this.state.currentProjectId) || [];
    let notes = projectNotes.map(n => {
      let entry = n.title;
      if (n.content) entry += '\n' + n.content;
      return entry;
    }).join('\n\n');

    const genreInfo = this._getGenreRules(project?.genre, project?.subgenre);

    document.getElementById('rethink-status').style.display = '';
    document.getElementById('btn-rethink-submit').disabled = true;

    try {
      const revisedOutline = await this.generator.rethinkOutline({
        currentOutline: chapter.outline,
        chapterTitle: chapter.title,
        userInstructions,
        bookTitle: project?.title || '',
        genre: genreInfo?.label || '',
        characters,
        notes
      });

      if (revisedOutline) {
        await this.fs.updateChapter(this.state.currentChapterId, { outline: revisedOutline });
        // Close modal and reload chapter
        document.getElementById('rethink-overlay').classList.remove('visible');
        await this._loadChapter(this.state.currentChapterId);
        alert('Chapter outline has been revised.');
      }
    } catch (err) {
      console.error('Rethink failed:', err);
      alert('Rethink failed: ' + err.message);
    } finally {
      document.getElementById('rethink-status').style.display = 'none';
      document.getElementById('btn-rethink-submit').disabled = false;
    }
  }

  // ========================================
  //  Prose Quality Scoring
  // ========================================

  async _scoreProse(generatedText) {
    if (!this.generator.hasApiKey()) return;
    if (!generatedText || generatedText.length < 100) return;

    // Reset rewrite iteration counter for fresh generations
    this._rewriteIteration = 0;
    this._previousRewriteScore = null;
    this._previousRewriteIssueCount = null;
    this._previousRewriteText = null;

    // Show scoring progress bar
    this._showScoringProgress(true);

    try {
      const review = await this.generator.scoreProse(generatedText);
      this._showScoringProgress(false);

      // Record errors to the cross-project error pattern database
      if (this.errorDb && review && ((review.issues?.length || 0) + (review.aiPatterns?.length || 0)) > 0) {
        this.errorDb.recordFromReview(review, {
          projectId: this.state.currentProjectId,
          chapterId: this.state.currentChapterId,
          genre: this._currentProject?.genre || ''
        }).catch(() => {});
      }

      this._showProseReview(review, generatedText);
    } catch (err) {
      this._showScoringProgress(false);
      console.error('Prose scoring failed:', err);
    }
  }

  async _scoreProseAfterRewrite(generatedText, previousScore, previousIssueCount, previousSubscores) {
    if (!this.generator.hasApiKey()) return;
    if (!generatedText || generatedText.length < 100) return;

    // Show scoring progress bar
    this._showScoringProgress(true);

    try {
      const review = await this.generator.scoreProse(generatedText, {
        isRewrite: true,
        previousIssueCount,
        previousScore,
        previousSubscores
      });

      // Add comparison data to the review for display
      review._previousScore = previousScore;
      review._rewriteIteration = this._rewriteIteration;
      review._previousIssueCount = previousIssueCount;

      // Detect convergence: score didn't improve meaningfully
      const scoreDelta = review.score - previousScore;
      const newIssueCount = (review.issues?.length || 0) + (review.aiPatterns?.length || 0);

      if (scoreDelta <= 1 && this._rewriteIteration >= 2) {
        review._convergenceWarning = true;
      }

      // If score dropped, automatically revert to the previous version
      // This is the key safeguard: rewrites should never make things worse
      if (scoreDelta < 0 && this._previousRewriteText) {
        review._scoreDecreased = true;
        review._revertedToPrevious = true;

        // Restore the previous (better-scoring) text
        const baseContent = this._preGenerationContent || '';
        const editorEl = this.editor.element;
        const paragraphs = this._previousRewriteText.split('\n\n');
        const restoredHtml = paragraphs
          .map(p => {
            const lines = p.replace(/\n/g, '<br>');
            return `<p>${lines}</p>`;
          })
          .join('');
        editorEl.innerHTML = (baseContent.trim() ? baseContent : '') + restoredHtml;

        // Save the reverted content
        if (this.state.currentChapterId) {
          try {
            await this.fs.updateChapter(this.state.currentChapterId, { content: this.editor.getContent() });
          } catch (_) {}
          this._updateLocalWordCounts(this.editor.getContent());
        }

        // Reset the generated text to the previous version
        this._lastGeneratedText = this._previousRewriteText;
      }

      this._showScoringProgress(false);

      // Record errors to the cross-project error pattern database
      if (this.errorDb && review && ((review.issues?.length || 0) + (review.aiPatterns?.length || 0)) > 0) {
        this.errorDb.recordFromReview(review, {
          projectId: this.state.currentProjectId,
          chapterId: this.state.currentChapterId,
          genre: this._currentProject?.genre || ''
        }).catch(() => {});
      }

      this._showProseReview(review, generatedText);
    } catch (err) {
      this._showScoringProgress(false);
      console.error('Prose scoring failed:', err);
    }
  }

  // ========================================
  //  Iterative Writing Engine
  // ========================================

  /**
   * Iterative Write: generates ~100 words, scores, rewrites until score >= 90,
   * then automatically continues to the next chunk. Repeats until cancelled.
   */
  async _iterativeWrite() {
    if (!this.generator.hasApiKey()) {
      alert('No API key set. Go to Settings to add your Anthropic API key.');
      return;
    }

    // Gather generation settings from the panel
    const plot = document.getElementById('generate-plot')?.value?.trim();
    if (!plot) {
      alert('Please enter a story plot or description.');
      return;
    }

    const tone = document.getElementById('generate-tone')?.value?.trim() || '';
    const style = document.getElementById('generate-style')?.value?.trim() || '';
    const useCharacters = document.getElementById('generate-use-characters')?.checked;
    const useNotes = document.getElementById('generate-use-notes')?.checked;

    // Store settings for the iterative session
    this._iterativeSettings = { plot, tone, style, useCharacters, useNotes };
    this._iterativeCancelled = false;
    this._iterativeChunkNum = 0;

    this._closeAllPanels();
    this._hideWelcome();

    // Start the iterative loop
    await this._iterativeWriteLoop();
  }

  async _iterativeWriteLoop() {
    if (this._iterativeCancelled) return;

    const settings = this._iterativeSettings;
    if (!settings) return;

    // Advance chunk counter
    this._iterativeChunkNum = (this._iterativeChunkNum || 0) + 1;

    // Reset stagnation tracking for new chunk
    this._iterativeNoImprovement = 0;
    this._iterativeBestReview = null;
    this._iterativeBestText = null;
    this._iterativeConsecutiveNoIssues = 0;

    // Show iterative writing overlay with fresh state for new chunk
    this._showIterativeOverlay(true);
    this._showIterativeScoringNotice(false);
    this._updateIterativeChunk(this._iterativeChunkNum);
    this._updateIterativePhase('Generating paragraph\u2026');
    this._updateIterativeScore(null);
    this._updateIterativeIteration(0, 0);
    this._resetScoreHistory();
    // Update threshold display
    const qualityThreshold = this._currentProject?.qualityThreshold || 90;
    const thresholdLabel = document.getElementById('iterative-threshold-label');
    if (thresholdLabel) thresholdLabel.textContent = `Target: ${qualityThreshold}%`;
    const thresholdMarker = document.getElementById('iterative-progress-threshold');
    if (thresholdMarker) thresholdMarker.style.left = qualityThreshold + '%';
    // Clear log for new chunk
    const logEl = document.getElementById('iterative-status-log');
    if (logEl) logEl.textContent = `Chunk ${this._iterativeChunkNum}: Generating ~100 words\u2026`;

    // Gather context
    const existingContent = this.editor.getContent();
    this._preGenerationContent = existingContent;

    let characters = [];
    if (settings.useCharacters && this.state.currentProjectId) {
      characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId);
    }

    let notes = '';
    if (settings.useNotes && this.state.currentProjectId) {
      const projectNotes = await this.localStorage.getProjectNotes(this.state.currentProjectId);
      if (projectNotes.length > 0) {
        notes = projectNotes.map(n => {
          let entry = n.title;
          if (n.type && n.type !== 'general') entry = `[${n.type}] ${entry}`;
          if (n.content) entry += '\n' + n.content;
          return entry;
        }).join('\n\n');
      }
    }

    // Append project knowledge base as reference materials
    const knowledgePrompt = await this._getProjectKnowledge();
    if (knowledgePrompt) {
      notes = notes ? notes + '\n\n' + knowledgePrompt : knowledgePrompt;
    }

    const aiInstructions = this._currentProject?.aiInstructions || '';
    let chapterTitle = '';
    if (this.state.currentChapterId) {
      try {
        const chapter = await this.fs.getChapter(this.state.currentChapterId);
        if (chapter) chapterTitle = chapter.title;
      } catch (_) {}
    }

    const project = this._currentProject;
    const genreId = project ? (project.genre || '') : '';
    const subgenreId = project ? (project.subgenre || '') : '';
    const genreInfo = this._getGenreRules(genreId, subgenreId);
    const chapterOutline = this._currentChapterOutline || '';

    // Generate ~100 words — hard limit via maxTokens to prevent overrun
    const editorEl = this.editor.element;
    let streamedText = '';

    try {
      await new Promise((resolve, reject) => {
        if (this._iterativeCancelled) { resolve(); return; }

        this.generator.generate(
          {
            plot: settings.plot + '\n\nCRITICAL CONSTRAINT: Write EXACTLY ONE PARAGRAPH of approximately 80-120 words. STOP after one paragraph. Do NOT write more than 150 words under any circumstances.',
            existingContent,
            chapterTitle,
            characters,
            notes,
            chapterOutline,
            aiInstructions,
            tone: settings.tone,
            style: settings.style,
            wordTarget: 100,
            maxTokens: 250,
            genre: genreInfo?.label || '',
            genreRules: genreInfo?.rules || '',
            projectGoal: project?.wordCountGoal || 0,
            voice: project?.voice || ''
          },
          {
            onChunk: (text) => {
              streamedText += text;
              streamedText = this._stripEmDashes(streamedText);
              const startingContent = existingContent.trim() ? existingContent : '';
              const paragraphs = streamedText.split('\n\n');
              const newHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
              editorEl.innerHTML = startingContent + newHtml;
              const container = editorEl.closest('.editor-area');
              if (container) container.scrollTop = container.scrollHeight;
              const wc = editorEl.textContent.match(/[a-zA-Z'''\u2019-]+/g) || [];
              const wordsEl = document.getElementById('status-words');
              if (wordsEl) wordsEl.textContent = wc.length.toLocaleString();
              const fwcWords = document.getElementById('fwc-words');
              if (fwcWords) fwcWords.textContent = wc.length.toLocaleString();
            },
            onDone: () => {
              // Format headings and scene breaks
              editorEl.innerHTML = this._formatGeneratedHtml(editorEl.innerHTML, chapterTitle);
              // Save generated content
              const content = this.editor.getContent();
              if (this.state.currentChapterId) {
                this.fs.updateChapter(this.state.currentChapterId, { content }).catch(() => {});
                this._updateLocalWordCounts(content);
              }
              resolve();
            },
            onError: (err) => reject(err)
          }
        );
      });
    } catch (err) {
      this._showIterativeOverlay(false);
      alert('Generation failed: ' + err.message);
      return;
    }

    if (this._iterativeCancelled || !streamedText || streamedText.length < 20) {
      this._showIterativeOverlay(false);
      return;
    }

    // Store the generated text for the iteration loop
    this._lastGeneratedText = streamedText;
    this._iterativeBestText = null;
    this._iterPrevScore = 0;
    this._iterPrevIssueCount = 0;
    this._iterPrevSubscores = {};
    // Unique session key to prevent duplicate error recording within the same iteration session
    this._iterativeSessionKey = `iter_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this._lastGenSettings = {
      plot: settings.plot, wordTarget: 100, tone: settings.tone,
      style: settings.style, useCharacters: settings.useCharacters,
      useNotes: settings.useNotes, chapterOutline
    };

    // Begin score-and-refine loop
    await this._iterativeScoreAndRefine(streamedText, 0, 0);
  }

  /**
   * Score the current paragraph and refine it using reflective AI analysis.
   * Uses a 3-iteration max approach:
   *   1. Score the prose
   *   2. If below threshold, ask AI to reflect: "How can I improve this? What fixes are needed?"
   *   3. Create and implement a fix list based on the reflection
   *   4. Score again and repeat reflection (max 3 iterations)
   */
  async _iterativeScoreAndRefine(currentText, iteration, bestScore) {
    if (this._iterativeCancelled) {
      this._showIterativeOverlay(false);
      return;
    }

    const MAX_ITERATIONS = 8;
    const MAX_SCORE_RETRIES = 2;
    const MAX_CONSECUTIVE_NO_IMPROVEMENT = 3;
    const qualityThreshold = this._currentProject?.qualityThreshold || 90;
    const previousFixLists = [];
    let workingText = currentText;
    let degradationAnalysis = null;
    let consecutiveNoImprovement = 0;
    let iterationHistory = []; // Track full history for final fix screen

    for (let iter = 1; iter <= MAX_ITERATIONS; iter++) {
      if (this._iterativeCancelled) {
        this._showIterativeOverlay(false);
        return;
      }

      // === STEP 1: Score the prose ===
      this._updateIterativePhase(`Scoring (iteration ${iter}/${MAX_ITERATIONS})\u2026`);
      this._showIterativeScoringNotice(true);
      this._updateIterativeIteration(iter, bestScore);
      this._updateIterativeLog(`Iteration ${iter}: Scoring\u2026`);

      let review = null;
      let scoreRetries = 0;
      while (scoreRetries <= MAX_SCORE_RETRIES) {
        try {
          review = await this.generator.scoreProse(workingText, iter > 1 ? {
            isRewrite: true,
            previousIssueCount: this._iterPrevIssueCount || 0
          } : undefined);
        } catch (err) {
          this._updateIterativeLog(`Scoring error: ${err.message}`);
          review = null;
        }
        if (review && review.score > 0) break;
        scoreRetries++;
        if (scoreRetries <= MAX_SCORE_RETRIES) {
          this._updateIterativeLog(`Scoring returned 0, retrying (${scoreRetries}/${MAX_SCORE_RETRIES})\u2026`);
          await new Promise(r => setTimeout(r, 1500));
        }
      }

      this._showIterativeScoringNotice(false);

      if (this._iterativeCancelled) {
        this._showIterativeOverlay(false);
        return;
      }

      if (!review || review.score === 0) {
        this._updateIterativeLog(`Scoring failed after ${MAX_SCORE_RETRIES + 1} attempts. Using best available version.`);
        break; // Fall through to final fix screen
      }

      const score = review.score;

      // Record errors to cross-project error pattern database
      const issueCount = (review.issues?.length || 0) + (review.aiPatterns?.length || 0);
      if (this.errorDb && issueCount > 0) {
        const sessionKey = this._iterativeSessionKey || null;
        this.errorDb.recordFromReview(review, {
          projectId: this.state.currentProjectId,
          chapterId: this.state.currentChapterId,
          genre: this._currentProject?.genre || '',
          sessionKey
        }).catch(() => {});
        this.errorDb.buildNegativePrompt({ maxPatterns: 20, minFrequency: 1 }).then(prompt => {
          this._cachedErrorPatternsPrompt = prompt;
        }).catch(() => {});
      }

      // Record iteration history
      iterationHistory.push({ iteration: iter, score, subscores: { ...review.subscores }, issueCount, text: workingText });

      // Track best version
      if (score > bestScore) {
        bestScore = score;
        this._iterativeBestText = workingText;
        this._iterativeBestReview = review;
        degradationAnalysis = null;
        consecutiveNoImprovement = 0;
      } else if (score < bestScore && this._iterativeBestText && iter > 1) {
        consecutiveNoImprovement++;
        // === DEEP COMPARATIVE ANALYSIS: Understand WHY score dropped ===
        this._updateIterativePhase('Deep analysis of score decline\u2026');
        this._updateIterativeLog(`Iteration ${iter}: Score dropped (${score} < best ${bestScore}). Performing deep analysis\u2026`);

        try {
          degradationAnalysis = await this.generator.compareProseVersions({
            bestProse: this._iterativeBestText,
            bestScore,
            bestSubscores: this._iterativeBestReview?.subscores || {},
            rewrittenProse: workingText,
            rewrittenScore: score,
            rewrittenSubscores: review.subscores || {},
            appliedFixes: previousFixLists.length > 0 ? previousFixLists[previousFixLists.length - 1] : null
          });
          this._updateIterativeLog(`Root cause: ${degradationAnalysis.rootCause || 'Analysis complete'}`);
          if (degradationAnalysis.analysis) {
            this._updateIterativeLog(`Detail: ${degradationAnalysis.analysis}`);
          }
          if (degradationAnalysis.betterApproach) {
            this._updateIterativeLog(`Recommended approach: ${degradationAnalysis.betterApproach}`);
          }
        } catch (err) {
          this._updateIterativeLog(`Deep analysis failed: ${err.message}. Will use standard reflection.`);
          degradationAnalysis = null;
        }

        // Revert to best version for next iteration
        this._updateIterativeLog(`Reverting to best version (score ${bestScore}).`);
        workingText = this._iterativeBestText;
        if (this._iterativeBestReview) review = this._iterativeBestReview;

        // Restore best text in editor (background update)
        const baseContent = this._preGenerationContent || '';
        const editorEl = this.editor.element;
        const paragraphs = workingText.split('\n\n');
        const restoredHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
        editorEl.innerHTML = (baseContent.trim() ? baseContent : '') + restoredHtml;
        if (this.state.currentChapterId) {
          this.fs.updateChapter(this.state.currentChapterId, { content: this.editor.getContent() }).catch(() => {});
        }
        this._lastGeneratedText = workingText;
      } else {
        consecutiveNoImprovement++;
      }

      // Update UI — after revert, review.score reflects the working version's actual score
      const displayScore = review.score;
      this._updateIterativeScore(displayScore, true);
      this._recordIterationScore(iter, displayScore);
      this._updateIterativeIteration(iter, bestScore);
      this._updateIterativeLog(`Iteration ${iter}: Score = ${displayScore}/100${displayScore < bestScore ? ` (best: ${bestScore})` : ''} [threshold: ${qualityThreshold}]`);

      // After revert, review may point to best version — use review.score for consistency
      this._iterPrevScore = review.score;
      this._iterPrevIssueCount = (review.issues?.length || 0) + (review.aiPatterns?.length || 0);
      this._iterPrevSubscores = review.subscores;

      // === THRESHOLD CHECK: If met, proceed to next chunk ===
      if (bestScore >= qualityThreshold) {
        this._updateIterativeLog(`Score ${bestScore}/100 meets threshold (${qualityThreshold}%)!`);
        await new Promise(r => setTimeout(r, 800));
        // Show final fix screen instead of auto-proceeding
        this._showIterativeOverlay(false);
        this._showFinalFixScreen(
          this._iterativeBestText || workingText,
          bestScore,
          this._iterativeBestReview,
          iterationHistory,
          qualityThreshold,
          true // threshold met
        );
        return;
      }

      // === STAGNATION CHECK: Stop if no improvement after several attempts ===
      if (consecutiveNoImprovement >= MAX_CONSECUTIVE_NO_IMPROVEMENT) {
        this._updateIterativeLog(`No improvement after ${consecutiveNoImprovement} consecutive iterations. Moving to final review.`);
        break; // Fall through to final fix screen
      }

      // If this is the last iteration, fall through to final fix screen
      if (iter >= MAX_ITERATIONS) {
        this._updateIterativeLog(`Max iterations (${MAX_ITERATIONS}) reached. Best: ${bestScore}/${qualityThreshold}`);
        break; // Fall through to final fix screen
      }

      // === STEP 2: AI Self-Reflection — Deep analysis of what's holding score back ===
      this._updateIterativePhase(`Analyzing improvements (${iter}/${MAX_ITERATIONS})\u2026`);
      this._updateIterativeLog(`Iteration ${iter}: Deep analysis — "How to reach ${qualityThreshold} from ${bestScore}?"\u2026`);

      let fixList = null;
      try {
        fixList = await this.generator.reflectOnProse({
          prose: workingText,
          score: bestScore || score,
          subscores: review.subscores,
          threshold: qualityThreshold,
          issues: review.issues,
          aiPatterns: review.aiPatterns,
          iterationNum: iter,
          previousFixLists: previousFixLists.length > 0 ? previousFixLists : undefined,
          degradationAnalysis: degradationAnalysis || undefined
        });
      } catch (err) {
        this._updateIterativeLog(`Reflection failed: ${err.message}. Moving to final review.`);
        break; // Fall through to final fix screen
      }

      if (this._iterativeCancelled) {
        this._showIterativeOverlay(false);
        return;
      }

      if (!fixList || !fixList.fixes || fixList.fixes.length === 0) {
        this._updateIterativeLog(`Iteration ${iter}: No fixes identified. Moving to final review.`);
        break; // Fall through to final fix screen
      }

      // Log the fix list
      this._updateIterativeLog(`Fix strategy: ${fixList.reflection || 'Analysis complete'}`);
      this._updateIterativeLog(`${fixList.fixes.length} surgical fixes planned: ${fixList.fixes.map(f => f.description.slice(0, 50)).join('; ')}`);

      // === STEP 2.5: ALWAYS pre-validate fixes before applying ===
      this._updateIterativePhase('Pre-validating fixes\u2026');
      this._updateIterativeLog(`Pre-validating ${fixList.fixes.length} fixes before applying\u2026`);

      let validation = null;
      try {
        validation = await this.generator.preValidateFixes({
          prose: workingText,
          fixList,
          currentScore: bestScore || score,
          subscores: review.subscores,
          threshold: qualityThreshold
        });
        this._updateIterativeLog(`Predicted score: ${validation.predictedScore} (confidence: ${validation.confidence})`);
      } catch (err) {
        this._updateIterativeLog(`Pre-validation failed: ${err.message}. Proceeding cautiously.`);
        validation = null;
      }

      if (this._iterativeCancelled) {
        this._showIterativeOverlay(false);
        return;
      }

      // If pre-validation predicts no improvement, refine the fix strategy
      if (validation && validation.predictedScore <= (bestScore || score)) {
        this._updateIterativeLog(`Predicted score (${validation.predictedScore}) won't improve. Refining strategy\u2026`);
        this._updateIterativePhase('Refining fix strategy\u2026');

        try {
          fixList = await this.generator.reflectOnProse({
            prose: workingText,
            score: bestScore || score,
            subscores: review.subscores,
            threshold: qualityThreshold,
            issues: review.issues,
            aiPatterns: review.aiPatterns,
            iterationNum: iter,
            previousFixLists: previousFixLists.length > 0 ? previousFixLists : undefined,
            degradationAnalysis: degradationAnalysis || undefined,
            validationFeedback: validation
          });

          if (!fixList || !fixList.fixes || fixList.fixes.length === 0) {
            this._updateIterativeLog(`Refinement produced no viable fixes. Moving to final review.`);
            break; // Fall through to final fix screen
          }

          this._updateIterativeLog(`Refined: ${fixList.fixes.length} fixes`);

          // Re-validate the refined fixes
          this._updateIterativePhase('Re-validating\u2026');
          try {
            const validation2 = await this.generator.preValidateFixes({
              prose: workingText,
              fixList,
              currentScore: bestScore || score,
              subscores: review.subscores,
              threshold: qualityThreshold
            });
            this._updateIterativeLog(`Re-validation: predicted ${validation2.predictedScore} (${validation2.confidence})`);

            if (validation2.predictedScore <= (bestScore || score)) {
              this._updateIterativeLog(`Refined fixes still won't improve score. Continuing to next iteration with different approach.`);
              previousFixLists.push(fixList);
              continue; // Skip applying, try a fresh approach next iteration
            }
          } catch (err) {
            this._updateIterativeLog(`Re-validation failed: ${err.message}. Proceeding with refined fixes.`);
          }
        } catch (err) {
          this._updateIterativeLog(`Fix refinement failed: ${err.message}. Continuing.`);
          previousFixLists.push(fixList);
          continue; // Skip this iteration's fixes, try again
        }
      } else if (validation) {
        this._updateIterativeLog(`Pre-validation predicts improvement (${validation.predictedScore}). Applying fixes.`);
      }

      // Clear degradation analysis after it has been used
      if (degradationAnalysis) degradationAnalysis = null;

      if (this._iterativeCancelled) {
        this._showIterativeOverlay(false);
        return;
      }

      previousFixLists.push(fixList);

      // === STEP 3: Apply the fix list surgically ===
      this._updateIterativePhase(`Applying ${fixList.fixes.length} surgical fixes\u2026`);
      this._updateIterativeLog(`Implementing ${fixList.fixes.length} fixes\u2026`);

      let characters = [];
      if (this._iterativeSettings.useCharacters && this.state.currentProjectId) {
        characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId);
      }
      let chapterTitle = '';
      if (this.state.currentChapterId) {
        try {
          const chapter = await this.fs.getChapter(this.state.currentChapterId);
          if (chapter) chapterTitle = chapter.title;
        } catch (_) {}
      }

      const project = this._currentProject;
      const genreInfo = this._getGenreRules(project?.genre, project?.subgenre);
      const baseContent = this._preGenerationContent || '';
      const editorEl = this.editor.element;
      editorEl.innerHTML = baseContent;

      let rewrittenText = '';
      try {
        await new Promise((resolve, reject) => {
          if (this._iterativeCancelled) { resolve(); return; }

          this.generator.applyFixList(
            {
              originalProse: workingText,
              fixList,
              chapterTitle,
              characters,
              notes: '',
              chapterOutline: this._currentChapterOutline || '',
              aiInstructions: project?.aiInstructions || '',
              tone: this._iterativeSettings.tone || '',
              style: this._iterativeSettings.style || '',
              wordTarget: 100,
              maxTokens: 250,
              genre: genreInfo?.label || '',
              genreRules: genreInfo?.rules || '',
              voice: project?.voice || '',
              errorPatternsPrompt: this._cachedErrorPatternsPrompt || '',
              iterationNum: iter,
              threshold: qualityThreshold
            },
            {
              onChunk: (text) => {
                rewrittenText += text;
                rewrittenText = this._stripEmDashes(rewrittenText);
                const startingContent = baseContent.trim() ? baseContent : '';
                const paragraphs = rewrittenText.split('\n\n');
                const newHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
                editorEl.innerHTML = startingContent + newHtml;
                const container = editorEl.closest('.editor-area');
                if (container) container.scrollTop = container.scrollHeight;
              },
              onDone: () => {
                const content = this.editor.getContent();
                if (this.state.currentChapterId) {
                  this.fs.updateChapter(this.state.currentChapterId, { content }).catch(() => {});
                  this._updateLocalWordCounts(content);
                }
                resolve();
              },
              onError: (err) => reject(err)
            }
          );
        });
      } catch (err) {
        this._updateIterativeLog(`Fix application failed: ${err.message}. Continuing with best version.`);
        consecutiveNoImprovement++;
        continue; // Try again next iteration
      }

      if (this._iterativeCancelled) {
        this._showIterativeOverlay(false);
        return;
      }

      // Anti-regression: check word count drift
      if (rewrittenText && rewrittenText.length > 20) {
        const preWords = (workingText.match(/[a-zA-Z'''\u2019-]+/g) || []).length;
        const postWords = (rewrittenText.match(/[a-zA-Z'''\u2019-]+/g) || []).length;
        const wordCountDrift = Math.abs(postWords - preWords) / Math.max(preWords, 1);

        if (wordCountDrift > 0.25) {
          this._updateIterativeLog(`Word count drifted ${Math.round(wordCountDrift * 100)}% (${preWords} \u2192 ${postWords}). Reverting.`);
          const startingContent = baseContent.trim() ? baseContent : '';
          const paragraphs = workingText.split('\n\n');
          const revertHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
          editorEl.innerHTML = startingContent + revertHtml;
          if (this.state.currentChapterId) {
            this.fs.updateChapter(this.state.currentChapterId, { content: this.editor.getContent() }).catch(() => {});
          }
          consecutiveNoImprovement++;
        } else {
          workingText = rewrittenText;
          this._lastGeneratedText = workingText;
          this._updateIterativeLog(`Fixes applied (${postWords} words). Proceeding to re-score\u2026`);
        }
      } else {
        this._updateIterativeLog(`Rewrite produced no usable text. Keeping current version.`);
        consecutiveNoImprovement++;
      }
    }

    // === FINAL: Show the final fix screen with best version ===
    this._showIterativeOverlay(false);
    const finalText = this._iterativeBestText || workingText;
    const finalScore = bestScore;
    const finalReview = this._iterativeBestReview;

    this._showFinalFixScreen(
      finalText,
      finalScore,
      finalReview,
      iterationHistory,
      qualityThreshold,
      finalScore >= qualityThreshold // threshold met?
    );
  }

  /**
   * Show the final fix screen after all background iterations are complete.
   * Presents the best prose with options: Fix Critical Errors, Apply All Fixes, Accept As-Is.
   */
  _showFinalFixScreen(prose, score, review, iterationHistory, threshold, thresholdMet) {
    const overlay = document.getElementById('iterative-accept-overlay');
    if (!overlay) return;

    // Store state for button handlers
    this._iterativeAcceptText = prose;
    this._finalFixReview = review;
    this._finalFixIterationHistory = iterationHistory;

    // Build the score display
    const scoreClass = score >= 88 ? 'score-excellent' : score >= 78 ? 'score-good' :
      score >= 65 ? 'score-fair' : 'score-poor';

    const scoreEl = document.getElementById('iterative-accept-score');
    if (scoreEl) {
      scoreEl.textContent = score;
      scoreEl.className = 'iterative-score-number ' + scoreClass;
    }

    // Build iteration journey summary
    let journeyHtml = '';
    if (iterationHistory && iterationHistory.length > 1) {
      const startScore = iterationHistory[0].score;
      journeyHtml = `<div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:8px;text-align:center;">
        Score journey: ${iterationHistory.map(h => h.score).join(' \u2192 ')}
        (${score - startScore >= 0 ? '+' : ''}${score - startScore} over ${iterationHistory.length} iterations)
      </div>`;
    }

    // Build threshold status
    const thresholdStatusHtml = thresholdMet
      ? `<div style="color:var(--success, #28a745);font-size:0.85rem;font-weight:600;text-align:center;margin-bottom:8px;">Threshold met: ${score}/${threshold}</div>`
      : `<div style="color:var(--danger, #dc3545);font-size:0.85rem;font-weight:600;text-align:center;margin-bottom:8px;">Below threshold: ${score}/${threshold} (${threshold - score} pts needed)</div>`;

    // Build remaining issues summary
    let issuesHtml = '';
    const highIssues = (review?.issues || []).filter(i => i.severity === 'high');
    const mediumIssues = (review?.issues || []).filter(i => i.severity === 'medium');
    const lowIssues = (review?.issues || []).filter(i => i.severity === 'low');
    const aiPatterns = review?.aiPatterns || [];
    const criticalCount = highIssues.length + aiPatterns.length;
    const totalIssues = highIssues.length + mediumIssues.length + lowIssues.length + aiPatterns.length;

    if (totalIssues > 0) {
      issuesHtml = `<div style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:12px;padding:8px;background:var(--bg-secondary);border-radius:var(--radius-sm);">
        <strong>Remaining issues:</strong>
        ${criticalCount > 0 ? `<span style="color:var(--danger);"> ${criticalCount} critical</span>` : ''}
        ${mediumIssues.length > 0 ? `<span style="color:var(--warning, #ffc107);"> ${mediumIssues.length} moderate</span>` : ''}
        ${lowIssues.length > 0 ? `<span style="color:var(--text-muted);"> ${lowIssues.length} minor</span>` : ''}
      </div>`;
    } else {
      issuesHtml = `<div style="font-size:0.8rem;color:var(--success);margin-bottom:12px;text-align:center;">No remaining issues detected.</div>`;
    }

    // Build prose preview
    const previewEl = document.getElementById('iterative-accept-preview');
    if (previewEl) {
      previewEl.textContent = prose;
    }

    // Insert journey and issue info before preview
    const modalBody = overlay.querySelector('.modal-body');
    if (modalBody) {
      // Remove any previously injected info divs
      modalBody.querySelectorAll('.final-fix-info').forEach(el => el.remove());

      const infoDiv = document.createElement('div');
      infoDiv.className = 'final-fix-info';
      infoDiv.innerHTML = thresholdStatusHtml + journeyHtml + issuesHtml;

      const previewContainer = document.getElementById('iterative-accept-preview');
      if (previewContainer) {
        modalBody.insertBefore(infoDiv, previewContainer);
      }
    }

    // Update modal title
    const modalHeader = overlay.querySelector('.modal-header h2');
    if (modalHeader) {
      modalHeader.textContent = thresholdMet ? 'Prose Ready' : 'Best Result';
    }

    // Update description text
    const descEl = overlay.querySelector('.modal-body > p');
    if (descEl) {
      descEl.innerHTML = thresholdMet
        ? 'This prose meets your quality threshold. Accept as-is or review remaining issues.'
        : `After ${iterationHistory?.length || 0} iterations, this is the best version achieved. You can accept it, or fix remaining issues.`;
    }

    // Update footer buttons
    const footer = overlay.querySelector('.modal-footer');
    if (footer) {
      footer.innerHTML = '';

      // Button: Fix Critical Errors (only if critical issues exist)
      if (criticalCount > 0) {
        const fixCritBtn = document.createElement('button');
        fixCritBtn.className = 'btn';
        fixCritBtn.style.cssText = 'border-color:var(--danger);color:var(--danger);';
        fixCritBtn.textContent = `Fix Critical (${criticalCount})`;
        fixCritBtn.id = 'btn-final-fix-critical';
        fixCritBtn.addEventListener('click', () => {
          overlay.classList.remove('visible');
          this._applyFinalFixes('critical');
        });
        footer.appendChild(fixCritBtn);
      }

      // Button: Apply All Fixes (only if any issues exist)
      if (totalIssues > 0) {
        const fixAllBtn = document.createElement('button');
        fixAllBtn.className = 'btn';
        fixAllBtn.textContent = `Fix All (${totalIssues})`;
        fixAllBtn.id = 'btn-final-fix-all';
        fixAllBtn.addEventListener('click', () => {
          overlay.classList.remove('visible');
          this._applyFinalFixes('all');
        });
        footer.appendChild(fixAllBtn);
      }

      // Button: Accept & Continue
      const acceptBtn = document.createElement('button');
      acceptBtn.className = 'btn btn-primary';
      acceptBtn.textContent = 'Accept & Continue';
      acceptBtn.id = 'btn-iterative-accept';
      acceptBtn.addEventListener('click', () => {
        overlay.classList.remove('visible');
        this._iterativeWriteLoop();
      });
      footer.appendChild(acceptBtn);

      // Button: Accept & Stop
      const stopBtn = document.createElement('button');
      stopBtn.className = 'btn';
      stopBtn.textContent = 'Accept & Stop';
      stopBtn.id = 'btn-iterative-accept-stop';
      stopBtn.addEventListener('click', () => {
        overlay.classList.remove('visible');
        this._iterativeCancelled = true;
        this._showContinueBar(true);
      });
      footer.appendChild(stopBtn);
    }

    overlay.classList.add('visible');
  }

  /**
   * Apply final fixes (critical-only or all) after the background iteration loop.
   * This triggers a rewrite pass focused on the remaining issues.
   */
  async _applyFinalFixes(mode) {
    const review = this._finalFixReview;
    const prose = this._iterativeAcceptText;
    if (!review || !prose) return;

    // Build fix list from remaining issues
    const problems = [];

    if (review.aiPatterns) {
      for (const p of review.aiPatterns) {
        problems.push(`AI Pattern: ${p.pattern}${p.examples?.[0] ? ` — "${p.examples[0]}"` : ''}`);
      }
    }

    if (review.issues) {
      for (const issue of review.issues) {
        if (mode === 'critical' && issue.severity !== 'high') continue;
        if (issue.severity === 'low') continue; // Skip low even in 'all' mode — they cause more harm
        problems.push(`[${issue.severity}] ${issue.problem || ''}${issue.text ? ` — "${issue.text}"` : ''}`);
      }
    }

    if (problems.length === 0) {
      // Nothing to fix, just continue
      this._iterativeWriteLoop();
      return;
    }

    this._updateIterativeLog(`Applying ${mode} fixes (${problems.length} issues)\u2026`);
    this._showIterativeOverlay(true);
    this._updateIterativePhase(`Applying ${problems.length} ${mode} fixes\u2026`);

    // Use the existing rewrite infrastructure
    const project = this._currentProject;
    const genreInfo = this._getGenreRules(project?.genre, project?.subgenre);
    let characters = [];
    if (this._iterativeSettings?.useCharacters && this.state.currentProjectId) {
      characters = await this.localStorage.getProjectCharacters(this.state.currentProjectId);
    }
    let chapterTitle = '';
    if (this.state.currentChapterId) {
      try {
        const chapter = await this.fs.getChapter(this.state.currentChapterId);
        if (chapter) chapterTitle = chapter.title;
      } catch (_) {}
    }

    const baseContent = this._preGenerationContent || '';
    const editorEl = this.editor.element;
    editorEl.innerHTML = baseContent;

    let rewrittenText = '';
    const qualityThreshold = this._currentProject?.qualityThreshold || 90;

    try {
      await new Promise((resolve, reject) => {
        this.generator.rewriteProse(
          {
            originalProse: prose,
            problems,
            userInstructions: `Apply ONLY the listed fixes. Use surgical, minimum-change fixes. Do NOT rewrite full sentences or paragraphs unless absolutely necessary. Preserve the existing voice, rhythm, and structure.`,
            chapterTitle,
            characters,
            notes: '',
            chapterOutline: this._currentChapterOutline || '',
            aiInstructions: project?.aiInstructions || '',
            tone: this._iterativeSettings?.tone || '',
            style: this._iterativeSettings?.style || '',
            wordTarget: 100,
            maxTokens: 4096,
            genre: genreInfo?.label || '',
            genreRules: genreInfo?.rules || '',
            voice: project?.voice || '',
            previousScore: this._iterativeBestReview?.score,
            previousSubscores: this._iterativeBestReview?.subscores,
            rewriteIteration: 1,
            errorPatternsPrompt: this._cachedErrorPatternsPrompt || ''
          },
          {
            onChunk: (text) => {
              rewrittenText += text;
              rewrittenText = this._stripEmDashes(rewrittenText);
              const startingContent = baseContent.trim() ? baseContent : '';
              const paragraphs = rewrittenText.split('\n\n');
              const newHtml = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
              editorEl.innerHTML = startingContent + newHtml;
              const container = editorEl.closest('.editor-area');
              if (container) container.scrollTop = container.scrollHeight;
            },
            onDone: () => {
              const content = this.editor.getContent();
              if (this.state.currentChapterId) {
                this.fs.updateChapter(this.state.currentChapterId, { content }).catch(() => {});
                this._updateLocalWordCounts(content);
              }
              resolve();
            },
            onError: (err) => reject(err)
          }
        );
      });

      if (rewrittenText && rewrittenText.length > 20) {
        this._iterativeAcceptText = rewrittenText;
        this._lastGeneratedText = rewrittenText;
        this._updateIterativeLog(`${mode} fixes applied. Re-scoring\u2026`);

        // Re-score the fixed prose
        this._updateIterativePhase('Re-scoring\u2026');
        try {
          const newReview = await this.generator.scoreProse(rewrittenText, {
            isRewrite: true,
            previousScore: this._iterativeBestReview?.score || 0,
            previousIssueCount: problems.length,
            previousSubscores: this._iterativeBestReview?.subscores || {}
          });
          if (newReview && newReview.score > 0) {
            this._updateIterativeLog(`New score after fixes: ${newReview.score}/100`);
            this._showIterativeOverlay(false);

            // Show updated final fix screen with new results
            this._showFinalFixScreen(
              rewrittenText,
              newReview.score,
              newReview,
              this._finalFixIterationHistory || [],
              qualityThreshold,
              newReview.score >= qualityThreshold
            );
            return;
          }
        } catch (err) {
          this._updateIterativeLog(`Re-scoring failed: ${err.message}`);
        }
      }
    } catch (err) {
      this._updateIterativeLog(`Fix application failed: ${err.message}`);
    }

    this._showIterativeOverlay(false);
    this._showContinueBar(true);
  }

  /**
   * Show the accept/reject dialog once score target is met (or iterations exhausted).
   */
  _presentIterativeAccept(text, score) {
    const scoreEl = document.getElementById('iterative-accept-score');
    if (scoreEl) {
      scoreEl.textContent = score;
      scoreEl.className = 'iterative-score-number ' + (
        score >= 88 ? 'score-excellent' : score >= 78 ? 'score-good' :
        score >= 65 ? 'score-fair' : 'score-poor'
      );
    }

    const previewEl = document.getElementById('iterative-accept-preview');
    if (previewEl) {
      previewEl.textContent = text;
    }

    this._iterativeAcceptText = text;

    const overlay = document.getElementById('iterative-accept-overlay');
    if (overlay) overlay.classList.add('visible');
  }

  _showIterativeOverlay(show) {
    const overlay = document.getElementById('iterative-write-overlay');
    if (overlay) {
      if (show) {
        overlay.classList.add('visible');
      } else {
        overlay.classList.remove('visible');
      }
    }
  }

  _updateIterativePhase(text) {
    const el = document.getElementById('iterative-phase-label');
    if (el) el.textContent = text;
  }

  _updateIterativeScore(score, isCurrent) {
    const numEl = document.getElementById('iterative-score-value');
    const pctEl = document.getElementById('iterative-score-pct');
    const fillEl = document.getElementById('iterative-progress-fill');
    const labelEl = document.getElementById('iterative-score-label');

    if (score === null || score === undefined) {
      if (numEl) { numEl.textContent = '--'; numEl.className = 'iterative-score-number'; }
      if (pctEl) pctEl.textContent = '0%';
      if (fillEl) { fillEl.style.width = '0%'; fillEl.className = 'iterative-progress-fill'; }
      if (labelEl) labelEl.textContent = 'Score / 100';
      return;
    }

    const scoreClass = score >= 88 ? 'score-excellent' : score >= 78 ? 'score-good' :
                       score >= 65 ? 'score-fair' : 'score-poor';

    if (numEl) { numEl.textContent = score; numEl.className = 'iterative-score-number ' + scoreClass; }
    if (pctEl) pctEl.textContent = score + '%';
    if (fillEl) { fillEl.style.width = score + '%'; fillEl.className = 'iterative-progress-fill ' + scoreClass; }
    if (labelEl) labelEl.textContent = isCurrent ? 'Current Score / 100' : 'Score / 100';
  }

  _updateIterativeIteration(iteration, bestScore) {
    const numEl = document.getElementById('iterative-iteration-num');
    const bestEl = document.getElementById('iterative-best-score');
    if (numEl) numEl.textContent = iteration;
    if (bestEl) bestEl.textContent = bestScore > 0 ? bestScore : '--';
  }

  /**
   * Record a score for a specific iteration and display the score history.
   */
  _recordIterationScore(iteration, score) {
    if (!this._iterationScoreHistory) this._iterationScoreHistory = [];
    this._iterationScoreHistory.push({ iteration, score });
    this._renderScoreHistory();
  }

  _resetScoreHistory() {
    this._iterationScoreHistory = [];
    const histEl = document.getElementById('iterative-score-history');
    if (histEl) {
      histEl.style.display = 'none';
      histEl.innerHTML = '';
    }
  }

  _renderScoreHistory() {
    const histEl = document.getElementById('iterative-score-history');
    if (!histEl || !this._iterationScoreHistory || this._iterationScoreHistory.length === 0) return;
    histEl.style.display = 'block';
    const entries = this._iterationScoreHistory.map(h => {
      const cls = h.score >= 88 ? 'color:var(--success)' : h.score >= 78 ? 'color:var(--accent-primary)' :
                  h.score >= 65 ? 'color:var(--warning)' : 'color:var(--danger)';
      return `<span style="${cls};font-weight:600;">Iter ${h.iteration}: ${h.score}</span>`;
    });
    histEl.innerHTML = entries.join(' &bull; ');
  }

  _updateIterativeLog(message) {
    const logEl = document.getElementById('iterative-status-log');
    if (logEl) {
      logEl.textContent += '\n' + message;
      logEl.scrollTop = logEl.scrollHeight;
    }
  }

  _showIterativeScoringNotice(show) {
    const el = document.getElementById('iterative-scoring-notice');
    if (el) {
      if (show) {
        el.classList.add('visible');
      } else {
        el.classList.remove('visible');
      }
    }
  }

  _updateIterativeChunk(num) {
    const el = document.getElementById('iterative-chunk-num');
    if (el) el.textContent = num;
  }

  _showProseReview(review, generatedText) {
    const body = document.getElementById('prose-review-body');
    if (!body) return;

    const scoreClass = review.score >= 88 ? 'score-excellent' :
                       review.score >= 78 ? 'score-good' :
                       review.score >= 65 ? 'score-fair' : 'score-poor';

    // Score comparison for rewrites
    let scoreComparisonHtml = '';
    if (review._previousScore != null) {
      const delta = review.score - review._previousScore;
      const deltaSign = delta > 0 ? '+' : '';
      const deltaColor = delta > 0 ? 'var(--success)' : delta < 0 ? 'var(--danger)' : 'var(--text-muted)';
      scoreComparisonHtml = `<div style="font-size:0.8rem;color:${deltaColor};margin-top:4px;">
        ${deltaSign}${delta} from previous (${review._previousScore}) &mdash; Rewrite #${review._rewriteIteration || 1}
      </div>`;
    }

    // Convergence warning
    let convergenceHtml = '';
    if (review._convergenceWarning) {
      convergenceHtml = `<div style="background:var(--warning-bg, rgba(255,193,7,0.15));border:1px solid var(--warning, #ffc107);border-radius:var(--radius-sm);padding:10px;margin:12px 0;font-size:0.85rem;">
        <strong>Diminishing returns detected.</strong> The score has not improved meaningfully after ${review._rewriteIteration} rewrites. This prose may be near its optimization ceiling for AI-assisted fixes. Consider accepting the prose or making manual edits.
      </div>`;
    }
    if (review._scoreDecreased) {
      const revertNote = review._revertedToPrevious
        ? ' <strong>The previous (higher-scoring) version has been automatically restored.</strong>'
        : '';
      convergenceHtml = `<div style="background:var(--danger-bg, rgba(220,53,69,0.15));border:1px solid var(--danger, #dc3545);border-radius:var(--radius-sm);padding:10px;margin:12px 0;font-size:0.85rem;">
        <strong>Score decreased after rewrite.</strong> The rewrite introduced new issues while fixing old ones.${revertNote} Consider accepting the prose and making targeted manual edits for remaining issues.
      </div>`;
    }

    // Threshold comparison
    const qualityThreshold = review._qualityThreshold || this._currentProject?.qualityThreshold || 90;
    let thresholdHtml = '';
    if (qualityThreshold) {
      const meetsThreshold = review.score >= qualityThreshold;
      thresholdHtml = `<div style="font-size:0.8rem;margin-top:6px;color:${meetsThreshold ? 'var(--success, #28a745)' : 'var(--danger, #dc3545)'};">
        ${meetsThreshold ? 'Meets' : 'Below'} threshold: ${review.score}/${qualityThreshold}
      </div>`;
    }

    let html = `
      <div class="prose-score-display">
        <div class="prose-score-number ${scoreClass}">${review.score}</div>
        <div class="prose-score-label">${this._esc(review.label || '')} / 100</div>
        ${scoreComparisonHtml}
        ${thresholdHtml}
        <div class="meter" style="margin-top:12px;max-width:200px;margin-left:auto;margin-right:auto;">
          <div class="meter-fill ${review.score >= 70 ? 'good' : review.score >= 50 ? 'warning' : 'danger'}" style="width:${review.score}%"></div>
        </div>
      </div>
      ${convergenceHtml}`;

    // Sub-scores breakdown
    if (review.subscores) {
      const subScoreLabels = {
        sentenceVariety: { label: 'Sentence Variety & Rhythm', max: 15 },
        dialogueAuthenticity: { label: 'Dialogue Authenticity', max: 15 },
        sensoryDetail: { label: 'Sensory Detail / Show vs Tell', max: 15 },
        emotionalResonance: { label: 'Emotional Resonance & Depth', max: 15 },
        vocabularyPrecision: { label: 'Vocabulary Precision', max: 10 },
        narrativeFlow: { label: 'Narrative Flow & Pacing', max: 10 },
        originalityVoice: { label: 'Originality & Voice', max: 10 },
        technicalExecution: { label: 'Technical Execution', max: 10 }
      };
      html += `<div class="prose-subscores">`;
      for (const [key, info] of Object.entries(subScoreLabels)) {
        const val = review.subscores[key] ?? 0;
        const pct = Math.round((val / info.max) * 100);
        const barClass = pct >= 80 ? 'good' : pct >= 55 ? 'warning' : 'danger';
        html += `
          <div class="prose-subscore-row">
            <span class="prose-subscore-label">${info.label}</span>
            <span class="prose-subscore-value">${val}/${info.max}</span>
            <div class="prose-subscore-bar"><div class="meter-fill ${barClass}" style="width:${pct}%"></div></div>
          </div>`;
      }
      html += `</div>`;
    }

    html += `<p style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:16px;">${this._esc(review.summary || '')}</p>`;

    if (review.aiPatterns && review.aiPatterns.length > 0) {
      const totalAiImpact = review.aiPatterns.reduce((s, p) => s + (p.estimatedImpact || 0), 0);
      html += `<h3 style="font-size:0.85rem;font-weight:600;color:var(--danger);margin-bottom:8px;">AI Patterns Detected${totalAiImpact > 0 ? ` <span class="prose-impact-badge">fixing could add ~${totalAiImpact} pts</span>` : ''}</h3>
        <ul class="prose-patterns-list">
          ${review.aiPatterns.map(p => `
            <li class="prose-pattern-item">
              <strong>${this._esc(p.pattern)}</strong>${p.estimatedImpact ? ` <span class="prose-impact-inline">+${p.estimatedImpact}</span>` : ''}
              ${p.examples && p.examples.length > 0 ? `<br><span style="font-size:0.8rem;color:var(--text-muted);">"${this._esc(p.examples[0])}"</span>` : ''}
            </li>
          `).join('')}
        </ul>`;
    }

    // Separate issues by severity
    const highIssues = (review.issues || []).filter(i => i.severity === 'high');
    const mediumIssues = (review.issues || []).filter(i => i.severity === 'medium');
    const lowIssues = (review.issues || []).filter(i => i.severity === 'low');
    const hasIssues = highIssues.length > 0 || mediumIssues.length > 0 || lowIssues.length > 0;

    if (hasIssues) {
      const totalHighImpact = highIssues.reduce((s, i) => s + (i.estimatedImpact || 0), 0);
      const totalMedImpact = mediumIssues.reduce((s, i) => s + (i.estimatedImpact || 0), 0);
      const totalLowImpact = lowIssues.reduce((s, i) => s + (i.estimatedImpact || 0), 0);
      const totalAllImpact = totalHighImpact + totalMedImpact + totalLowImpact;

      html += `<h3 style="font-size:0.85rem;font-weight:600;color:var(--text-secondary);margin-top:16px;margin-bottom:8px;">Quality Issues (${review.issues.length})${totalAllImpact > 0 ? ` <span class="prose-impact-badge">fixing all could add ~${totalAllImpact} pts</span>` : ''}</h3>`;

      // Filter toggle buttons
      html += `<div class="prose-filter-bar">
        <button class="prose-filter-btn active" data-filter="all">All (${review.issues.length})</button>
        <button class="prose-filter-btn prose-filter-high" data-filter="high">Serious (${highIssues.length})${totalHighImpact > 0 ? ` +${totalHighImpact}` : ''}</button>
        <button class="prose-filter-btn prose-filter-medium" data-filter="medium">Moderate (${mediumIssues.length})${totalMedImpact > 0 ? ` +${totalMedImpact}` : ''}</button>
        <button class="prose-filter-btn prose-filter-low" data-filter="low">Minor (${lowIssues.length})${totalLowImpact > 0 ? ` +${totalLowImpact}` : ''}</button>
      </div>`;

      html += `<ul class="prose-issues-list">
          ${review.issues.map(issue => `
            <li class="prose-issue-item severity-${issue.severity || 'medium'}" data-severity="${issue.severity || 'medium'}">
              <strong>${this._esc(issue.problem || '')}</strong>${issue.estimatedImpact ? ` <span class="prose-impact-inline">+${issue.estimatedImpact}</span>` : ''}${issue.category ? ` <span class="prose-category-tag">${this._esc(issue.category)}</span>` : ''}
              ${issue.text ? `<br><span style="font-size:0.8rem;color:var(--text-muted);">"${this._esc(issue.text)}"</span>` : ''}
            </li>
          `).join('')}
        </ul>`;
    }

    if (!hasIssues && (!review.aiPatterns || review.aiPatterns.length === 0)) {
      html += `<p style="color:var(--success);font-size:0.9rem;text-align:center;margin-top:16px;">No major issues detected. The prose quality is solid.</p>`;
    }

    body.innerHTML = html;

    // Wire up severity filter buttons
    body.querySelectorAll('.prose-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        body.querySelectorAll('.prose-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.dataset.filter;
        body.querySelectorAll('.prose-issue-item').forEach(item => {
          if (filter === 'all') {
            item.style.display = '';
          } else {
            item.style.display = item.dataset.severity === filter ? '' : 'none';
          }
        });
      });
    });

    // Store for rewrite action
    this._lastProseReview = review;
    this._lastGeneratedText = generatedText;

    // Show rewrite buttons based on issue severity
    const hasAnyIssues = review.issues?.length > 0 || review.aiPatterns?.length > 0;
    const hasHighIssues = (review.issues || []).some(i => i.severity === 'high') || review.aiPatterns?.length > 0;

    const rewriteBtn = document.getElementById('btn-prose-review-rewrite');
    if (rewriteBtn) {
      rewriteBtn.style.display = hasAnyIssues ? '' : 'none';
    }

    const rewriteSeriousBtn = document.getElementById('btn-prose-review-rewrite-serious');
    if (rewriteSeriousBtn) {
      rewriteSeriousBtn.style.display = hasHighIssues ? '' : 'none';
    }

    const overlay = document.getElementById('prose-review-overlay');
    if (overlay) overlay.classList.add('visible');
  }

  async _rewriteProblems(userInstructions, severityFilter) {
    if (!this._lastProseReview || !this._lastGeneratedText) return;

    const review = this._lastProseReview;
    const problems = [];

    // Always include AI patterns — these are high-priority
    if (review.aiPatterns) {
      for (const p of review.aiPatterns) {
        problems.push({
          text: p.examples?.[0] || '',
          description: `AI Pattern: ${p.pattern}`,
          impact: p.estimatedImpact || 3,
          severity: 'high',
          category: 'ai-pattern'
        });
      }
    }

    // Filter and collect issues — NEVER include low-severity issues in rewrites
    // Low-severity fixes almost always introduce new problems that outweigh the benefit
    if (review.issues) {
      for (const issue of review.issues) {
        // Skip low-severity issues entirely — they cause more harm than good
        if (issue.severity === 'low') continue;

        if (severityFilter === 'high' && issue.severity !== 'high') continue;

        problems.push({
          text: issue.text || '',
          description: issue.problem || '',
          impact: issue.estimatedImpact || 1,
          severity: issue.severity,
          category: issue.category || 'other'
        });
      }
    }

    // Sort by estimated impact (highest first) so the most valuable fixes are prioritized
    problems.sort((a, b) => b.impact - a.impact);

    // Cap at 10 issues per rewrite pass to prevent the AI from being overwhelmed
    // Trying to fix too many issues at once is the primary cause of score degradation
    const MAX_ISSUES_PER_PASS = 10;
    const cappedProblems = problems.slice(0, MAX_ISSUES_PER_PASS);

    // Format problems as precise, actionable instructions
    const formattedProblems = cappedProblems.map(p => {
      if (p.text) {
        return `FIND: "${p.text}" → PROBLEM: ${p.description} [${p.severity}, ~${p.impact} pts]`;
      }
      return `${p.description} [${p.severity}, ~${p.impact} pts]`;
    });

    if (formattedProblems.length === 0 && !userInstructions) return;

    // Track rewrite iterations for convergence detection
    this._rewriteIteration = (this._rewriteIteration || 0) + 1;
    const previousScore = review.score;
    const previousSubscores = review.subscores;
    const previousIssueCount = (review.issues?.length || 0) + (review.aiPatterns?.length || 0);

    // Store previous text so we can revert if score drops
    this._previousRewriteText = this._lastGeneratedText;
    this._previousRewriteScore = previousScore;
    this._previousRewriteIssueCount = previousIssueCount;

    // Close review modal
    document.getElementById('prose-review-overlay').classList.remove('visible');

    this._showContinueBar(false);
    this._setGenerateStatus(true);

    // Roll back the editor to the content before the last generation
    const baseContent = this._preGenerationContent || '';
    const editorEl = this.editor.element;
    editorEl.innerHTML = baseContent;

    // Gather context for the rewrite
    const characters = this._lastGenSettings?.useCharacters
      ? await this.localStorage.getProjectCharacters(this.state.currentProjectId)
      : [];

    let notes = '';
    if (this._lastGenSettings?.useNotes && this.state.currentProjectId) {
      const projectNotes = await this.localStorage.getProjectNotes(this.state.currentProjectId);
      if (projectNotes.length > 0) {
        notes = projectNotes.map(n => {
          let entry = n.title;
          if (n.type && n.type !== 'general') entry = `[${n.type}] ${entry}`;
          if (n.content) entry += '\n' + n.content;
          return entry;
        }).join('\n\n');
      }
    }

    // Append project knowledge base as reference materials
    const knowledgePromptRewrite = await this._getProjectKnowledge();
    if (knowledgePromptRewrite) {
      notes = notes ? notes + '\n\n' + knowledgePromptRewrite : knowledgePromptRewrite;
    }

    let chapterTitle = '';
    if (this.state.currentChapterId) {
      try {
        const chapter = await this.fs.getChapter(this.state.currentChapterId);
        if (chapter) chapterTitle = chapter.title;
      } catch (_) {}
    }

    const project = this._currentProject;
    const genreInfo = this._getGenreRules(project?.genre, project?.subgenre);

    let streamedText = '';

    await this.generator.rewriteProse(
      {
        originalProse: this._lastGeneratedText,
        problems: formattedProblems,
        userInstructions: userInstructions || '',
        chapterTitle,
        characters,
        notes,
        chapterOutline: this._currentChapterOutline || '',
        aiInstructions: project?.aiInstructions || '',
        tone: this._lastGenSettings?.tone || '',
        style: this._lastGenSettings?.style || '',
        wordTarget: this._lastGenSettings?.wordTarget || 1000,
        genre: genreInfo?.label || '',
        genreRules: genreInfo?.rules || '',
        voice: project?.voice || '',
        previousScore,
        previousSubscores,
        rewriteIteration: this._rewriteIteration,
        errorPatternsPrompt: this._cachedErrorPatternsPrompt || ''
      },
      {
        onChunk: (text) => {
          streamedText += text;
          streamedText = this._stripEmDashes(streamedText);
          const startingContent = baseContent.trim() ? baseContent : '';
          const paragraphs = streamedText.split('\n\n');
          const newHtml = paragraphs
            .map(p => {
              const lines = p.replace(/\n/g, '<br>');
              return `<p>${lines}</p>`;
            })
            .join('');
          editorEl.innerHTML = startingContent + newHtml;
          const container = editorEl.closest('.editor-area');
          if (container) container.scrollTop = container.scrollHeight;
          // Update word count live
          const wc = editorEl.textContent.match(/[a-zA-Z'''\u2019-]+/g) || [];
          const chapterWords = wc.length;
          const wordsEl = document.getElementById('status-words');
          if (wordsEl) wordsEl.textContent = chapterWords.toLocaleString();
          const fwcWords = document.getElementById('fwc-words');
          if (fwcWords) fwcWords.textContent = chapterWords.toLocaleString();
          this._updateLocalWordCounts(editorEl.innerHTML);
          this._trackDailyWords(chapterWords);
        },
        onDone: async () => {
          this._setGenerateStatus(false);
          const content = this.editor.getContent();
          if (this.state.currentChapterId) {
            try {
              await this.fs.updateChapter(this.state.currentChapterId, { content });
            } catch (_) {}
            this._updateLocalWordCounts(content);
          }

          // Re-score the rewritten prose with rewrite context
          if (streamedText && streamedText.length > 100) {
            this._scoreProseAfterRewrite(streamedText, previousScore, previousIssueCount, previousSubscores);
          }

          this._showContinueBar(true);
        },
        onError: (err) => {
          this._setGenerateStatus(false);
          alert('Rewrite failed: ' + err.message);
        }
      }
    );
  }

  _openProseRethinkModal() {
    if (!this._lastGeneratedText) {
      alert('No generated prose to rethink.');
      return;
    }

    // Close the prose review modal
    document.getElementById('prose-review-overlay')?.classList.remove('visible');

    document.getElementById('prose-rethink-prompt').value = '';
    document.getElementById('prose-rethink-status').style.display = 'none';
    document.getElementById('btn-prose-rethink-submit').disabled = false;
    const overlay = document.getElementById('prose-rethink-overlay');
    if (overlay) overlay.classList.add('visible');
  }

  async _submitProseRethink() {
    const userInstructions = document.getElementById('prose-rethink-prompt')?.value?.trim();
    if (!userInstructions) {
      alert('Please enter instructions for how to revise the prose.');
      return;
    }

    // Show spinner and disable button
    document.getElementById('prose-rethink-status').style.display = '';
    document.getElementById('btn-prose-rethink-submit').disabled = true;

    // Close the modal
    document.getElementById('prose-rethink-overlay')?.classList.remove('visible');

    // Rewrite with user instructions (problems from last review are also included)
    await this._rewriteProblems(userInstructions);
  }

  // ========================================
  //  Welcome Screen
  // ========================================

  _showWelcome() {
    const overlay = document.getElementById('welcome-overlay');
    const editorEl = document.getElementById('editor');
    if (overlay) overlay.style.display = '';
    if (editorEl) editorEl.style.display = 'none';
    const outlineDisplay = document.getElementById('chapter-outline-display');
    if (outlineDisplay) outlineDisplay.style.display = 'none';
    document.getElementById('project-title').textContent = 'Genesis 2';
  }

  _hideWelcome() {
    const overlay = document.getElementById('welcome-overlay');
    const editorEl = document.getElementById('editor');
    if (overlay) overlay.style.display = 'none';
    if (editorEl) editorEl.style.display = '';
  }

  // ========================================
  //  Event Binding
  // ========================================

  _bindEvents() {
    // --- Landing Page Events ---

    // User list clicks
    document.getElementById('user-list')?.addEventListener('click', (e) => {
      const btn = e.target.closest('.user-btn');
      if (btn) this._selectUser(btn.dataset.name);
    });

    // New user input
    document.getElementById('btn-user-continue')?.addEventListener('click', () => {
      const name = document.getElementById('new-user-name')?.value?.trim();
      if (name) this._selectUser(name);
    });
    document.getElementById('new-user-name')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const name = e.target.value?.trim();
        if (name) this._selectUser(name);
      }
    });

    // Switch user
    document.getElementById('btn-change-user')?.addEventListener('click', () => {
      window.localStorage.removeItem('genesis2_userName');
      this.state.currentUser = null;
      this._showUserSelection();
    });

    // Create project
    document.getElementById('btn-create-project')?.addEventListener('click', () => {
      this._createNewProject();
    });

    // New project modal events
    document.getElementById('btn-new-project-accept')?.addEventListener('click', () => {
      this._submitNewProject();
    });
    document.getElementById('btn-new-project-cancel')?.addEventListener('click', () => {
      document.getElementById('new-project-overlay')?.classList.remove('visible');
    });
    document.getElementById('new-project-title')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this._submitNewProject();
    });

    // Project card clicks (event delegation on both lists)
    const handleProjectClick = (e) => {
      const card = e.target.closest('.project-card');
      if (card) this._openProject(card.dataset.id);
    };
    document.getElementById('my-projects-list')?.addEventListener('click', handleProjectClick);
    document.getElementById('others-projects-list')?.addEventListener('click', handleProjectClick);

    // --- Back to Projects ---
    document.getElementById('btn-back-to-projects')?.addEventListener('click', () => this._showLanding());
    document.getElementById('btn-back-to-projects-sidebar')?.addEventListener('click', () => this._showLanding());

    // --- Switch User ---
    document.getElementById('btn-switch-user-sidebar')?.addEventListener('click', () => this._switchUser());

    // --- Delete Project (sidebar) ---
    document.getElementById('btn-delete-project-sidebar')?.addEventListener('click', () => this._deleteCurrentProject());

    // --- Import Knowledge (sidebar) ---
    document.getElementById('btn-import-knowledge-sidebar')?.addEventListener('click', () => this._openImportKnowledgePanel());

    // --- Error Database (sidebar) ---
    document.getElementById('btn-error-database-sidebar')?.addEventListener('click', () => this.openErrorDatabasePanel());

    // --- Sidebar toggle ---
    document.getElementById('btn-sidebar-toggle')?.addEventListener('click', () => {
      this.state.sidebarOpen = !this.state.sidebarOpen;
      document.getElementById('app').classList.toggle('sidebar-collapsed', !this.state.sidebarOpen);
      document.querySelector('.sidebar')?.classList.toggle('mobile-open', this.state.sidebarOpen);
    });

    document.getElementById('btn-sidebar-toggle-mobile')?.addEventListener('click', () => {
      this.state.sidebarOpen = !this.state.sidebarOpen;
      document.getElementById('app').classList.toggle('sidebar-collapsed', !this.state.sidebarOpen);
      document.querySelector('.sidebar')?.classList.toggle('mobile-open', this.state.sidebarOpen);
    });

    // --- Focus mode ---
    const toggleFocus = () => {
      this.state.focusMode = !this.state.focusMode;
      document.getElementById('app').classList.toggle('focus-mode', this.state.focusMode);
      // Directly control exit button via JS — CSS selectors are unreliable on iPad Safari
      const exitBtn = document.getElementById('btn-exit-focus');
      if (exitBtn) exitBtn.style.display = this.state.focusMode ? 'flex' : 'none';
    };
    document.getElementById('btn-focus-mode')?.addEventListener('click', toggleFocus);
    document.getElementById('btn-exit-focus')?.addEventListener('click', toggleFocus);

    // --- Sidebar navigation tabs ---
    document.querySelectorAll('.sidebar-nav button').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const tab = e.target.dataset.tab;
        this.state.sidebarTab = tab;
        document.querySelectorAll('.sidebar-nav button').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');

        document.querySelectorAll('.sidebar-panel').forEach(p => p.style.display = 'none');
        const panel = document.getElementById('sidebar-' + tab);
        if (panel) panel.style.display = 'block';

        if (tab === 'characters') await this._renderCharactersList();
        if (tab === 'notes') await this._renderNotesList();
      });
    });

    // --- Sidebar content clicks (event delegation) ---
    document.querySelector('.sidebar-content')?.addEventListener('click', async (e) => {
      // Handle chapter checkbox clicks
      if (e.target.classList.contains('chapter-checkbox')) {
        e.stopPropagation();
        this._updateDeleteSelectedBtn();
        return;
      }

      // Handle Select All checkbox
      if (e.target.id === 'chapter-select-all') {
        e.stopPropagation();
        this._toggleSelectAll(e.target.checked);
        return;
      }

      // Handle Delete Selected button
      if (e.target.id === 'btn-delete-selected-chapters' || e.target.closest('#btn-delete-selected-chapters')) {
        e.stopPropagation();
        await this._deleteSelectedChapters();
        return;
      }

      // Handle Accept Chapter Outline button
      if (e.target.id === 'btn-accept-chapter-outline' || e.target.closest('#btn-accept-chapter-outline')) {
        e.stopPropagation();
        this._showAcceptOutlineConfirmation();
        return;
      }

      // Handle chapter delete button
      const deleteBtn = e.target.closest('.chapter-delete-btn');
      if (deleteBtn) {
        e.stopPropagation();
        const chapterId = deleteBtn.dataset.deleteChapter;
        if (chapterId) {
          await this._deleteChapter(chapterId);
        }
        return;
      }

      const treeItem = e.target.closest('.tree-item');
      const addBtn = e.target.closest('.tree-add');
      const charCard = e.target.closest('.character-card');

      if (treeItem) {
        const type = treeItem.dataset.type;
        const id = treeItem.dataset.id;

        if (type === 'chapter') {
          await this._loadChapter(id);
        } else if (type === 'note') {
          await this._openNoteEditor(id);
        }
      }

      if (charCard) {
        await this._openCharacterEditor(charCard.dataset.id);
      }

      if (addBtn) {
        const action = addBtn.dataset.action;
        if (action === 'add-chapter') {
          if (!this.state.currentProjectId) return;
          const chapters = await this.fs.getProjectChapters(this.state.currentProjectId);
          const nextNum = chapters.length + 1;
          const title = await this._prompt('Chapter Title', `Chapter ${nextNum}`);
          if (title) {
            try {
              const ch = await this.fs.createChapter({
                projectId: this.state.currentProjectId,
                chapterNumber: nextNum,
                title
              });
              this._chapterWordCounts[ch.id] = 0;
              await this._renderChapterList();
              await this._loadChapter(ch.id);
            } catch (err) {
              console.error('Failed to create chapter:', err);
            }
          }
        } else if (action === 'add-character') {
          const name = await this._prompt('Character Name', 'New Character');
          if (name && this.state.currentProjectId) {
            await this.manuscript.createCharacter(this.state.currentProjectId, { name });
            await this._renderCharactersList();
          }
        } else if (action === 'add-note') {
          const title = await this._prompt('Note Title', 'New Note');
          if (title && this.state.currentProjectId) {
            await this.manuscript.createNote(this.state.currentProjectId, { title });
            await this._renderNotesList();
          }
        }
      }
    });

    // --- Toolbar buttons ---
    document.getElementById('btn-bold')?.addEventListener('click', () => this.editor.bold());
    document.getElementById('btn-italic')?.addEventListener('click', () => this.editor.italic());
    document.getElementById('btn-heading')?.addEventListener('click', () => this.editor.insertHeading());
    document.getElementById('btn-blockquote')?.addEventListener('click', () => this.editor.insertBlockquote());
    document.getElementById('btn-scene-break')?.addEventListener('click', () => this.editor.insertSceneBreak());
    document.getElementById('btn-undo')?.addEventListener('click', () => this.editor.undo());
    document.getElementById('btn-redo')?.addEventListener('click', () => this.editor.redo());

    // --- Help button ---
    document.getElementById('btn-help')?.addEventListener('click', () => {
      const overlay = document.getElementById('help-features-overlay');
      if (overlay) overlay.classList.add('visible');
    });
    document.getElementById('btn-help-close')?.addEventListener('click', () => {
      const overlay = document.getElementById('help-features-overlay');
      if (overlay) overlay.classList.remove('visible');
    });

    // --- Panel buttons ---
    document.getElementById('btn-generate')?.addEventListener('click', () => this.openGeneratePanel());
    document.getElementById('btn-analysis')?.addEventListener('click', () => this.openAnalysisPanel());
    document.getElementById('btn-export')?.addEventListener('click', () => this.openExportPanel());
    document.getElementById('btn-settings')?.addEventListener('click', () => this.openSettingsPanel());
    document.getElementById('btn-error-database')?.addEventListener('click', () => this.openErrorDatabasePanel());
    document.getElementById('btn-book-structure')?.addEventListener('click', () => this.openBookStructurePanel());

    // --- Panel overlay close ---
    document.getElementById('panel-overlay')?.addEventListener('click', () => this._closeAllPanels());
    document.querySelectorAll('.panel-close').forEach(btn => {
      btn.addEventListener('click', () => this._closeAllPanels());
    });

    // --- Export panel actions ---
    document.getElementById('export-plain')?.addEventListener('click', async () => {
      if (!this.state.currentProjectId) return;
      const result = await this.exporter.exportPlainText(this.state.currentProjectId);
      this.exporter.download(result);
    });
    document.getElementById('export-manuscript')?.addEventListener('click', async () => {
      if (!this.state.currentProjectId) return;
      const result = await this.exporter.exportManuscriptFormat(this.state.currentProjectId);
      this.exporter.download(result);
    });
    document.getElementById('export-html')?.addEventListener('click', async () => {
      if (!this.state.currentProjectId) return;
      const result = await this.exporter.exportStyledHtml(this.state.currentProjectId);
      this.exporter.download(result);
    });
    document.getElementById('export-json')?.addEventListener('click', async () => {
      if (!this.state.currentProjectId) return;
      const result = await this.exporter.exportJson(this.state.currentProjectId);
      this.exporter.download(result);
    });

    // --- Welcome screen buttons ---
    document.addEventListener('click', async (e) => {
      if (e.target.id === 'btn-new-project' || e.target.closest('#btn-new-project')) {
        await this._createNewProject();
      }
    });

    // --- Book structure inputs (live update) ---
    document.addEventListener('input', (e) => {
      if (e.target.id === 'bs-total-words' || e.target.id === 'bs-num-chapters') {
        this._updateWordsPerChapter();
      }
    });

    // --- Settings panel dynamic events ---
    document.addEventListener('change', async (e) => {
      if (e.target.id === 'setting-theme') {
        this.state.theme = e.target.value;
        this._applyTheme(this.state.theme);
        await this.localStorage.setSetting('theme', this.state.theme);
      }
      if (e.target.id === 'setting-daily-goal') {
        this.state.dailyGoal = parseInt(e.target.value) || 1000;
        await this.localStorage.setSetting('dailyGoal', this.state.dailyGoal);
      }
      if (e.target.id === 'bs-total-words' || e.target.id === 'bs-num-chapters') {
        this._updateWordsPerChapter();
      }
      if (e.target.id === 'structure-template-select') {
        await this.localStorage.setSetting('structureTemplate_' + this.state.currentProjectId, e.target.value);
        // Refresh the structure section within settings
        const container = document.getElementById('settings-structure-container');
        if (container && this._currentProject) {
          const totalWords = Object.values(this._chapterWordCounts).reduce((sum, wc) => sum + wc, 0);
          const templateId = e.target.value;
          const targetWords = this._currentProject.wordCountGoal || 80000;
          const guidance = this.structure.getPacingGuidance(templateId, targetWords, totalWords);
          const beats = this.structure.mapBeatsToManuscript(templateId, targetWords, totalWords);
          container.innerHTML = this._renderStructureInSettings(guidance, beats, this._currentProject, templateId);
        }
      }
      if (e.target.id === 'setting-project-genre') {
        const genreId = e.target.value;
        const subGroup = document.getElementById('subgenre-group');
        const subSelect = document.getElementById('setting-project-subgenre');
        if (subGroup && subSelect) {
          if (genreId) {
            subSelect.innerHTML = '<option value="">— None (use main genre rules) —</option>' + this._getSubgenreOptions(genreId, '');
            subGroup.style.display = '';
          } else {
            subSelect.innerHTML = '<option value="">— None (use main genre rules) —</option>';
            subGroup.style.display = 'none';
          }
        }
      }
      // New project modal genre change
      if (e.target.id === 'new-project-genre') {
        const genreId = e.target.value;
        const subGroup = document.getElementById('new-project-subgenre-group');
        const subSelect = document.getElementById('new-project-subgenre');
        if (subGroup && subSelect) {
          if (genreId) {
            subSelect.innerHTML = '<option value="">— None —</option>' + this._getSubgenreOptions(genreId, '');
            subGroup.style.display = '';
          } else {
            subSelect.innerHTML = '<option value="">— None —</option>';
            subGroup.style.display = 'none';
          }
        }
      }
    });

    document.addEventListener('click', async (e) => {
      if (e.target.id === 'btn-create-cover') {
        await this._generateCover(false);
      }
      if (e.target.id === 'btn-regenerate-cover') {
        await this._generateCover(true);
      }
      if (e.target.id === 'btn-edit-cover') {
        this._openEditCoverPanel();
      }
      if (e.target.id === 'btn-cover-edit-apply') {
        this._applyCoverEdits();
      }
      if (e.target.id === 'btn-cover-edit-save') {
        await this._saveCoverEdits();
      }
      if (e.target.id === 'btn-knowledge-paste') {
        this._showKnowledgePasteArea();
      }
      if (e.target.id === 'btn-knowledge-file') {
        document.getElementById('knowledge-file-input')?.click();
      }
      if (e.target.id === 'btn-knowledge-save') {
        await this._saveKnowledge();
      }
      if (e.target.classList.contains('knowledge-delete-btn')) {
        const id = e.target.dataset.knowledgeId;
        if (id) await this._deleteKnowledge(id);
      }
      if (e.target.id === 'export-cover-download') {
        await this._downloadCover();
      }
      if (e.target.id === 'save-project-settings') {
        await this._saveProjectSettings();
      }
      if (e.target.id === 'btn-delete-project') {
        await this._deleteCurrentProject();
      }
      if (e.target.id === 'btn-export-json') {
        if (!this.state.currentProjectId) return;
        const result = await this.exporter.exportJson(this.state.currentProjectId);
        this.exporter.download(result);
      }
      if (e.target.id === 'api-key-unlock-btn') {
        const pin = document.getElementById('api-key-pin-input')?.value || '';
        const stored = localStorage.getItem('genesis-api-pin');
        if (pin === stored) {
          document.getElementById('api-key-locked').style.display = 'none';
          document.getElementById('api-key-unlocked').style.display = 'block';
          document.getElementById('api-key-pin-input').value = '';
        } else {
          alert('Incorrect PIN.');
        }
      }
      if (e.target.id === 'api-key-lock-btn') {
        const pin = document.getElementById('api-key-set-pin')?.value || '';
        if (!pin || pin.length < 4) {
          alert('PIN must be at least 4 characters.');
          return;
        }
        localStorage.setItem('genesis-api-pin', pin);
        alert('PIN set. API key is now protected.');
        await this.openSettingsPanel();
      }
      if (e.target.id === 'api-key-remove-pin') {
        localStorage.removeItem('genesis-api-pin');
        alert('PIN removed.');
        await this.openSettingsPanel();
      }
      if (e.target.id === 'save-api-settings') {
        const key = document.getElementById('setting-api-key')?.value || '';
        const model = document.getElementById('setting-ai-model')?.value || 'claude-sonnet-4-5-20250929';
        await this.generator.setApiKey(key);
        await this.generator.setModel(model);
        alert('AI settings saved.');
      }
      if (e.target.id === 'save-hf-settings') {
        const token = document.getElementById('setting-hf-token')?.value || '';
        this._hfToken = token;
        await this.localStorage.setSetting('hfToken', token);
        alert('Cover settings saved.');
      }
      // --- Book Structure events ---
      if (e.target.id === 'btn-save-book-structure') {
        await this._saveBookStructure();
      }
      // --- New Project Help modal ---
      if (e.target.id === 'btn-help-create-project') {
        document.getElementById('new-project-help-overlay')?.classList.remove('visible');
        this._showNewProjectModal();
      }
      if (e.target.id === 'btn-generate-outlines') {
        await this._generateOutlines();
      }
      // --- Rethink events ---
      if (e.target.id === 'btn-continue-rethink' || e.target.closest('#btn-continue-rethink')) {
        await this._openRethinkModal();
      }
      if (e.target.id === 'btn-rethink-submit') {
        await this._submitRethink();
      }
      if (e.target.id === 'btn-rethink-cancel') {
        document.getElementById('rethink-overlay')?.classList.remove('visible');
      }
      // --- Prose Review events ---
      if (e.target.id === 'btn-prose-review-accept') {
        document.getElementById('prose-review-overlay')?.classList.remove('visible');
      }
      if (e.target.id === 'btn-prose-review-rewrite') {
        await this._rewriteProblems(null, 'all');
      }
      if (e.target.id === 'btn-prose-review-rewrite-serious') {
        await this._rewriteProblems(null, 'high');
      }
      if (e.target.id === 'btn-prose-review-rethink') {
        this._openProseRethinkModal();
      }
      if (e.target.id === 'btn-prose-rethink-submit') {
        await this._submitProseRethink();
      }
      if (e.target.id === 'btn-prose-rethink-cancel') {
        document.getElementById('prose-rethink-overlay')?.classList.remove('visible');
      }
      if (e.target.id === 'btn-save-ai-instructions') {
        const instructions = document.getElementById('generate-ai-instructions')?.value || '';
        if (this.state.currentProjectId) {
          await this.fs.updateProject(this.state.currentProjectId, { aiInstructions: instructions });
          this._currentProject = { ...this._currentProject, aiInstructions: instructions };
          alert('AI instructions saved.');
        }
      }
      // --- Accept Outline confirmation modal events ---
      if (e.target.id === 'btn-accept-outline-continue') {
        await this._acceptChapterOutlineAndGenerate();
      }
      if (e.target.id === 'btn-accept-outline-cancel') {
        document.getElementById('accept-outline-overlay')?.classList.remove('visible');
      }
      if (e.target.id === 'btn-generate-prose') {
        await this._runGeneration();
      }
      if (e.target.id === 'btn-generate-cancel') {
        this.generator.cancel();
        this._generateCancelled = true;
        this._autoWriteToGoal = false;
        this._setGenerateStatus(false);
        this._showIterativeOverlay(false);
        this._showIterativeScoringNotice(false);
        this._showContinueBar(true);
      }
      if (e.target.id === 'btn-iterative-write') {
        await this._iterativeWrite();
      }
      if (e.target.id === 'btn-iterative-cancel') {
        this._iterativeCancelled = true;
        this._generateCancelled = true;
        this.generator.cancel();
        this._showIterativeOverlay(false);
        this._showIterativeScoringNotice(false);
        this._setGenerateStatus(false);
        this._showContinueBar(true);
      }
      // Note: btn-iterative-accept and btn-iterative-accept-stop handlers are now
      // attached directly in _showFinalFixScreen() to avoid conflicts with the
      // dynamically generated footer buttons. Only handle legacy reject if present.
      if (e.target.id === 'btn-iterative-reject') {
        // Reject — keep refining the same paragraph
        document.getElementById('iterative-accept-overlay')?.classList.remove('visible');
        const logEl = document.getElementById('iterative-status-log');
        if (logEl) logEl.textContent = 'Continuing refinement\u2026';
        // Reset iteration tracking and continue refining
        this._iterPrevScore = 0;
        this._iterPrevIssueCount = 0;
        this._iterPrevSubscores = {};
        await this._iterativeScoreAndRefine(this._iterativeAcceptText || this._lastGeneratedText, 0, 0);
      }
      if (e.target.id === 'btn-generate-open-settings') {
        this._closeAllPanels();
        setTimeout(() => this.openSettingsPanel(), 100);
      }
      // Continue Writing word-count buttons (+1000, +2000, +3000)
      const continueBtn = e.target.closest('.continue-word-btn');
      if (continueBtn) {
        // Close prose review modal if the button was clicked from there
        document.getElementById('prose-review-overlay')?.classList.remove('visible');
        const wordTarget = parseInt(continueBtn.dataset.words) || 1000;
        await this._handleContinueWriting(wordTarget);
      }
      if (e.target.id === 'btn-continue-to-target' || e.target.closest('#btn-continue-to-target')) {
        await this._handleWriteToGoal();
      }
      if (e.target.id === 'btn-continue-dismiss' || e.target.closest('#btn-continue-dismiss')) {
        this._showContinueBar(false);
      }
    });

    // --- Auto-save on visibility change ---
    document.addEventListener('visibilitychange', async () => {
      if (document.hidden) {
        await this._saveCurrentChapter();
      }
    });

    // --- Before unload save ---
    window.addEventListener('beforeunload', () => {
      this._saveCurrentChapter();
    });

    // --- Flyout Tooltip System ---
    this._initTooltips();
  }

  // ========================================
  //  Flyout Tooltip System
  // ========================================

  _initTooltips() {
    const flyout = document.getElementById('tooltip-flyout');
    if (!flyout) return;
    const body = flyout.querySelector('.tooltip-body');

    let touchTimer = null;
    let activeEl = null;
    let hoverTimer = null;

    const show = (el) => {
      const text = el.dataset.tooltip;
      if (!text) return;
      body.textContent = text;
      flyout.className = 'visible';
      activeEl = el;

      // Position the tooltip relative to the element
      const rect = el.getBoundingClientRect();
      const fw = flyout.offsetWidth;
      const fh = flyout.offsetHeight;
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      // Horizontal: center on element, clamp to viewport
      let left = rect.left + rect.width / 2 - fw / 2;
      left = Math.max(8, Math.min(left, vw - fw - 8));

      // Arrow horizontal position
      const arrowX = Math.max(16, Math.min(rect.left + rect.width / 2 - left, fw - 16));
      flyout.style.setProperty('--arrow-x', arrowX + 'px');

      // Vertical: prefer below the element, flip above if not enough room
      const gap = 8;
      let top;
      if (rect.bottom + gap + fh < vh) {
        top = rect.bottom + gap;
        flyout.classList.add('arrow-top');
      } else {
        top = rect.top - gap - fh;
        flyout.classList.add('arrow-bottom');
      }
      top = Math.max(8, Math.min(top, vh - fh - 8));

      flyout.style.left = left + 'px';
      flyout.style.top = top + 'px';
    };

    const hide = () => {
      flyout.className = '';
      flyout.style.left = '';
      flyout.style.top = '';
      activeEl = null;
      clearTimeout(touchTimer);
      clearTimeout(hoverTimer);
    };

    // Touch: long-press (600ms hold) shows tooltip
    document.addEventListener('touchstart', (e) => {
      const el = e.target.closest('[data-tooltip]');
      if (!el) { hide(); return; }
      clearTimeout(touchTimer);
      touchTimer = setTimeout(() => {
        show(el);
        // Prevent the tap from also firing as a click
        el.addEventListener('click', preventClick, { once: true, capture: true });
      }, 600);
    }, { passive: true });

    const preventClick = (e) => {
      e.preventDefault();
      e.stopPropagation();
    };

    document.addEventListener('touchend', () => {
      clearTimeout(touchTimer);
    }, { passive: true });

    document.addEventListener('touchmove', () => {
      clearTimeout(touchTimer);
    }, { passive: true });

    // Tap anywhere dismisses tooltip
    document.addEventListener('touchstart', (e) => {
      if (activeEl && !e.target.closest('#tooltip-flyout')) {
        // Small delay to avoid immediately dismissing on the same touch
        setTimeout(() => { if (activeEl) hide(); }, 50);
      }
    }, { passive: true });

    // Mouse: hover shows tooltip after 400ms delay
    document.addEventListener('mouseover', (e) => {
      const el = e.target.closest('[data-tooltip]');
      if (!el || el === activeEl) return;
      hide();
      hoverTimer = setTimeout(() => show(el), 400);
    });

    document.addEventListener('mouseout', (e) => {
      const el = e.target.closest('[data-tooltip]');
      if (el) hide();
    });
  }

  // ========================================
  //  Helper Methods
  // ========================================

  _updateStatusBarLocal() {
    const total = Object.values(this._chapterWordCounts).reduce((sum, wc) => sum + wc, 0);
    const project = this._currentProject;
    const goal = project ? (project.wordCountGoal || 80000) : 80000;
    const progress = Math.round((total / goal) * 100);

    const el = (id) => document.getElementById(id);
    if (el('status-total')) el('status-total').textContent = total.toLocaleString();
    if (el('status-goal')) el('status-goal').textContent = goal.toLocaleString();
    if (el('status-progress')) el('status-progress').textContent = progress + '%';
    if (el('status-daily')) el('status-daily').textContent = `${this.state.wordsToday} / ${this.state.dailyGoal}`;
    if (el('fwc-total')) el('fwc-total').textContent = total.toLocaleString();
    if (el('fwc-progress')) el('fwc-progress').textContent = progress + '%';
  }

  async _loadDailyProgress() {
    const today = new Date().toISOString().split('T')[0];
    this.state.wordsToday = await this.localStorage.getSetting('wordsToday_' + today, 0);
  }

  _trackDailyWords(currentChapterWords) {
    const today = new Date().toISOString().split('T')[0];
    const key = 'wordsToday_' + today;
    const updated = Math.max(this.state.wordsToday, currentChapterWords);
    this.state.wordsToday = updated;
    this.localStorage.setSetting(key, updated);
    // Update daily display
    const dailyEl = document.getElementById('status-daily');
    if (dailyEl) dailyEl.textContent = `${updated.toLocaleString()} / ${this.state.dailyGoal.toLocaleString()}`;
  }

  _applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme === 'dark' ? '' : theme);
    if (theme === 'dark') document.documentElement.removeAttribute('data-theme');
  }

  async _saveProjectSettings() {
    if (!this.state.currentProjectId) return;
    const title = document.getElementById('setting-project-name')?.value;
    const genre = document.getElementById('setting-project-genre')?.value || '';
    const subgenre = document.getElementById('setting-project-subgenre')?.value || '';
    const voice = document.getElementById('setting-project-voice')?.value || 'auto';

    try {
      await this.fs.updateProject(this.state.currentProjectId, {
        title, genre, subgenre, voice
      });

      // Update cached project
      this._currentProject = { ...this._currentProject, title, genre, subgenre, voice };
      document.getElementById('project-title').textContent = title;
      this._updateStatusBarLocal();
      this._closeAllPanels();
    } catch (err) {
      console.error('Failed to save project settings:', err);
      alert('Failed to save settings.');
    }
  }

  async _deleteCurrentProject() {
    if (!this.state.currentProjectId) return;
    if (!confirm('Delete this entire project? This cannot be undone.')) return;
    if (!confirm('Are you absolutely sure? All chapters will be permanently deleted.')) return;

    try {
      // Stop auto-save
      if (this._autoSaveInterval) {
        clearInterval(this._autoSaveInterval);
        this._autoSaveInterval = null;
      }
      this.state.currentChapterId = null;

      await this.fs.deleteProject(this.state.currentProjectId);

      this.state.currentProjectId = null;
      this._currentProject = null;
      this._chapterWordCounts = {};
      this._closeAllPanels();
      await this._showLanding();
    } catch (err) {
      console.error('Failed to delete project:', err);
      alert('Failed to delete project.');
    }
  }

  async _deleteChapter(chapterId) {
    if (!confirm('Delete this chapter? This cannot be undone.')) return;

    try {
      // If deleting the currently loaded chapter, clear the editor and reset word count
      if (this.state.currentChapterId === chapterId) {
        this.state.currentChapterId = null;
        this.editor.clear();
        this._showWelcome();
        const wcEl = document.getElementById('status-words');
        if (wcEl) wcEl.textContent = '0';
        const fwcWords = document.getElementById('fwc-words');
        if (fwcWords) fwcWords.textContent = '0';
      }

      await this.fs.deleteChapter(chapterId);
      delete this._chapterWordCounts[chapterId];

      // Renumber remaining chapters
      const chapters = await this.fs.getProjectChapters(this.state.currentProjectId);
      const orderedIds = chapters.map(ch => ch.id);
      if (orderedIds.length > 0) {
        await this.fs.reorderChapters(this.state.currentProjectId, orderedIds);
      }

      await this._renderChapterList();
      this._updateStatusBarLocal();
    } catch (err) {
      console.error('Failed to delete chapter:', err);
      alert('Failed to delete chapter.');
    }
  }

  _updateDeleteSelectedBtn() {
    const checked = document.querySelectorAll('.chapter-checkbox:checked');
    const btn = document.getElementById('btn-delete-selected-chapters');
    if (btn) {
      btn.disabled = checked.length === 0;
      btn.textContent = checked.length > 0 ? `Delete Selected (${checked.length})` : 'Delete Selected';
    }
    // Sync "Select All" checkbox state
    const selectAll = document.getElementById('chapter-select-all');
    const allBoxes = document.querySelectorAll('.chapter-checkbox');
    if (selectAll && allBoxes.length > 0) {
      selectAll.checked = checked.length === allBoxes.length;
      selectAll.indeterminate = checked.length > 0 && checked.length < allBoxes.length;
    }
  }

  _toggleSelectAll(checked) {
    document.querySelectorAll('.chapter-checkbox').forEach(cb => {
      cb.checked = checked;
    });
    this._updateDeleteSelectedBtn();
  }

  async _deleteSelectedChapters() {
    const checked = document.querySelectorAll('.chapter-checkbox:checked');
    if (checked.length === 0) return;

    const count = checked.length;
    if (!confirm(`Delete ${count} selected chapter${count > 1 ? 's' : ''}? This cannot be undone.`)) return;

    try {
      const idsToDelete = Array.from(checked).map(cb => cb.dataset.chapterId);

      for (const chapterId of idsToDelete) {
        if (this.state.currentChapterId === chapterId) {
          this.state.currentChapterId = null;
          this.editor.clear();
          this._showWelcome();
          const wcEl = document.getElementById('status-words');
          if (wcEl) wcEl.textContent = '0';
          const fwcWords = document.getElementById('fwc-words');
          if (fwcWords) fwcWords.textContent = '0';
        }

        await this.fs.deleteChapter(chapterId);
        delete this._chapterWordCounts[chapterId];
      }

      // Renumber remaining chapters
      const chapters = await this.fs.getProjectChapters(this.state.currentProjectId);
      const orderedIds = chapters.map(ch => ch.id);
      if (orderedIds.length > 0) {
        await this.fs.reorderChapters(this.state.currentProjectId, orderedIds);
      }

      await this._renderChapterList();
      this._updateStatusBarLocal();
    } catch (err) {
      console.error('Failed to delete selected chapters:', err);
      alert('Failed to delete selected chapters.');
    }
  }

  _showAcceptOutlineConfirmation() {
    const overlay = document.getElementById('accept-outline-overlay');
    if (overlay) overlay.classList.add('visible');
  }

  async _acceptChapterOutlineAndGenerate() {
    // Close the confirmation modal
    const overlay = document.getElementById('accept-outline-overlay');
    if (overlay) overlay.classList.remove('visible');

    // Ensure we have a current chapter with an outline
    if (!this.state.currentChapterId) {
      alert('Please select a chapter first.');
      return;
    }

    if (!this._currentChapterOutline) {
      alert('The current chapter has no outline. Generate outlines first via Structure.');
      return;
    }

    if (!this.generator.hasApiKey()) {
      alert('Set your Anthropic API key in Settings first.');
      return;
    }

    // Open the generate panel with outline pre-filled, then auto-trigger generation
    await this.openGeneratePanel();

    // Auto-fill the plot field with the chapter outline if not already set
    const plotEl = document.getElementById('generate-plot');
    if (plotEl && !plotEl.value?.trim()) {
      plotEl.value = this._currentChapterOutline;
    }

    // Trigger generation
    await this._runGeneration();
  }

  async _openCharacterEditor(charId) {
    const character = await this.localStorage.get(STORE_NAMES.characters, charId);
    if (!character) return;

    const body = document.getElementById('panel-analysis-body');
    if (!body) return;

    body.innerHTML = `
      <div class="analysis-section">
        <h3>Character Details</h3>
        <div class="form-group">
          <label>Name</label>
          <input type="text" class="form-input" id="char-name" value="${this._esc(character.name)}">
        </div>
        <div class="form-group">
          <label>Role</label>
          <select class="form-input" id="char-role">
            <option value="protagonist" ${character.role === 'protagonist' ? 'selected' : ''}>Protagonist</option>
            <option value="antagonist" ${character.role === 'antagonist' ? 'selected' : ''}>Antagonist</option>
            <option value="supporting" ${character.role === 'supporting' ? 'selected' : ''}>Supporting</option>
            <option value="minor" ${character.role === 'minor' ? 'selected' : ''}>Minor</option>
          </select>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea class="form-input" id="char-desc" rows="3">${this._esc(character.description || '')}</textarea>
        </div>
        <div class="form-group">
          <label>Motivation / Want</label>
          <textarea class="form-input" id="char-motivation" rows="2">${this._esc(character.motivation || '')}</textarea>
        </div>
        <div class="form-group">
          <label>Character Arc</label>
          <textarea class="form-input" id="char-arc" rows="3">${this._esc(character.arc || '')}</textarea>
        </div>
        <div class="form-group">
          <label>Notes</label>
          <textarea class="form-input" id="char-notes" rows="3">${this._esc(character.notes || '')}</textarea>
        </div>
        <button class="btn btn-primary" id="save-character" data-id="${charId}" style="width:100%;">Save Character</button>
        <button class="btn btn-sm" id="delete-character" data-id="${charId}" style="width:100%;margin-top:8px;border-color:var(--danger);color:var(--danger);">Delete Character</button>
      </div>
    `;

    document.getElementById('save-character')?.addEventListener('click', async () => {
      await this.manuscript.updateCharacter(charId, {
        name: document.getElementById('char-name')?.value,
        role: document.getElementById('char-role')?.value,
        description: document.getElementById('char-desc')?.value,
        motivation: document.getElementById('char-motivation')?.value,
        arc: document.getElementById('char-arc')?.value,
        notes: document.getElementById('char-notes')?.value
      });
      this._closeAllPanels();
      await this._renderCharactersList();
    });

    document.getElementById('delete-character')?.addEventListener('click', async () => {
      if (confirm('Delete this character?')) {
        await this.manuscript.deleteCharacter(charId);
        this._closeAllPanels();
        await this._renderCharactersList();
      }
    });

    this._showPanel('analysis');
  }

  async _openNoteEditor(noteId) {
    const note = await this.localStorage.get(STORE_NAMES.notes, noteId);
    if (!note) return;

    const body = document.getElementById('panel-analysis-body');
    if (!body) return;

    body.innerHTML = `
      <div class="analysis-section">
        <h3>Note</h3>
        <div class="form-group">
          <label>Title</label>
          <input type="text" class="form-input" id="note-title" value="${this._esc(note.title)}">
        </div>
        <div class="form-group">
          <label>Type</label>
          <select class="form-input" id="note-type">
            <option value="general" ${note.type === 'general' ? 'selected' : ''}>General</option>
            <option value="worldbuilding" ${note.type === 'worldbuilding' ? 'selected' : ''}>World Building</option>
            <option value="research" ${note.type === 'research' ? 'selected' : ''}>Research</option>
            <option value="plot" ${note.type === 'plot' ? 'selected' : ''}>Plot</option>
          </select>
        </div>
        <div class="form-group">
          <label>Content</label>
          <textarea class="form-input" id="note-content" rows="10">${this._esc(note.content || '')}</textarea>
        </div>
        <button class="btn btn-primary" id="save-note" data-id="${noteId}" style="width:100%;">Save Note</button>
        <button class="btn btn-sm" id="delete-note" data-id="${noteId}" style="width:100%;margin-top:8px;border-color:var(--danger);color:var(--danger);">Delete Note</button>
      </div>
    `;

    document.getElementById('save-note')?.addEventListener('click', async () => {
      await this.manuscript.updateNote(noteId, {
        title: document.getElementById('note-title')?.value,
        type: document.getElementById('note-type')?.value,
        content: document.getElementById('note-content')?.value
      });
      this._closeAllPanels();
      await this._renderNotesList();
    });

    document.getElementById('delete-note')?.addEventListener('click', async () => {
      if (confirm('Delete this note?')) {
        await this.manuscript.deleteNote(noteId);
        this._closeAllPanels();
        await this._renderNotesList();
      }
    });

    this._showPanel('analysis');
  }

  _prompt(label, defaultValue = '') {
    return new Promise((resolve) => {
      const result = prompt(label, defaultValue);
      resolve(result);
    });
  }

  _getSubgenreOptions(genreId, selectedSubgenre) {
    if (!genreId || !window.GENRE_DATA) return '';
    const genre = window.GENRE_DATA.find(g => g.id === genreId);
    if (!genre || !genre.subgenres) return '';
    return genre.subgenres.map(s =>
      `<option value="${s.id}" ${selectedSubgenre === s.id ? 'selected' : ''}>${s.label}</option>`
    ).join('');
  }

  _getGenreRules(genreId, subgenreId) {
    if (!genreId || !window.GENRE_DATA) return null;
    const genre = window.GENRE_DATA.find(g => g.id === genreId);
    if (!genre) return null;
    let rules = genre.rules;
    let label = genre.label;
    if (subgenreId && genre.subgenres) {
      const sub = genre.subgenres.find(s => s.id === subgenreId);
      if (sub) {
        rules += '\n\nSubgenre-specific rules (' + sub.label + '): ' + sub.rules;
        label = sub.label;
      }
    }
    return { label, rules };
  }

  /**
   * Format generated prose HTML: convert chapter headings to H1, scene breaks to centered markers.
   */
  _formatGeneratedHtml(html, chapterTitle) {
    if (!html) return html;
    // Convert scene break paragraphs (e.g. "* * *") to centered format
    html = html.replace(/<p>\s*\*\s*\*\s*\*\s*<\/p>/gi, '<p style="text-align:center;text-indent:0">* * *</p>');

    // If the first paragraph matches the chapter title, convert it to H1
    if (chapterTitle) {
      const escapedTitle = chapterTitle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const h1Regex = new RegExp(`^(<p>)(\\s*${escapedTitle}\\s*)(</p>)`, 'i');
      html = html.replace(h1Regex, '<h1 style="text-align:center;margin:1em 0 0.5em;font-size:1.8em;">$2</h1>');
    }
    return html;
  }

  /**
   * Strip em dashes and en dashes from generated text, replacing with commas or appropriate punctuation.
   */
  _stripEmDashes(text) {
    if (!text) return text;
    // Replace em dash (U+2014) and en dash (U+2013) surrounded by spaces with comma
    text = text.replace(/\s*\u2014\s*/g, ', ');
    text = text.replace(/\s*\u2013\s*/g, ', ');
    // Replace double/triple hyphens used as em dashes
    text = text.replace(/\s*---\s*/g, ', ');
    text = text.replace(/\s*--\s*/g, ', ');
    // Clean up double commas or comma-period
    text = text.replace(/,\s*,/g, ',');
    text = text.replace(/,\s*\./g, '.');
    text = text.replace(/,\s*!/g, '!');
    text = text.replace(/,\s*\?/g, '?');
    return text;
  }

  _esc(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ======== Edit Cover Methods ========

  _openEditCoverPanel() {
    const project = this._currentProject;
    if (!project?.coverImage) {
      alert('Generate a cover first before editing.');
      return;
    }
    const panel = document.getElementById('panel-edit-cover');
    if (!panel) return;
    panel.classList.add('visible');

    // Populate fields from project
    const titleInput = document.getElementById('cover-edit-title');
    const subtitleInput = document.getElementById('cover-edit-subtitle');
    const authorInput = document.getElementById('cover-edit-author');
    if (titleInput) titleInput.value = project.coverTitle || project.title || '';
    if (subtitleInput) subtitleInput.value = project.coverSubtitle || project.subtitle || '';
    if (authorInput) authorInput.value = project.coverAuthor || this.state.currentUser || '';

    // Load saved cover edit settings
    const fontInput = document.getElementById('cover-edit-font');
    const sizeInput = document.getElementById('cover-edit-fontsize');
    const colorInput = document.getElementById('cover-edit-color');
    const posInput = document.getElementById('cover-edit-position');
    const shadowInput = document.getElementById('cover-edit-shadow');
    if (fontInput) fontInput.value = project.coverFont || 'Georgia';
    if (sizeInput) {
      sizeInput.value = project.coverFontSize || 48;
      const label = document.getElementById('cover-edit-fontsize-label');
      if (label) label.textContent = (project.coverFontSize || 48) + 'px';
    }
    if (colorInput) colorInput.value = project.coverTextColor || '#ffffff';
    if (posInput) posInput.value = project.coverTextPosition || 'bottom';
    if (shadowInput) shadowInput.value = project.coverTextShadow || 'light';

    // Set up live font size label update
    if (sizeInput) {
      sizeInput.oninput = () => {
        const label = document.getElementById('cover-edit-fontsize-label');
        if (label) label.textContent = sizeInput.value + 'px';
      };
    }

    // Draw initial preview
    this._drawCoverPreview();
  }

  _drawCoverPreview() {
    const project = this._currentProject;
    if (!project?.coverImage) return;

    const canvas = document.getElementById('cover-edit-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const titleText = document.getElementById('cover-edit-title')?.value || '';
    const subtitleText = document.getElementById('cover-edit-subtitle')?.value || '';
    const authorText = document.getElementById('cover-edit-author')?.value || '';
    const fontFamily = document.getElementById('cover-edit-font')?.value || 'Georgia';
    const fontSize = parseInt(document.getElementById('cover-edit-fontsize')?.value || '48', 10);
    const textColor = document.getElementById('cover-edit-color')?.value || '#ffffff';
    const position = document.getElementById('cover-edit-position')?.value || 'bottom';
    const shadow = document.getElementById('cover-edit-shadow')?.value || 'light';

    // Use base image (without text) if available, otherwise fall back to coverImage
    const imageSrc = project.coverImageBase || project.coverImage;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      // Cap canvas dimensions to keep JPEG output under Firestore's 1MB field limit
      const MAX_DIM = 800;
      let w = img.width || 600;
      let h = img.height || 900;
      if (w > MAX_DIM || h > MAX_DIM) {
        const ratio = Math.min(MAX_DIM / w, MAX_DIM / h);
        w = Math.round(w * ratio);
        h = Math.round(h * ratio);
      }
      canvas.width = w;
      canvas.height = h;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      // Apply text shadow
      if (shadow === 'light') {
        ctx.shadowColor = 'rgba(0,0,0,0.6)';
        ctx.shadowBlur = 4;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
      } else if (shadow === 'heavy') {
        ctx.shadowColor = 'rgba(0,0,0,0.9)';
        ctx.shadowBlur = 8;
        ctx.shadowOffsetX = 3;
        ctx.shadowOffsetY = 3;
      }

      ctx.fillStyle = textColor;
      ctx.textAlign = 'center';

      // Calculate Y position
      let titleY, subtitleY, authorY;
      if (position === 'top') {
        titleY = fontSize + 30;
        subtitleY = titleY + fontSize * 0.6 + 10;
        authorY = canvas.height - 40;
      } else if (position === 'center') {
        titleY = canvas.height / 2 - fontSize * 0.3;
        subtitleY = titleY + fontSize * 0.6 + 10;
        authorY = canvas.height - 40;
      } else {
        titleY = canvas.height - 120;
        subtitleY = titleY + fontSize * 0.6 + 10;
        authorY = canvas.height - 40;
      }

      const centerX = canvas.width / 2;

      // Draw title
      if (titleText) {
        ctx.font = `bold ${fontSize}px "${fontFamily}"`;
        ctx.fillText(titleText, centerX, titleY, canvas.width - 40);
      }

      // Draw subtitle
      if (subtitleText) {
        ctx.font = `${Math.round(fontSize * 0.5)}px "${fontFamily}"`;
        ctx.fillText(subtitleText, centerX, subtitleY, canvas.width - 40);
      }

      // Draw author
      if (authorText) {
        ctx.shadowBlur = Math.max(ctx.shadowBlur - 2, 0);
        ctx.font = `${Math.round(fontSize * 0.4)}px "${fontFamily}"`;
        ctx.fillText(authorText, centerX, authorY, canvas.width - 40);
      }
    };
    img.src = imageSrc;
  }

  _applyCoverEdits() {
    this._drawCoverPreview();
  }

  async _saveCoverEdits() {
    const project = this._currentProject;
    if (!project) return;

    const canvas = document.getElementById('cover-edit-canvas');
    if (!canvas) return;

    // Redraw to make sure canvas is current
    this._drawCoverPreview();

    // Wait a moment for the image to draw
    await new Promise(r => setTimeout(r, 300));

    try {
      // Firestore has a 1,048,487 byte limit per field value.
      // We must keep the data URL string under this limit.
      const MAX_BYTES = 1000000;

      // Step 1: Try progressive JPEG quality reduction
      let quality = 0.85;
      let sourceCanvas = canvas;
      let dataUrl = sourceCanvas.toDataURL('image/jpeg', quality);

      while (dataUrl.length > MAX_BYTES && quality > 0.1) {
        quality -= 0.05;
        dataUrl = sourceCanvas.toDataURL('image/jpeg', quality);
      }

      // Step 2: If still too large, downscale image dimensions
      if (dataUrl.length > MAX_BYTES) {
        let scale = 0.8;
        while (dataUrl.length > MAX_BYTES && scale >= 0.3) {
          const tempCanvas = document.createElement('canvas');
          tempCanvas.width = Math.round(canvas.width * scale);
          tempCanvas.height = Math.round(canvas.height * scale);
          const tempCtx = tempCanvas.getContext('2d');
          tempCtx.drawImage(canvas, 0, 0, tempCanvas.width, tempCanvas.height);
          dataUrl = tempCanvas.toDataURL('image/jpeg', 0.6);
          scale -= 0.1;
        }
      }

      // Save cover typography settings
      const updates = {
        coverImage: dataUrl,
        coverTitle: document.getElementById('cover-edit-title')?.value || '',
        coverSubtitle: document.getElementById('cover-edit-subtitle')?.value || '',
        coverAuthor: document.getElementById('cover-edit-author')?.value || '',
        coverFont: document.getElementById('cover-edit-font')?.value || 'Georgia',
        coverFontSize: parseInt(document.getElementById('cover-edit-fontsize')?.value || '48', 10),
        coverTextColor: document.getElementById('cover-edit-color')?.value || '#ffffff',
        coverTextPosition: document.getElementById('cover-edit-position')?.value || 'bottom',
        coverTextShadow: document.getElementById('cover-edit-shadow')?.value || 'light'
      };

      await this.fs.updateProject(project.id, updates);
      Object.assign(project, updates);
      this._updateCoverDisplay();

      document.getElementById('panel-edit-cover')?.classList.remove('visible');
    } catch (err) {
      alert('Failed to save cover: ' + err.message);
    }
  }

  // ======== Import Knowledge Methods ========

  _openImportKnowledgePanel() {
    const panel = document.getElementById('panel-import-knowledge');
    if (!panel) return;
    panel.classList.add('visible');

    // Reset form
    const titleInput = document.getElementById('knowledge-title');
    const contentArea = document.getElementById('knowledge-content');
    const pasteArea = document.getElementById('knowledge-paste-area');
    const fileInfo = document.getElementById('knowledge-file-info');
    if (titleInput) titleInput.value = '';
    if (contentArea) contentArea.value = '';
    if (pasteArea) pasteArea.style.display = 'none';
    if (fileInfo) fileInfo.style.display = 'none';

    // Set up file input handler
    const fileInput = document.getElementById('knowledge-file-input');
    if (fileInput) {
      fileInput.onchange = (e) => this._handleKnowledgeFile(e);
    }

    // Render existing knowledge list
    this._renderKnowledgeList();
  }

  _showKnowledgePasteArea() {
    const pasteArea = document.getElementById('knowledge-paste-area');
    const fileInfo = document.getElementById('knowledge-file-info');
    if (pasteArea) pasteArea.style.display = '';
    if (fileInfo) fileInfo.style.display = 'none';
    this._knowledgeFileContent = null;
  }

  _handleKnowledgeFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    const pasteArea = document.getElementById('knowledge-paste-area');
    const fileInfo = document.getElementById('knowledge-file-info');
    if (pasteArea) pasteArea.style.display = 'none';

    const reader = new FileReader();
    reader.onload = () => {
      this._knowledgeFileContent = reader.result;
      if (fileInfo) {
        fileInfo.style.display = '';
        fileInfo.textContent = `File loaded: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
      }
      // Auto-fill title from filename if empty
      const titleInput = document.getElementById('knowledge-title');
      if (titleInput && !titleInput.value) {
        titleInput.value = file.name.replace(/\.[^.]+$/, '');
      }
    };
    reader.onerror = () => {
      alert('Failed to read file.');
    };
    reader.readAsText(file);
  }

  async _saveKnowledge() {
    const project = this._currentProject;
    if (!project) {
      alert('Open a project first.');
      return;
    }

    const title = document.getElementById('knowledge-title')?.value?.trim();
    if (!title) {
      alert('Please enter a title for this knowledge entry.');
      return;
    }

    const type = document.getElementById('knowledge-type')?.value || 'research';
    const pastedContent = document.getElementById('knowledge-content')?.value?.trim();
    const content = this._knowledgeFileContent || pastedContent;

    if (!content) {
      alert('Please paste text or upload a file.');
      return;
    }

    const entry = {
      id: `kb_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      projectId: project.id,
      title,
      type,
      content,
      wordCount: (content.match(/[a-zA-Z'''\u2019-]+/g) || []).length,
      createdAt: Date.now()
    };

    try {
      await this.localStorage.put('knowledgeBase', entry);
      this._knowledgeFileContent = null;

      // Reset form
      const titleInput = document.getElementById('knowledge-title');
      const contentArea = document.getElementById('knowledge-content');
      const pasteArea = document.getElementById('knowledge-paste-area');
      const fileInfo = document.getElementById('knowledge-file-info');
      if (titleInput) titleInput.value = '';
      if (contentArea) contentArea.value = '';
      if (pasteArea) pasteArea.style.display = 'none';
      if (fileInfo) fileInfo.style.display = 'none';

      this._renderKnowledgeList();
    } catch (err) {
      alert('Failed to save knowledge: ' + err.message);
    }
  }

  async _deleteKnowledge(knowledgeId) {
    if (!confirm('Delete this knowledge entry?')) return;
    try {
      await this.localStorage.delete('knowledgeBase', knowledgeId);
      this._renderKnowledgeList();
    } catch (err) {
      alert('Failed to delete: ' + err.message);
    }
  }

  async _renderKnowledgeList() {
    const listEl = document.getElementById('knowledge-list');
    if (!listEl) return;

    const project = this._currentProject;
    if (!project) {
      listEl.innerHTML = '<p style="color:var(--text-muted); font-size:13px;">Open a project first.</p>';
      return;
    }

    try {
      const allKnowledge = await this.localStorage.getAll('knowledgeBase');
      const projectKnowledge = allKnowledge.filter(k => k.projectId === project.id);

      if (projectKnowledge.length === 0) {
        listEl.innerHTML = '<p style="color:var(--text-muted); font-size:13px;">No knowledge imported yet.</p>';
        return;
      }

      const typeLabels = {
        research: 'Research',
        reference: 'Reference',
        wikipedia: 'Wikipedia',
        notes: 'Notes',
        other: 'Other'
      };

      listEl.innerHTML = projectKnowledge.map(k => `
        <div style="padding:8px; margin-bottom:8px; background:var(--bg-secondary); border-radius:var(--radius-sm); border:1px solid var(--border-color);">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <strong style="font-size:14px;">${this._esc(k.title)}</strong>
            <button class="btn btn-sm knowledge-delete-btn" data-knowledge-id="${k.id}" style="padding:2px 8px; border-color:var(--danger); color:var(--danger); font-size:12px;">&times;</button>
          </div>
          <div style="font-size:12px; color:var(--text-muted); margin-top:4px;">
            ${typeLabels[k.type] || k.type} &bull; ${(k.wordCount || 0).toLocaleString()} words &bull; ${new Date(k.createdAt).toLocaleDateString()}
          </div>
        </div>
      `).join('');
    } catch (err) {
      listEl.innerHTML = '<p style="color:var(--text-muted); font-size:13px;">Failed to load knowledge.</p>';
    }
  }

  async _getProjectKnowledge() {
    const project = this._currentProject;
    if (!project) return '';

    try {
      const allKnowledge = await this.localStorage.getAll('knowledgeBase');
      const projectKnowledge = allKnowledge.filter(k => k.projectId === project.id);
      if (projectKnowledge.length === 0) return '';

      let knowledgePrompt = '\n=== PROJECT KNOWLEDGE BASE (AUTHORITATIVE REFERENCE MATERIALS) ===\n';
      knowledgePrompt += 'The following reference materials have been imported for this project. You MUST actively consult them during writing.\n';
      knowledgePrompt += 'INSTRUCTIONS:\n';
      knowledgePrompt += '- Use facts, names, dates, locations, and details from these materials for accuracy\n';
      knowledgePrompt += '- Incorporate relevant information to enrich prose, outlines, and character development\n';
      knowledgePrompt += '- When knowledge files contain historical facts, technical details, or world-building, weave them naturally into the narrative\n';
      knowledgePrompt += '- Do NOT contradict information in these reference materials\n\n';

      // Build a brief overview index first
      knowledgePrompt += 'KNOWLEDGE FILES INDEX:\n';
      for (let i = 0; i < projectKnowledge.length; i++) {
        const k = projectKnowledge[i];
        const wordCount = (k.content.match(/[a-zA-Z]+/g) || []).length;
        knowledgePrompt += `  ${i + 1}. "${k.title}" (${k.type}) — ${wordCount.toLocaleString()} words\n`;
      }
      knowledgePrompt += '\nFULL REFERENCE MATERIALS:\n\n';

      for (const k of projectKnowledge) {
        // Truncate very long knowledge entries to keep prompt manageable
        const truncated = k.content.length > 8000
          ? k.content.slice(0, 8000) + '\n[... truncated ...]'
          : k.content;
        knowledgePrompt += `--- ${k.title} (${k.type}) ---\n${truncated}\n\n`;
      }

      knowledgePrompt += '=== END PROJECT KNOWLEDGE BASE ===\n';

      // Silently log the scan (no UI display)
      console.log(`[Knowledge Scan] Project "${project.title}": ${projectKnowledge.length} knowledge file(s) loaded`);
      for (const k of projectKnowledge) {
        const wordCount = (k.content.match(/[a-zA-Z]+/g) || []).length;
        console.log(`  - "${k.title}" (${k.type}): ${wordCount.toLocaleString()} words`);
      }

      return knowledgePrompt;
    } catch (err) {
      return '';
    }
  }

  _registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      const swPath = new URL('sw.js', window.location.href).pathname;
      navigator.serviceWorker.register(swPath).catch(() => {
        // Service worker registration failed — app still works without it
      });
    }
  }
}

// --- Initialize ---
document.addEventListener('DOMContentLoaded', () => {
  const app = new App();
  app.init().catch(err => {
    console.error('Genesis 2 initialization failed:', err);
  });

  // Expose for debugging
  window.__genesis = app;
});
